function cfg = dali_p0_config()
%DALI_P0_CONFIG  课题4 Baseline V1 (P0) 的全部设置与临时假设。
%   只改这一个文件即可。每一项假设都会写入日志 / revision_log.csv，
%   均为“未经数据方确认”的试验配置，不代表真实设备语义或调度权限。

here = fileparts(mfilename('fullpath'));

%% ---------------- 路径 ----------------
cfg.txtfile          = fullfile(here, 'pasExp_20261004_153500_1.txt'); % 原始TXT（只读，不会被修改）
cfg.outdir           = '';   % 空 = 自动命名 out_P0_<电压口径>_n1screen<0/1>，不同口径的运行互不覆盖
cfg.matpower_path    = '';  % MATPOWER 不在 path 时填根目录，如 'D:\matpower8.0'
cfg.copt_matlab_path = '';  % copt_solve 不在 path 时填 COPT 的 MATLAB 接口目录
cfg.expected_sha256  = '85f724d78dfed663da29127f0da1b1cab71ace41e72c6e6cf6acea697d08509c';

%% ---------------- 拓扑审计期望值（修订版报告口径） ----------------
cfg.expect = struct('branch_on', 1000, 'simple_edges', 931, 'simple_bridges', 839, ...
    'multigraph_bridges', 775, 'nonbridge', 225, 'parallel_groups', 67, ...
    'nonbridge_tap0', 29, 'nonbridge_tapnz', 196, 'cand_after_excl', 28);

%% ---------------- 数据转换（临时假设） ----------------
cfg.conv.va_unit   = 'rad';   % 源VA按弧度（反算支持）；'deg' 为字面解释
cfg.conv.b_factor  = 2.0;     % MATPOWER总BR_B = 2 * 源BR_B（源为每端值的假设）
cfg.conv.imp_policy = 'perbranch_bestfit';
%   'perbranch_bestfit' : 逐条在 {原R/X, X变号(损耗符号判据), R/X除以TAP, 二者组合}
%                         中选两端复功率误差最小者，且改善 > imp_min_improve_MVA 才采用
%   'none'              : 全部保留原R/X
%   'rule_all'          : 对照用，相当于审计脚本 H5 的统一规则（不推荐作为正式口径）
cfg.conv.imp_min_improve_MVA = 0.01;

cfg.boundary.buses           = [175 176 314];
cfg.boundary.zero_PD_buses   = [175 314];   % 疑似重复计入的负PD置0（原值记入日志）
cfg.boundary.merge_gen_buses = 176;         % 176 对冲等值机组合并（净PG约3.573 MW），PD保留
cfg.boundary.fix_voltage     = true;        % 外网边界母线电压固定在断面值（AC与COPT一致）
cfg.boundary.forbidden_pairs = [175 176];   % 禁止作为OTS开断变量的端点对（每行一对）

cfg.qeq.mode           = 'BS';   % PQ母线无功缺额等值：'BS'(随V^2) | 'QD'(恒定注入) | 'none'
cfg.qeq.threshold_Mvar = 0.01;   % |缺额| 大于此值才补；这是等值，不是可投切电容器
cfg.qeq.allow_negative = true;   % 是否允许负BS（感性）等值

%% ---------------- 支路额定值解释 ----------------
cfg.rate.unit = 'A';
%   'A'   : RATE_A 数值规律与额定电流(A)吻合（35/10kV主变 132A=8MVA@35kV 等），
%           按首端 BASE_KV 折算 S = sqrt(3)*kV*I/1000，OPF采用电流限值
%   'MVA' : 字面按 MVA 解释（与旧报告11.43%口径一致）
cfg.rate.enforce_in_opf = true;
cfg.rate.relax_preexisting = true;   % 断面已超额定的支路：优化中限值放宽到断面值*margin（仍按原额定评价越限）
cfg.rate.relax_margin = 1.10;        %   否则有功固定的机组出线会使 OPF 直接不可行（如源第942行 110/6kV 主变）

%% ---------------- 机组权限（试验配置，非真实权限） ----------------
cfg.gen.p_policy = 'fixed_snapshot';   % 本地机组有功固定在断面值；仅175主机组（外网平衡）可变
cfg.gen.q_policy = 'pf_trial';         % 'pf_trial' | 'raw'(±1000占位) | 'fixed_snapshot'
cfg.gen.pf_lag   = 0.85;               % pf_trial: Qmax = tan(acos(0.85))*max(PG,0)，且不小于断面QG
cfg.gen.pf_lead  = 0.95;               % pf_trial: Qmin = -tan(acos(0.95))*max(PG,0)，且不大于断面QG
cfg.gen.slack_P_range = [-5000 5000];  % 175主机组（外网等值）有功范围 MW

%% ---------------- 目标函数（MATPOWER 与 COPT 权重一致） ----------------
cfg.obj.c_loss    = 1.0;              % $/MWh，网损代理单价（不是真实发电成本）
cfg.obj.vpen_list = [100 10 1000];    % 电压越限惩罚 $/p.u.；第1个为主方案，其余为权重灵敏度
cfg.vlim.opf_source = 'file';         % 'file'(文件0.90/1.05) | 'taskbook_proxy'(110/35kV用0.97~1.07)

%% ---------------- AC-OPF ----------------
cfg.opf.solver           = 'MIPS';
cfg.opf.try_ipopt_on_fail = true;
cfg.opf.max_it           = 500;
cfg.opf.verbose          = 1;

%% ---------------- COPT 代理OTS ----------------
cfg.ots.kmax             = 1;     % 最多开断条数（P0：0~1）
cfg.ots.candidate_rows   = [];    % 空 = 使用28条初筛候选；台账确认后可填白名单（源Branch行号）
cfg.ots.require_n1_connectivity = true;  % v0.2：单条开断后不得产生新的桥（N-1连通性必要条件，不等于N-1校验）
cfg.ots.theta_trust      = 0.3;   % |Δθ| 信赖域 rad
cfg.ots.dv_trust         = 0.05;  % |ΔV| 信赖域 p.u.
cfg.ots.angdiff_open_max = 0.35;  % 'fixed' 模式的候选角差上限 rad（≈20°）
cfg.ots.bigm_mode        = 'lodf'; % v1.0-a3：'lodf' 按直流开断灵敏度估算开断角差收紧 Big-M；'fixed' 为旧口径
cfg.ots.angdiff_margin   = 3;      %   角差上限 = 3 × 估算开断角差（原型：估算与交流相差 < 2%）
cfg.ots.angdiff_floor    = 1 * pi / 180;  % 下限 1°
cfg.ots.loss_cut         = true;   % v1.0-a3：候选支路两端潮流之和（损耗）一致性割，松弛 gap 原型中 -97%
cfg.ots.dv_open          = 0.02;
cfg.ots.taps             = false;  % v1.0-b：主变分接头挡位整数变量（P0 关闭；run_dali_mp 按 cfg.mp.taps 开启）
cfg.ots.tap_step         = 0.0125; %   每挡 1.25%（占位，待台账）
cfg.ots.tap_max_steps    = 8;      %   相对当前挡位最多 ±8 挡
cfg.ots.tap_range        = [0.90 1.10];  % 变比绝对范围
cfg.ots.tap_kv_min       = [];     %   空 = 全部在运 TAP≠0 支路（候选与近零阻抗除外）   %   候选两端电压增量差 |dVf-dVt| 上限 p.u.（原型实测 <= 0.0022）
cfg.ots.switch_cost      = 0.01;  % 每开断一条的微小成本 $，避免目标相同时的无意义开断
cfg.ots.max_nogood       = 20;
cfg.ots.merge_ideal      = true;   % v0.9：|z| <= ideal_zmax 的非候选支路按理想连接合并为超节点
cfg.ots.ideal_zmax       = 2e-4;   % 本断面命中 26 条（R=0、X=1e-4 等）    % kmax>1 时连通性 no-good 割的最大次数
cfg.copt.time_limit = 60;
cfg.copt.rel_gap    = 1e-6;
cfg.copt.int_tol    = 1e-9;
cfg.copt.threads    = 0;          % 0 = COPT 默认
cfg.copt.extra_params = struct();   % v0.9：合并近零阻抗支路后恢复预处理；失败/违反量超限时自动以 Presolve=0 重解
%   v0.4 默认关闭COPT预处理：本模型上预处理两次出错——file口径返回违反约束的“optimal”解，
%   taskbook口径把可行模型（全在运基点可行）判为 infeasible；Presolve=0 时三组权重均干净最优。
%   疑似根源：25条近零阻抗支路(R=0, X=1e-4, |y|=1e4)造成的病态，P1拟在代理中并合其两端母线。
cfg.copt.viol_tol   = 1e-3;       % 自行复核MIQP解（未缩放约束）的允许违反量 p.u.
cfg.copt.retry_miqp_without_presolve = true;  % 超过 viol_tol 时以 Presolve=0 重解MIQP，取违反量小者

%% ---------------- 静态 N-1（v0.5） ----------------
cfg.n1.run            = true;
cfg.n1.kv_min         = 110;              % 故障集：元件两端最高电压 >= 110 kV
cfg.n1.types          = {'line', 'xfmr'}; % 线路(TAP=0) 与 变压器(TAP~=0)
cfg.n1.count_bridges  = false;            % false：桥元件（断开即解列）不计入通过率，单独报告失负荷/失出力
                                          % true ：桥元件计入分母并一律判为不通过
cfg.n1.include_gens   = false;            % 是否纳入机组故障
cfg.n1.gen_min_MW     = 5;                %   纳入时只考虑 |PG| >= 该值的本地机组
cfg.n1.enforce_q_lims = true;             % 故障后潮流按试验无功范围限制机组（越限转PQ）
cfg.n1.overload_limit = 1.00;             % 负载率上限（按 cfg.rate.unit 解释 RATE_A）
cfg.n1.worsen_tol_load = 0.05;            % 增量判据：既有过载恶化超过 5 个百分点才判不通过
cfg.n1.v_tol          = 1e-3;             % 电压越限判定容差 p.u.
cfg.n1.worsen_tol_v   = 0.01;             % 增量判据：既有电压越限恶化超过 0.01 p.u. 才判不通过
cfg.n1.emerg_vband    = [0.90 1.10];      % 事故判据电压带（占位，待按调度规程确认）
cfg.n1.v_kv_min       = 35;               % v0.7：N-1 电压检查只计 >= 35 kV 母线（任务书终期考核范围）

%% ---------------- 静态电压稳定 CPF（v0.7，任务书 4.2 稳定性指标） ----------------
cfg.cpf.run            = true;
cfg.cpf.kv_max         = 110;             % 负荷增长方向：非边界、<= 110 kV 母线的正 PD
cfg.cpf.target_scale   = 1.0;             % 目标算例负荷 = (1 + target_scale) × 基态
cfg.cpf.step           = 0.05;
cfg.cpf.enforce_q_lims = true;

%% ---------------- 完整 AC-OTS（v1.1，run_dali_acots） ----------------
cfg.acots.cand_mode = 'nonbridge'; % 'nonbridge' 全部非桥支路（线路+主变，224 条）| 'lines' 仅非桥线路（28）| 'n1screen' P0 的 8 条
cfg.acots.kmax      = 1;       % 1 = 单条开断精确穷举；>=2 为逐条贪心
cfg.acots.vpen      = 100;     % 与 P0 主权重相同
cfg.acots.parallel  = false;   % true 且有 Parallel Computing Toolbox 时用 parfor
cfg.acots.show_top  = 15;      % 每阶段打印前若干个最优开断
cfg.acots.min_gain  = 1e-4;    % J_AC 改善不足此值（$/h）即停止
cfg.acots.n1        = true;    % 对基准与最优拓扑做静态 N-1

%% ---------------- 4.1 多时段参考模型（v1.0-a，run_dali_mp） ----------------
cfg.mp.T            = 16;      % 时段数（15 min × 16 = 4 h）
cfg.mp.dt_h         = 0.25;    % 时段长度 h（目标按能量计）
cfg.mp.load_start   = 1.00;    % 负荷系数曲线（占位）：第 1 时段 = 断面
cfg.mp.load_end     = 1.08;    %   线性升至 1.08（4 h 爬升段）
cfg.mp.load_kv_max  = 110;     % 缩放范围：<= 110 kV 非边界正负荷（与 CPF 一致）
cfg.mp.vpen         = 100;     % 电压越限惩罚 $/p.u.·h
cfg.mp.disp_min_MW  = 10;      % 可调机组：本地、断面 PG >= 10 MW（35 台，约 629 MW）
cfg.mp.disp_range   = 0.20;    %   出力范围 S1 出力 ±20%（占位）
cfg.mp.ramp_frac    = 0.10;    %   爬坡 ≤ 10% S1 出力 / 时段（占位）
cfg.mp.max_actions  = 4;       % 全程开关动作次数上限
cfg.mp.min_hold     = 4;       % 动作后最小持续时段数（1 h）
cfg.mp.action_cost  = 0.01;    % 每次动作成本 $（仅打破平局）
cfg.mp.time_limit   = 300;     % COPT 时间上限 s（v1.0-b：整数约 8000 个，基准测试放宽到 300 s）
cfg.mp.rel_gap      = 1e-4;    % 多时段相对 gap
cfg.mp.miqp_presolve = 0;      % MIQP 直接关预处理（v0.3 起各轮均被误判不可行，节省重试时间）
cfg.mp.curtail_cost = 0;       % v1.0-a3：可调机组低于 S1 出力的压减成本 $/MWh（0 = 不计，仅统计压减电量）
cfg.mp.taps         = true;    % v1.0-b：多时段模型启用分接头整数变量
cfg.mp.tap_move_max = 1;       %   每时段每台最多调 1 挡
cfg.mp.lp_method    = 2;       %   LP 用内点法（连续阶段与 MILP 根节点；v1.0-a4 单纯形 81.7 s）；[] = COPT 默认
cfg.mp.loss_model   = 'quadratic'; % v1.0-c：连续阶段 QP 内点法约 2.5 s；'pwl'（切线外逼近，MILP）的 LP 在 v1.0-b 中内点法数值失败、单纯形 77 s
cfg.mp.slp_iters    = 3;       % v1.0-d：逐次线性化总轮数（第 1 轮即松弛-取整；之后在上轮决策的交流状态处重新线性化）
cfg.mp.slp_tol      = 0.005;   %   AC 目标相对改善 < 0.5% 即停止
cfg.mp.round_repair = false;   % v1.0-c3：取整后不再在线性化模型中重解（v1.0-c/c2 均不可行），直接以交流潮流校核
cfg.mp.round_dv_trust = 0.08;  % v1.0-c2：取整阶段电压增量信任域放宽到 ±0.08（v1.0-c 直接取整后 QP 不可行）
cfg.mp.rf_rounds    = 4;       %   失败时逐步固定：每轮固定离整数 <= rf_tol 的挡位，最后一轮全部固定
cfg.mp.rf_tol       = 0.2;
cfg.mp.copt_mip     = false;   % v1.0-c3：COPT 整体求解基准默认关闭（v1.0-b/c/c2 已测：120–300 s gap 52%，停在初始解）    % v1.0-c：启发式之后再让 COPT 解完整整数模型作基准（初始解 = 启发式解）
cfg.mp.copt_mip_time = 120;    %   该基准的时限 s
cfg.mp.pwl_cover    = 0.995;   %   切线逼近覆盖网损曲率的份额（原型：约 640 个潮流变量/时段），其余一阶线性化
cfg.mp.pwl_grid     = [-2 -1 -0.5 0 0.5 1 2];  % 切点 = 基点潮流 + d*grid，另加 0 点
cfg.mp.pwl_rel      = 0.25;    %   d = max(0.25*|基点潮流|, pwl_abs)
cfg.mp.pwl_abs      = 0.02;    %   p.u.
cfg.mp.cut_level    = 1;       %   仅 quadratic（MIQP）时使用；MILP 用 COPT 默认割平面       % 根节点割平面强度（v1.0-a 根节点割平面耗时约 150 s）；[] = COPT 默认

%% ---------------- 评价口径 ----------------
cfg.taskbook.v_kv   = [110 35];      % 任务书：220kV变电站110kV和35kV母线 -3%~+7%（无变电站映射，按电压等级代理）
cfg.taskbook.v_band = [0.97 1.07];

%% ---------------- 其它 ----------------
cfg.run_raw_pf         = false;   % 对字面raw算例跑潮流（仅对照，默认关）
cfg.run_enum_reference = true;    % 逐条开断 AC-OPF 独立参考（不是COPT优化，约需数分钟）
end
