function run_dali_mp(varargin)
%RUN_DALI_MP  课题4 指标4.1 多时段参考模型 v1.0-a：16 时段 × 8 候选开关 + 可调机组出力（含爬坡）。
%   流程：P0 准备（读数、建算例、S1 AC-OPF，不计入 4.1 时钟）→
%         MP-1 生成时段数据与线性化点（逐时段 ACPF）→ MP-2 逐时段建块 → MP-3 COPT 整体 MIQP
%         （4.1 时钟到此为止：从输入数据到可行解）→ 对照：同模型固定全在运的连续 QP →
%         MP-4 逐时段 MATPOWER AC 校核与指标。
%   默认电压口径为任务书口径（P0 结论）。覆盖配置同 run_dali_p0，例如 run_dali_mp('mp.max_actions', 8)。

here = fileparts(mfilename('fullpath'));
addpath(here);
cfg = dali_p0_config();
cfg.vlim.opf_source = 'taskbook_proxy';
if mod(numel(varargin), 2) ~= 0
    error('dali:mp', 'Overrides must be name/value pairs');
end
for i = 1:2:numel(varargin)
    fpath = strsplit(varargin{i}, '.');
    cfg = setfield(cfg, fpath{:}, varargin{i+1}); %#ok<SFLD>
end
if isempty(cfg.outdir)
    cfg.outdir = fullfile(here, sprintf('out_MP_T%d_%s', cfg.mp.T, cfg.vlim.opf_source));
end
if ~exist(cfg.outdir, 'dir'), mkdir(cfg.outdir); end
stamp = datestr(now, 'yyyymmdd_HHMMSS');
logf = fullfile(cfg.outdir, ['MP_log_' stamp '.txt']);
diary(logf);
cleaner = onCleanup(@() diary('off')); %#ok<NASGU>
fprintf('Dali multi-period reference model run %s (package v1.1)\n', stamp);
for i = 1:2:numel(varargin)
    fprintf('  override: %s = %s\n', varargin{i}, mat2str(varargin{i+1}));
end
try
    main_mp(cfg, stamp, logf);
catch err
    fprintf(2, '\n*** RUN FAILED ***\n%s\n', getReport(err, 'extended', 'hyperlinks', 'off'));
    fprintf('\nPlease upload the log file: %s\n', logf);
end
end

%% =======================================================================
function main_mp(cfg, stamp, logf)
Tm = struct();
t0 = tic;
env = dali_p0_step0_env(cfg);
if ~env.matpower_ok, error('dali:mp', 'MATPOWER >= 7 required'); end
if ~env.copt.ok, error('dali:mp', 'COPT interface not available'); end
define_constants;
raw = dali_read_pasexp(cfg.txtfile);
topo = dali_topology_audit(raw, cfg);
[mpc, ~, meta] = dali_build_case(raw, topo, cfg);
[pf0, ~] = dali_run_acpf(mpc, meta, 'equivalent_v1', false, false);
vpen = cfg.mp.vpen;
[mpo, opfset] = dali_setup_opf(mpc, pf0, meta, cfg, vpen, []);
[r1, i1] = dali_run_acopf(mpo, opfset, cfg, env, 'MP period-0 controls (S1)');
if ~i1.success, error('dali:mp', 'S1 AC-OPF failed; cannot set period controls'); end
Tm.p0_prep_s = toc(t0);

%% ---------------- MP-1: period data + linearisation points (4.1 clock starts) ----------------
T = cfg.mp.T;
fprintf('\n===== MP-1: %d periods of %.2f h, load factor %.3f -> %.3f =====\n', T, cfg.mp.dt_h, ...
    cfg.mp.load_start, cfg.mp.load_end);
tclock = tic; tt = tic;
lam = linspace(cfg.mp.load_start, cfg.mp.load_end, T);
sel = mpc.bus(:, PD) > 0 & meta.base_kv <= cfg.mp.load_kv_max & ~meta.is_boundary;
gon = mpc.gen(:, GEN_STATUS) > 0;
dispg = gon & ~ismember(mpc.gen(:, GEN_BUS), cfg.boundary.buses) & meta.snap_gen_PG >= cfg.mp.disp_min_MW;
dispg(opfset.slackgen) = false;
pg_init = r1.gen(:, PG);
opm = opfset;
opm.pmin(dispg) = (1 - cfg.mp.disp_range) * pg_init(dispg);
opm.pmax(dispg) = (1 + cfg.mp.disp_range) * pg_init(dispg);
fprintf('  scaled load: %d buses, %.1f MW at factor 1 | dispatchable units: %d (%.1f MW), range +-%.0f%%, ramp %.0f%%/period\n', ...
    sum(sel), sum(mpc.bus(sel, PD)), sum(dispg), sum(pg_init(dispg)), 100 * cfg.mp.disp_range, 100 * cfg.mp.ramp_frac);
m0 = mpc;
m0.gen(:, QMIN) = opfset.qmin;
m0.gen(:, QMAX) = opfset.qmax;
mpopt_pf = mpoption('pf.alg', 'NR', 'pf.tol', 1e-8, 'pf.nr.max_it', 30, 'verbose', 0, 'out.all', 0, ...
    'pf.enforce_q_lims', 1);
cases = cell(1, T); bases = cell(1, T);
for t = 1:T
    mt = m0;
    mt.bus(sel, PD) = mpc.bus(sel, PD) * lam(t);
    mt.bus(sel, QD) = mpc.bus(sel, QD) * lam(t);
    cases{t} = mt;
    rt = runpf(dali_pf_case_from_state(mt, r1, meta, []), mpopt_pf);
    if ~rt.success
        error('dali:mp', 'Base ACPF failed at period %d (load factor %.3f)', t, lam(t));
    end
    bases{t} = rt;
end
Tm.mp1_period_acpf_s = toc(tt);
fprintf('  %d base power flows converged in %.2f s\n', T, Tm.mp1_period_acpf_s);

%% ---------------- MP-2: blocks ----------------
fprintf('\n===== MP-2: build %d period blocks =====\n', T);
tt = tic;
blocks = cell(1, T);
cfg.ots.taps = cfg.mp.taps;
for t = 1:T
    blocks{t} = dali_mp_build_period(bases{t}, opm, meta, cfg, vpen, cfg.mp.dt_h, t == 1);
end
Tm.mp2_build_s = toc(tt);
ntp = numel(blocks{1}.tapk);
fprintf('  blocks built in %.2f s | integer decisions: %d switches x %d periods = %d binary, %d taps x %d periods = %d integer (binary-encoded equivalent %d)\n', ...
    Tm.mp2_build_s, numel(meta.cand_rows), T, numel(meta.cand_rows) * T, ntp, T, ntp * T, ...
    T * getfield_def(blocks{1}.chk, 'tap_binary_equiv', 0));

%% ---------------- MP-3 (v1.0-c): dispatch-only QP -> relaxed taps -> rounded taps -> optional COPT MIP ----------------
info = struct('disp', dispg, 'pg_init', pg_init, 'base', mpc.baseMVA, 'z_mode', 'all_on', 'tap_mode', 'zero');
fprintf('\n===== MP-3a: dispatch only (switches all in service, taps at current step), loss model %s =====\n', cfg.mp.loss_model);
S0 = dali_mp_solve(blocks, info, cfg, env);
Tm.mp3a_dispatch_s = S0.solve_time_s;
Tm.clock_first_feasible_s = toc(tclock);
if ~S0.ok
    error('dali:mp', 'Dispatch-only problem returned no solution (status %s)', S0.status);
end
fprintf('\n  >>> 4.1 clock to FIRST feasible solution (dispatch only): %.2f s  [ACPF %.2f + build %.2f + solve %.2f]\n', ...
    Tm.clock_first_feasible_s, Tm.mp1_period_acpf_s, Tm.mp2_build_s, Tm.mp3a_dispatch_s);
S = S0; used = 'DISPATCH_ONLY';
Tm.mp3b_relax_s = 0; Tm.mp3c_round_s = 0; Tm.mp3d_copt_mip_s = 0;
Sr = []; Sh = []; Sm = [];
if ntp > 0
    fprintf('\n===== MP-3b: tap steps relaxed to continuous (switches all in service) -> lower bound for this subproblem =====\n');
    info.tap_mode = 'relax'; info.diag_binding = true;
    Sr = dali_mp_solve(blocks, info, cfg, env);
    info.diag_binding = false;
    Tm.mp3b_relax_s = Sr.solve_time_s;
    if Sr.ok
        fprintf('\n===== MP-3c: round taps period by period (|move| <= %g step, within range), fix, re-solve =====\n', cfg.mp.tap_move_max);
        nfix = round_taps(Sr.ntap_cont, Sr.tap_lo, Sr.tap_hi, cfg.mp.tap_move_max);
        Sh = Sr; Sh.ok = false;
        if cfg.mp.round_repair
            info.tap_mode = 'fixed'; info.tap_fix = nfix; info.dv_trust = cfg.mp.round_dv_trust;
            fprintf('  attempt 1: fix all rounded taps, voltage trust region widened to +-%.3f pu\n', cfg.mp.round_dv_trust);
            Sh = dali_mp_solve(blocks, info, cfg, env);
            Tm.mp3c_round_s = Sh.solve_time_s;
        end
        if cfg.mp.round_repair && ~Sh.ok                % relax-and-fix: fix near-integral taps first
            cur = Sr; fixed = nan(ntp, T);
            for rd = 1:cfg.mp.rf_rounds
                nr = round_taps(cur.ntap_cont, Sr.tap_lo, Sr.tap_hi, cfg.mp.tap_move_max);
                near = abs(cur.ntap_cont - nr) <= cfg.mp.rf_tol;
                if rd == cfg.mp.rf_rounds, near(:) = true; end
                tf = fixed; newm = near & isnan(fixed); tf(newm) = nr(newm);
                info.tap_fix = tf; info.dv_trust = ternary(rd == cfg.mp.rf_rounds, cfg.mp.round_dv_trust, []);
                fprintf('  relax-and-fix round %d: %d of %d tap values fixed\n', rd, sum(~isnan(tf(:))), numel(tf));
                Sx = dali_mp_solve(blocks, info, cfg, env);
                Tm.mp3c_round_s = Tm.mp3c_round_s + Sx.solve_time_s;
                if ~Sx.ok, break; end
                cur = Sx; fixed = tf;
                if all(~isnan(fixed(:))), Sh = Sx; nfix = fixed; break; end
            end
        end
        info.dv_trust = [];
        if Sh.ok                                        % repaired in the proxy (only with cfg.mp.round_repair)
            Sh.ntap = nfix;
            Sh.tap_moves = sum(sum(abs(diff([zeros(ntp, 1), nfix], 1, 2))));
            fprintf('  relax-and-round (proxy-repaired): objective %.4f vs relaxed bound %.4f vs dispatch only %.4f\n', ...
                Sh.objval, Sr.objval, S0.objval);
            if Sh.objval < S.objval, S = Sh; used = 'RELAX_AND_ROUND'; end
        else                                            % v1.0-c3 default: relaxed controls + rounded taps, judged by AC power flow
            Sh = Sr; Sh.ntap = nfix;
            Sh.tap_moves = sum(sum(abs(diff([zeros(ntp, 1), nfix], 1, 2))));
            dr = abs(Sr.ntap_cont - nfix);
            fprintf(['  relax-and-round: taps rounded from the relaxed solution (max |rounding| %.2f step, mean %.3f) | ', ...
                'tap moves %d, transformers used %d of %d | proxy objective of the relaxation %.4f vs dispatch only %.4f ', ...
                '(feasibility is judged by the AC check)\n'], max(dr(:)), mean(dr(:)), Sh.tap_moves, sum(any(nfix ~= 0, 2)), ntp, ...
                Sr.objval, S0.objval);
            S = Sh; used = 'RELAX_AND_ROUND_AC';
        end
    end
end
Tm.clock_heuristic_s = toc(tclock);
fprintf('\n  >>> 4.1 clock to INTEGER decision (%s): %.2f s  [ACPF %.2f + build %.2f + dispatch %.2f + relax %.2f + round %.2f]\n', ...
    used, Tm.clock_heuristic_s, Tm.mp1_period_acpf_s, Tm.mp2_build_s, Tm.mp3a_dispatch_s, Tm.mp3b_relax_s, Tm.mp3c_round_s);
if cfg.mp.copt_mip
    fprintf('\n===== MP-3d: COPT on the full integer model (switches + taps), MIP start = %s solution, %g s (benchmark) =====\n', ...
        used, cfg.mp.copt_mip_time);
    info.z_mode = 'free'; info.tap_mode = 'integer'; info.start = S0.x; info.time_limit = cfg.mp.copt_mip_time;
    if strcmp(used, 'RELAX_AND_ROUND'), info.dv_trust = cfg.mp.round_dv_trust; end   % same feasible set as the start
    Sm = dali_mp_solve(blocks, info, cfg, env);
    Tm.mp3d_copt_mip_s = Sm.solve_time_s;
    if Sm.ok
        fprintf('  COPT benchmark: status %s, objective %.4f (start %.4f), gap %g\n', Sm.status, Sm.objval, S.objval, Sm.bestgap);
        if ~strcmp(used, 'RELAX_AND_ROUND_AC') && Sm.objval < S.objval - 1e-6, S = Sm; used = 'COPT_MIP'; end
    end
end
Tm.clock_input_to_solution_s = toc(tclock);
fprintf('\n  >>> final decision from %s | objective %.4f (dispatch only %.4f) | switching actions %g | tap moves %g\n', ...
    used, S.objval, S0.objval, S.actions, S.tap_moves);

%% ---------------- MP-3e (v1.0-d): successive linearisation of the tap decision, judged by AC ----------------
tapk = blocks{1}.tapk;
D0 = mk_decision(S0, blocks, zeros(ntp, T), 'D');
DF = mk_decision(S, blocks, S.ntap, 'F1');
DF.tap_abs = S.ntap;
tslp = tic;
Af = ac_eval(DF, bases, cases, meta, cfg, vpen, opm, mpopt_pf, tapk);
slp_log = struct('it', 1, 'J_AC', cfg.mp.dt_h * sum(Af.J), 'viol', mean(Af.viol), 'loss_MWh', cfg.mp.dt_h * sum(Af.loss), ...
    'vq', mean(Af.vq), 'conv', sum(Af.conv), 'tap_moves', sum(sum(abs(diff([zeros(ntp, 1), DF.tap_abs], 1, 2)))), ...
    'proxy_viol', mean(DF.viol_proxy), 'time_s', toc(tslp));
if ntp > 0 && strcmp(used, 'RELAX_AND_ROUND_AC') && cfg.mp.slp_iters > 1
    fprintf('\n===== MP-3e: successive linearisation at the AC state of the current decision (up to %d iterations) =====\n', cfg.mp.slp_iters);
    fprintf('  it 1: AC objective %.1f $ | mean viol %.3f pu (proxy %.3f) | energy loss %.2f MWh | 110/35kV %.1f %% | conv %d/%d\n', ...
        slp_log(1).J_AC, slp_log(1).viol, slp_log(1).proxy_viol, slp_log(1).loss_MWh, slp_log(1).vq, slp_log(1).conv, T);
    for it = 2:cfg.mp.slp_iters
        if any(~Af.conv), fprintf('  stop: AC not converged in every period\n'); break; end
        tk = tic;
        blk = cell(1, T);
        for t = 1:T
            blk{t} = dali_mp_build_period(Af.res{t}, opm, meta, cfg, vpen, cfg.mp.dt_h, false);
        end
        infok = struct('disp', dispg, 'pg_init', pg_init, 'base', mpc.baseMVA, 'z_mode', 'all_on', ...
            'tap_mode', 'relax', 'tap_offset', DF.tap_abs);
        Sk = dali_mp_solve(blk, infok, cfg, env);
        if ~Sk.ok, fprintf('  stop: relaxed QP failed (%s)\n', Sk.status); break; end
        nabs = round_taps(Sk.ntap_cont + DF.tap_abs, Sr.tap_lo, Sr.tap_hi, cfg.mp.tap_move_max);
        Dn = mk_decision(Sk, blk, nabs - DF.tap_abs, sprintf('F%d', it));
        Dn.tap_abs = nabs;
        An = ac_eval(Dn, bases, cases, meta, cfg, vpen, opm, mpopt_pf, tapk);
        rec = struct('it', it, 'J_AC', cfg.mp.dt_h * sum(An.J), 'viol', mean(An.viol), 'loss_MWh', cfg.mp.dt_h * sum(An.loss), ...
            'vq', mean(An.vq), 'conv', sum(An.conv), 'tap_moves', sum(sum(abs(diff([zeros(ntp, 1), nabs], 1, 2)))), ...
            'proxy_viol', mean(Dn.viol_proxy), 'time_s', toc(tk));
        slp_log(end+1) = rec; %#ok<AGROW>
        fprintf(['  it %d: AC objective %.1f $ | mean viol %.3f pu (proxy %.3f) | energy loss %.2f MWh | 110/35kV %.1f %% | ', ...
            'conv %d/%d | tap moves %d | %.1f s\n'], it, rec.J_AC, rec.viol, rec.proxy_viol, rec.loss_MWh, rec.vq, rec.conv, T, ...
            rec.tap_moves, rec.time_s);
        if all(An.conv) && sum(An.J) < sum(Af.J) - cfg.mp.slp_tol * abs(sum(Af.J))
            DF = Dn; Af = An; used = sprintf('RELAX_AND_ROUND_SLP%d', it);
        else
            fprintf('  stop: no further AC improvement (keeping iteration %d)\n', it - 1);
            break;
        end
    end
end
Tm.mp3e_slp_s = toc(tslp);
Tm.clock_final_decision_s = Tm.clock_input_to_solution_s + Tm.mp3e_slp_s;
fprintf('\n  >>> 4.1 clock to FINAL integer decision (%s): %.2f s  [heuristic %.2f + successive linearisation incl. AC states %.2f]\n', ...
    used, Tm.clock_final_decision_s, Tm.clock_input_to_solution_s, Tm.mp3e_slp_s);

%% ---------------- MP-4: AC check per period: base (S1 controls) / D (dispatch only) / F (final decision) ----------------
fprintf('\n===== MP-4: MATPOWER AC check per period | base = S1 controls, D = dispatch only, F = final decision (%s) =====\n', used);
tt = tic;
dt = cfg.mp.dt_h;
Ab = ac_eval([], bases, cases, meta, cfg, vpen, opm, mpopt_pf, tapk);
Ad = ac_eval(D0, bases, cases, meta, cfg, vpen, opm, mpopt_pf, tapk);
R = struct('t', {}, 'load_factor', {}, 'load_MW', {}, 'open_rows', {}, 'taps_off_initial', {}, 'disp_pg_MW_F', {}, ...
    'loss_base_MW', {}, 'loss_D_MW', {}, 'loss_F_MW', {}, 'proxy_loss_F_MW', {}, 'viol_base_pu', {}, 'viol_D_pu', {}, ...
    'viol_F_pu', {}, 'proxy_viol_F_pu', {}, 'vq_base_pct', {}, 'vq_D_pct', {}, 'vq_F_pct', {}, 'conv_D', {}, 'conv_F', {}, ...
    'J_base', {}, 'J_D', {}, 'J_F', {});
for t = 1:T
    open = meta.cand_rows(DF.z(:, t) < 0.5);
    R(end+1) = struct('t', t, 'load_factor', lam(t), 'load_MW', sum(cases{t}.bus(sel, PD)), 'open_rows', dali_rows2str(open), ...
        'taps_off_initial', sum(DF.tap_abs(:, t) ~= 0), 'disp_pg_MW_F', sum(DF.pg(dispg, t)), ...
        'loss_base_MW', Ab.loss(t), 'loss_D_MW', Ad.loss(t), 'loss_F_MW', Af.loss(t), 'proxy_loss_F_MW', DF.loss_proxy(t), ...
        'viol_base_pu', Ab.viol(t), 'viol_D_pu', Ad.viol(t), 'viol_F_pu', Af.viol(t), 'proxy_viol_F_pu', DF.viol_proxy(t), ...
        'vq_base_pct', Ab.vq(t), 'vq_D_pct', Ad.vq(t), 'vq_F_pct', Af.vq(t), 'conv_D', Ad.conv(t), 'conv_F', Af.conv(t), ...
        'J_base', Ab.J(t), 'J_D', Ad.J(t), 'J_F', Af.J(t)); %#ok<AGROW>
    fprintf(['  t%02d x%.3f | open %-5s taps off %3d | loss %.2f / %.2f / %.2f MW (proxy F %.2f) | viol %.3f / %.3f / %.3f pu ', ...
        '(proxy F %.3f) | 110/35kV qualified %.1f / %.1f / %.1f %% | conv D %d F %d\n'], t, lam(t), R(end).open_rows, ...
        R(end).taps_off_initial, Ab.loss(t), Ad.loss(t), Af.loss(t), DF.loss_proxy(t), Ab.viol(t), Ad.viol(t), Af.viol(t), ...
        DF.viol_proxy(t), Ab.vq(t), Ad.vq(t), Af.vq(t), Ad.conv(t), Af.conv(t));
end
Tm.mp4_ac_check_s = toc(tt);
Eloss_base = dt * sum(Ab.loss); Eloss_D = dt * sum(Ad.loss); Eloss_dec = dt * sum(Af.loss);
dpg = DF.pg(dispg, :) - pg_init(dispg) * ones(1, T);
E_up = dt * sum(max(dpg(:), 0)); E_down = dt * sum(max(-dpg(:), 0));
fprintf('\n  dispatchable units (F): +%.2f MWh raised, -%.2f MWh reduced vs S1 over the horizon (curtail cost %g $/MWh)\n', ...
    E_up, E_down, cfg.mp.curtail_cost);
fprintf(['  horizon (base / D / F): energy loss %.2f / %.2f / %.2f MWh | mean voltage violation %.3f / %.3f / %.3f pu | ', ...
    'mean 110/35kV qualified %.1f / %.1f / %.1f %% | AC objective %.1f / %.1f / %.1f $ | converged D %d/%d F %d/%d\n'], ...
    Eloss_base, Eloss_D, Eloss_dec, mean(Ab.viol), mean(Ad.viol), mean(Af.viol), mean(Ab.vq), mean(Ad.vq), mean(Af.vq), ...
    dt * sum(Ab.J), dt * sum(Ad.J), dt * sum(Af.J), sum(Ad.conv), T, sum(Af.conv), T);
fprintf('  final decision: switching actions %g | tap moves %d | transformers moved %d of %d | decision from %s\n', ...
    DF.actions, slp_log(end).tap_moves * 0 + sum(sum(abs(diff([zeros(ntp, 1), DF.tap_abs], 1, 2)))), ...
    sum(any(DF.tap_abs ~= 0, 2)), ntp, used);
writetable(struct2table(slp_log), fullfile(cfg.outdir, 'MP_slp_iterations.csv'));

%% ---------------- outputs ----------------
writetable(struct2table(R), fullfile(cfg.outdir, 'MP_periods.csv'));
Ssum = rmfield(S, intersect(fieldnames(S), {'z', 'pg', 'dV', 'loss_proxy', 'viol_proxy', 'max_row_viol', 'x', 'ntap', 'ntap_cont', 'tap_lo', 'tap_hi'}));
Ssum.decision_from = used;
Ssum.ref_qp_objval = S0.objval; Ssum.ref_qp_time_s = S0.solve_time_s;
Ssum.relaxed_bound = NaN; Ssum.round_objval = NaN; Ssum.copt_mip_objval = NaN; Ssum.copt_mip_gap = NaN;
if ~isempty(Sr) && Sr.ok, Ssum.relaxed_bound = Sr.objval; end
if ~isempty(Sh) && Sh.ok, Ssum.round_objval = Sh.objval; end
if ~isempty(Sm) && Sm.ok, Ssum.copt_mip_objval = Sm.objval; Ssum.copt_mip_gap = Sm.bestgap; end
Ssum.clock_heuristic_s = Tm.clock_heuristic_s; Ssum.clock_final_decision_s = Tm.clock_final_decision_s; Ssum.slp_iterations = numel(slp_log);
Ssum.Eloss_base_MWh = Eloss_base; Ssum.Eloss_D_MWh = Eloss_D; Ssum.Eloss_dec_MWh = Eloss_dec;
Ssum.J_AC_base = dt * sum(Ab.J); Ssum.J_AC_D = dt * sum(Ad.J); Ssum.J_AC_F = dt * sum(Af.J);
Ssum.disp_raised_MWh = E_up; Ssum.disp_reduced_MWh = E_down; Ssum.curtail_cost = cfg.mp.curtail_cost;
writetable(struct2table(Ssum, 'AsArray', true), fullfile(cfg.outdir, 'MP_solve_summary.csv'));
writetable(array2table(S.z.', 'VariableNames', arrayfun(@(k) sprintf('row%d', k), meta.cand_rows(:).', ...
    'UniformOutput', false)), fullfile(cfg.outdir, 'MP_switch_schedule.csv'));
S = rmfield(S, 'x'); S0 = rmfield(S0, 'x');
if ntp > 0, writematrix(DF.tap_abs, fullfile(cfg.outdir, 'MP_tap_schedule.csv')); end
save(fullfile(cfg.outdir, 'MP_workspace.mat'), 'cfg', 'S', 'S0', 'R', 'Tm', 'lam', 'dispg', 'DF', 'slp_log', '-v7');
Tm.total_s = toc(t0);
fprintf('\nTimings (s):\n'); disp(Tm);
fprintf('\n===== DONE. Upload %s (MP_log_*, MP_periods.csv, MP_solve_summary.csv, MP_switch_schedule.csv) =====\n', cfg.outdir);
end

function r = safe_pf(m, mpopt)
try
    r = runpf(m, mpopt);
catch
    r = struct('success', 0);
end
end

function s = ternary(c, a, b)
if c, s = a; else, s = b; end
end

function v = getfield_def(s, f, d)
if isfield(s, f), v = s.(f); else, v = d; end
end

function n = round_taps(nr, lo, hi, mv)
% Round relaxed tap steps period by period, keeping |n(t) - n(t-1)| <= mv (n(0) = 0) and lo <= n <= hi.
[ntp, T] = size(nr);
n = zeros(ntp, T);
prev = zeros(ntp, 1);
for t = 1:T
    v = round(nr(:, t));
    v = min(max(v, prev - mv), prev + mv);
    v = min(max(v, lo(:)), hi(:));
    n(:, t) = v;
    prev = v;
end
end

function D = mk_decision(Sx, blk, nrel, label)
% Multi-period decision in absolute terms: switch states, generator P, voltage settings, tap ratios.
T = numel(blk); nb = blk{1}.nb; ntp = numel(blk{1}.tapk);
D = struct('label', label, 'z', Sx.z, 'pg', Sx.pg, 'vm', zeros(nb, T), 'ratio', zeros(ntp, T), ...
    'loss_proxy', Sx.loss_proxy, 'viol_proxy', Sx.viol_proxy, 'actions', Sx.actions, 'tap_abs', zeros(ntp, T));
for t = 1:T
    D.vm(:, t) = blk{t}.vm0 + Sx.dV{t}(blk{t}.sidx(:));
    if ntp > 0
        D.ratio(:, t) = blk{t}.tau0 + blk{t}.tapstep * nrel(:, t);
    end
end
end

function A = ac_eval(D, bases, cases, meta, cfg, vpen, opm, mpopt, tapk)
% AC power flow + evaluation of one multi-period decision (D empty: the base states themselves).
define_constants;
T = numel(bases);
A = struct('loss', nan(1, T), 'viol', nan(1, T), 'vq', nan(1, T), 'conv', zeros(1, T), 'J', nan(1, T));
A.res = cell(1, T);
for t = 1:T
    if isempty(D)
        r = bases{t};
    else
        open = meta.cand_rows(D.z(:, t) < 0.5);
        st = bases{t};
        st.gen(:, PG) = D.pg(:, t);
        st.bus(:, VM) = D.vm(:, t);
        m = dali_pf_case_from_state(cases{t}, st, meta, open);
        if ~isempty(tapk)
            m.branch(tapk, TAP) = D.ratio(:, t);
        end
        r = safe_pf(m, mpopt);
    end
    A.res{t} = r;
    E = dali_eval_ac(r, meta, cfg, vpen, sprintf('t%02d', t), opm);
    A.conv(t) = E.converged;
    if E.converged
        A.loss(t) = E.loss_MW; A.viol(t) = E.sum_v_viol_opf_scope; A.vq(t) = E.tb_vq_rate_110_35kV_pct;
        A.J(t) = cfg.obj.c_loss * E.loss_MW + vpen * E.sum_v_viol_opf_scope;
    end
end
end
