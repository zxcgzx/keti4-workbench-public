function run_dali_acots(varargin)
%RUN_DALI_ACOTS  单断面“完整 AC-OTS”：在完整非线性交流 OPF 上做开断优化。
%   对候选集中每一条可开断支路（默认：全部非桥支路，不造成解列），断开后求一次完整非线性 AC-OPF
%   （MATPOWER MIPS，与 P0 同一目标：网损 + vpen*电压越限，同一电流限值与无功/电压权限），取目标最小者。
%   kmax = 1 时这是在该候选集内对离散开断的精确穷举（每个连续子问题为非凸 AC-OPF 的局部最优）；
%   kmax >= 2 时采用逐条贪心（每一步在当前拓扑下重新判桥、重新穷举），并给出精确穷举所需 OPF 次数的估算。
%   每个候选同时给出“断开后新增桥数”（N-1 连通性），并单独给出保持 N-1 连通性的开断排名。
%   不使用线性化代理模型，也不使用 COPT。
%
%   例：run_dali_acots                                % 全部非桥支路，kmax = 1
%       run_dali_acots('acots.cand_mode', 'n1safe')   % 只穷举断开后不新增桥的支路
%       run_dali_acots('acots.cand_mode', 'lines')    % 只考虑非桥线路（与 P0 初选口径一致）
%       run_dali_acots('acots.kmax', 2)               % 贪心第二条
%       run_dali_acots('acots.parallel', true)        % 若有 Parallel Computing Toolbox

here = fileparts(mfilename('fullpath'));
addpath(here);
cfg = dali_p0_config();
cfg.vlim.opf_source = 'taskbook_proxy';
if mod(numel(varargin), 2) ~= 0
    error('dali:acots', 'Overrides must be name/value pairs');
end
for i = 1:2:numel(varargin)
    fpath = strsplit(varargin{i}, '.');
    cfg = setfield(cfg, fpath{:}, varargin{i+1}); %#ok<SFLD>
end
if isempty(cfg.outdir)
    cfg.outdir = fullfile(here, sprintf('out_ACOTS_%s_k%d_%s', cfg.acots.cand_mode, cfg.acots.kmax, cfg.vlim.opf_source));
end
if ~exist(cfg.outdir, 'dir'), mkdir(cfg.outdir); end
stamp = datestr(now, 'yyyymmdd_HHMMSS');
logf = fullfile(cfg.outdir, ['ACOTS_log_' stamp '.txt']);
diary(logf);
cleaner = onCleanup(@() diary('off')); %#ok<NASGU>
fprintf('Dali full AC-OTS (exhaustive nonlinear AC-OPF) run %s (package v1.1b)\n', stamp);
for i = 1:2:numel(varargin)
    fprintf('  override: %s = %s\n', varargin{i}, mat2str(varargin{i+1}));
end
try
    main_acots(cfg);
catch err
    fprintf(2, '\n*** RUN FAILED ***\n%s\n', getReport(err, 'extended', 'hyperlinks', 'off'));
    fprintf('\nPlease upload the log file: %s\n', logf);
end
end

%% =======================================================================
function main_acots(cfg)
define_constants;
Tm = struct();
t_all = tic;
env = dali_p0_step0_env(cfg);
if ~env.matpower_ok, error('dali:acots', 'MATPOWER >= 7 required'); end
raw = dali_read_pasexp(cfg.txtfile);
topo = dali_topology_audit(raw, cfg);
[mpc, ~, meta] = dali_build_case(raw, topo, cfg);
tpf = tic;
[pf0, ~] = dali_run_acpf(mpc, meta, 'equivalent_v1', false, false);
Tm.one_acpf_s = toc(tpf);
Tm.prep_s = toc(t_all);
vpen = cfg.acots.vpen;
nb = size(mpc.bus, 1);
nl = size(mpc.branch, 1);
inserv = mpc.branch(:, BR_STATUS) > 0;
isline = mpc.branch(:, TAP) == 0;

%% ---------------- base: full topology AC-OPF ----------------
t0 = tic;
[mpo0, opf0] = dali_setup_opf(mpc, pf0, meta, cfg, vpen, []);
[r0, i0] = dali_run_acopf(mpo0, opf0, cfg, env, 'AC-OTS base: no switching');
if ~i0.success, error('dali:acots', 'Base AC-OPF failed'); end
E0 = dali_eval_ac(r0, meta, cfg, vpen, 'acots_base', opf0);
Tm.base_opf_s = toc(t0);
fprintf('  base: J_AC %.4f $/h | loss %.3f MW | voltage violation %.4f pu | 110/35kV qualified %.1f%%\n', ...
    E0.J_AC, E0.loss_MW, E0.sum_v_viol_opf_scope, E0.tb_vq_rate_110_35kV_pct);

Sb = [];
Tm.n1_base_s = 0; Tm.n1_stage_s = 0; n1log = [];
if cfg.acots.n1_constrained
    cfg.acots.kmax = 1;
    tnb = tic;
    Sb = dali_n1_check(mpc, r0, [], opf0, meta, cfg, 'ACOTS_N1_base');
    Tm.n1_base_s = toc(tnb);
end

%% ---------------- parallel pool (optional) ----------------
usepar = false;
Tm.pool_start_s = 0;
if cfg.acots.parallel
    hasPCT = license('test', 'Distrib_Computing_Toolbox') && ~isempty(ver('parallel'));
    if hasPCT
        tp = tic;
        if isempty(gcp('nocreate')), parpool('local'); end
        Tm.pool_start_s = toc(tp);
        usepar = true;
        fprintf('  parallel pool ready (%d workers, %.1f s)\n', gcp().NumWorkers, Tm.pool_start_s);
    else
        fprintf('  Parallel Computing Toolbox not available: running serially\n');
    end
end

%% ---------------- greedy stages (stage 1 = exact single-switch enumeration) ----------------
opened = [];
init = r0; Eref = E0; opfref = opf0;
stages = {};
Tm.enum_wall_s = 0; Tm.enum_sum_s = 0; Tm.bridge_screen_s = 0; nopf = 0;
for s = 1:cfg.acots.kmax
    tb = tic;
    on = inserv; on(opened) = false;
    isbr = dali_bridges(nb, meta.f, meta.t, on);
    keep = on & ~isbr & ~topo.forbidden;
    newb = nan(nl, 1);                                 % new bridges created by opening each candidate (N-1 connectivity)
    for k = find(keep).'
        on2 = on; on2(k) = false;
        b2 = dali_bridges(nb, meta.f, meta.t, on2);
        newb(k) = sum(b2 & ~isbr);
    end
    Tm.bridge_screen_s = Tm.bridge_screen_s + toc(tb);
    fprintf('\n  N-1 connectivity: %d of %d non-bridge openings create no new bridge (%.2f s)\n', ...
        sum(newb(keep) == 0), sum(keep), toc(tb));
    switch lower(cfg.acots.cand_mode)
        case 'nonbridge', keep = keep;
        case 'lines',     keep = keep & isline;
        case 'n1screen',  keep = keep & ismember((1:nl).', meta.cand_rows);
        case 'n1safe',    keep = keep & newb == 0;   % openings that keep every remaining element non-bridge
        otherwise, error('dali:acots', 'Unknown cand_mode %s', cfg.acots.cand_mode);
    end
    cand = find(keep);
    fprintf(['===== Stage %d: %d candidate openings (%s; %d lines + %d transformers; bridges and forbidden excluded) ', ...
        '| already open: %s =====\n'], s, numel(cand), cfg.acots.cand_mode, sum(isline(cand)), sum(~isline(cand)), dali_rows2str(opened));
    tw = tic;
    recs = cell(numel(cand), 1);
    if usepar
        parfor j = 1:numel(cand)
            recs{j} = one_case(mpc, init, meta, cfg, vpen, [opened(:); cand(j)], cand(j), Eref, isline(cand(j)));
        end
        for j = 1:numel(cand), recs{j}.new_bridges = newb(cand(j)); print_rec(recs{j}, j, numel(cand)); end
    else
        for j = 1:numel(cand)
            recs{j} = one_case(mpc, init, meta, cfg, vpen, [opened(:); cand(j)], cand(j), Eref, isline(cand(j)));
            recs{j}.new_bridges = newb(cand(j));
            print_rec(recs{j}, j, numel(cand));
        end
    end
    wall = toc(tw);
    tab = [recs{:}];
    Tm.enum_wall_s = Tm.enum_wall_s + wall;
    Tm.enum_sum_s = Tm.enum_sum_s + sum([tab.time_s]);
    nopf = nopf + numel(tab);
    ok = [tab.converged] == 1;
    ts = [tab.time_s];
    fprintf(['  stage %d: %d AC-OPFs in %.1f s wall (sum %.1f s) | per OPF mean %.2f s, median %.2f s, max %.2f s | ', ...
        'converged %d/%d | improving openings %d\n'], s, numel(tab), wall, sum(ts), mean(ts), median(ts), max(ts), ...
        sum(ok), numel(tab), sum(ok & [tab.dJ_AC] < -1e-6));
    fprintf('  time split: converged %d OPFs %.1f s (mean %.2f s) | not converged %d OPFs %.1f s (mean %.2f s, incl. fallback re-solve)\n', ...
        sum(ok), sum(ts(ok)), mean(ts(ok)), sum(~ok), sum(ts(~ok)), mean(ts(~ok)));
    [~, o] = sort([tab.dJ_AC]);
    o = o(isfinite([tab(o).dJ_AC]));
    fprintf('  best openings at this stage (dJ_AC relative to the current topology):\n');
    for q = 1:min(cfg.acots.show_top, numel(o))
        rr = tab(o(q));
        fprintf('    %2d. row %4d (%d-%d, %s, %g/%g kV): dJ_AC %+9.4f $/h | dLoss %+8.3f MW | dViol %+8.4f pu | 110/35kV %.1f%% | new bridges %d\n', ...
            q, rr.row, rr.from_bus, rr.to_bus, rr.type, rr.kv_from, rr.kv_to, rr.dJ_AC, rr.dLoss_MW, rr.dViol_pu, rr.tbVQ_pct, rr.new_bridges);
    end
    sf = o([tab(o).new_bridges] == 0);
    fprintf('  best openings that keep N-1 connectivity (no new bridge): %d of %d\n', numel(sf), numel(o));
    for q = 1:min(cfg.acots.show_top, numel(sf))
        rr = tab(sf(q));
        fprintf('    %2d. row %4d (%d-%d, %s, %g/%g kV): dJ_AC %+9.4f $/h | dLoss %+8.3f MW | dViol %+8.4f pu | 110/35kV %.1f%%\n', ...
            q, rr.row, rr.from_bus, rr.to_bus, rr.type, rr.kv_from, rr.kv_to, rr.dJ_AC, rr.dLoss_MW, rr.dViol_pu, rr.tbVQ_pct);
    end
    stages{end+1} = tab; %#ok<AGROW>
    if cfg.acots.n1_constrained                        % N-1 constrained: check candidates in order of dJ_AC
        tn1 = tic;
        if cfg.acots.require_n1safe, plist = sf; else, plist = o; end
        plist = plist([tab(plist).dJ_AC] < -cfg.acots.min_gain);
        fprintf('\n===== N-1 stage: static AC N-1 of %d improving candidates in order of dJ_AC (check all %d) =====\n', ...
            numel(plist), cfg.acots.n1_check_all);
        n1log = struct('row', {}, 'type', {}, 'dJ_AC', {}, 'pass', {}, 'emerg_pct', {}, 'incr_pct', {}, ...
            'islands_load', {}, 'nonconv', {}, 'time_s', {}, 'cum_time_s', {});
        sel = [];
        for q = 1:numel(plist)
            rr = tab(plist(q)); tq = tic;
            [mpoq, opfq] = dali_setup_opf(mpc, init, meta, cfg, vpen, [opened(:); rr.row]);
            cfgq = cfg; cfgq.opf.verbose = 0;
            [rq, iq] = dali_run_acopf(mpoq, opfq, cfgq, env, sprintf('N-1 candidate row %d', rr.row));
            if ~iq.success, continue; end
            Sq = dali_n1_check(mpc, rq, [opened(:); rr.row], opfq, meta, cfg, sprintf('ACOTS_N1_row%d', rr.row));
            pass = strcmp(Sq.status, 'EVALUATED') && Sq.n_fail_nonconv == 0 && ...
                Sq.pass_rate_emergency_pct >= Sb.pass_rate_emergency_pct - 1e-9 && ...
                Sq.n_islands_load_gt_1MW <= Sb.n_islands_load_gt_1MW;
            n1log(end+1) = struct('row', rr.row, 'type', rr.type, 'dJ_AC', rr.dJ_AC, 'pass', double(pass), ...
                'emerg_pct', Sq.pass_rate_emergency_pct, 'incr_pct', Sq.pass_rate_incremental_pct, ...
                'islands_load', Sq.n_islands_load_gt_1MW, 'nonconv', Sq.n_fail_nonconv, 'time_s', toc(tq), ...
                'cum_time_s', toc(tn1)); %#ok<AGROW>
            fprintf(['  => row %d (%s, dJ_AC %+.4f): N-1 emergency %.1f%% (base %.1f%%) | incremental %.1f%% | ', ...
                'load-cutting islanding elements %d (base %d) | nonconv %d -> %s | %.1f s\n'], rr.row, rr.type, rr.dJ_AC, ...
                Sq.pass_rate_emergency_pct, Sb.pass_rate_emergency_pct, Sq.pass_rate_incremental_pct, ...
                Sq.n_islands_load_gt_1MW, Sb.n_islands_load_gt_1MW, Sq.n_fail_nonconv, ternary(pass, 'PASS', 'FAIL'), toc(tq));
            if pass && isempty(sel)
                sel = rr.row; rsel = rq; opfsel = opfq; Tm.n1_time_to_first_pass_s = toc(tn1);
            end
            if ~isempty(sel) && ~cfg.acots.n1_check_all, break; end
        end
        Tm.n1_stage_s = toc(tn1);
        if ~isempty(sel)
            opened(end+1) = sel; init = rsel; opfref = opfsel; %#ok<AGROW>
            Eref = dali_eval_ac(rsel, meta, cfg, vpen, 'acots_n1_selected', opfsel);
        else
            fprintf('  no improving candidate passes N-1: keep the base topology\n');
        end
        break;
    end
    % the stage winner: overall best, or best N-1-connectivity-safe when cfg.acots.require_n1safe
    if cfg.acots.require_n1safe, pick = sf; else, pick = o; end
    if isempty(pick) || tab(pick(1)).dJ_AC >= -cfg.acots.min_gain
        fprintf('  no admissible opening improves J_AC by more than %g $/h: stop\n', cfg.acots.min_gain);
        break;
    end
    kbest = tab(pick(1)).row;
    opened(end+1) = kbest; %#ok<AGROW>
    [mpob, opfb] = dali_setup_opf(mpc, init, meta, cfg, vpen, opened);
    cfgq = cfg; cfgq.opf.verbose = 0;
    [rb, ib] = dali_run_acopf(mpob, opfb, cfgq, env, sprintf('AC-OTS stage %d best: open %s', s, dali_rows2str(opened)));
    if ~ib.success, fprintf(2, '  re-solve of the best topology failed: stop\n'); opened(end) = []; break; end
    init = rb; Eref = dali_eval_ac(rb, meta, cfg, vpen, sprintf('acots_stage%d', s), opfb); opfref = opfb;
end
Tm.total_search_s = Tm.base_opf_s + Tm.enum_wall_s;
Tm.total_n1_constrained_s = Tm.base_opf_s + Tm.bridge_screen_s + Tm.enum_wall_s + Tm.n1_base_s + Tm.n1_stage_s;

%% ---------------- result ----------------
Ebest = Eref;
fprintf('\n===== Full AC-OTS result (%s, kmax %d, require N-1 connectivity %d) =====\n', cfg.acots.cand_mode, ...
    cfg.acots.kmax, cfg.acots.require_n1safe);
fprintf('  opened: %s | J_AC %.4f -> %.4f $/h (%+.4f) | loss %.3f -> %.3f MW | voltage violation %.4f -> %.4f pu | 110/35kV %.1f%% -> %.1f%%\n', ...
    dali_rows2str(opened), E0.J_AC, Ebest.J_AC, Ebest.J_AC - E0.J_AC, E0.loss_MW, Ebest.loss_MW, ...
    E0.sum_v_viol_opf_scope, Ebest.sum_v_viol_opf_scope, E0.tb_vq_rate_110_35kV_pct, Ebest.tb_vq_rate_110_35kV_pct);
tab1 = stages{1};
ref_rows = [150 151];                                  % P0: COPT proxy choices (taskbook voltage band)
for k = ref_rows
    jj = find([tab1.row] == k, 1);
    if ~isempty(jj)
        rk = sum([tab1.dJ_AC] < tab1(jj).dJ_AC);
        rks = sum([tab1.dJ_AC] < tab1(jj).dJ_AC & [tab1.new_bridges] == 0);
        fprintf('  P0 COPT proxy choice row %d: dJ_AC %+.4f $/h | rank %d of %d overall, rank %d among N-1-connectivity-safe openings\n', ...
            k, tab1(jj).dJ_AC, rk + 1, sum(isfinite([tab1.dJ_AC])), rks + 1);
    end
end
inN1 = ismember([tab1.row], meta.cand_rows);
if any(inN1)
    d8 = [tab1(inN1).dJ_AC]; dall = [tab1.dJ_AC]; dsafe = dall([tab1.new_bridges] == 0);
    fprintf('  best within the 8 P0 candidates: %+.4f $/h | best N-1-connectivity-safe: %+.4f $/h | best overall: %+.4f $/h\n', ...
        min(d8), min(dsafe), min(dall));
end
ns = numel(tab1);
mt = mean([tab1.time_s]);
fprintf(['  exact enumeration of every pair of openings would need C(%d,2) = %d AC-OPFs, about %.1f h at %.2f s each ', ...
    '(single-thread)\n'], ns, nchoosek(ns, 2), nchoosek(ns, 2) * mt / 3600, mt);

%% ---------------- optional static N-1 of base and best ----------------
if cfg.acots.n1 && ~cfg.acots.n1_constrained
    tn = tic;
    dali_n1_check(mpc, r0, [], opf0, meta, cfg, 'ACOTS_base_no_switching');
    if ~isempty(opened)
        dali_n1_check(mpc, init, opened, opfref, meta, cfg, sprintf('ACOTS_best_open_%s', strrep(dali_rows2str(opened), ' ', '')));
    end
    Tm.n1_s = toc(tn);
end

%% ---------------- outputs ----------------
for s = 1:numel(stages)
    writetable(struct2table(stages{s}), fullfile(cfg.outdir, sprintf('ACOTS_stage%d_enumeration.csv', s)));
end
Tm.total_s = toc(t_all);
fid = fopen(fullfile(cfg.outdir, 'ACOTS_summary.txt'), 'w');
fprintf(fid, 'cand_mode %s | kmax %d | require_n1safe %d | candidates stage1 %d | AC-OPFs %d | opened %s\n', ...
    cfg.acots.cand_mode, cfg.acots.kmax, cfg.acots.require_n1safe, ns, nopf, dali_rows2str(opened));
fprintf(fid, 'J_AC base %.4f best %.4f | loss base %.3f best %.3f MW | viol base %.4f best %.4f pu\n', E0.J_AC, Ebest.J_AC, ...
    E0.loss_MW, Ebest.loss_MW, E0.sum_v_viol_opf_scope, Ebest.sum_v_viol_opf_scope);
fprintf(fid, 'time: base OPF %.2f s | enumeration wall %.1f s (sum %.1f s) | bridge screen %.2f s | search total %.1f s | parallel %d\n', ...
    Tm.base_opf_s, Tm.enum_wall_s, Tm.enum_sum_s, Tm.bridge_screen_s, Tm.total_search_s, usepar);
fclose(fid);
fprintf('\n  >>> full AC-OTS time (base AC-OPF + all candidate AC-OPFs): %.1f s for %d AC-OPFs (parallel %d)\n', ...
    Tm.total_search_s, nopf + 1, usepar);
if cfg.acots.n1_constrained
    fprintf(['  >>> N-1 constrained full AC-OTS time: %.1f s = base OPF %.1f + connectivity screen %.2f + %d candidate AC-OPFs %.1f ', ...
        '+ base N-1 %.1f + candidate N-1 checks %.1f\n'], Tm.total_n1_constrained_s, Tm.base_opf_s, Tm.bridge_screen_s, ...
        numel(tab1), Tm.enum_wall_s, Tm.n1_base_s, Tm.n1_stage_s);
    if ~isempty(n1log), writetable(struct2table(n1log), fullfile(cfg.outdir, 'ACOTS_n1_checks.csv')); end
end
dali_acots_report(cfg, Tm, E0, Ebest, opened, tab1, n1log, Sb, mpc, meta);
fprintf('\nTimings (s):\n'); disp(Tm);
fprintf('\n===== DONE. Upload %s (ACOTS_log_*, ACOTS_stage*_enumeration.csv, ACOTS_summary.txt) =====\n', cfg.outdir);
end

%% =======================================================================
function rec = one_case(mpc, init, meta, cfg, vpen, open, k, Eref, isline_k)
tj = tic;
[mpo, opfs] = dali_setup_opf(mpc, init, meta, cfg, vpen, open);
mpopt = mpoption('opf.ac.solver', cfg.opf.solver, 'verbose', 0, 'out.all', 0, ...
    'opf.flow_lim', opfs.flow_lim, 'mips.max_it', cfg.opf.max_it);
mpopt = try_opt(mpopt, 'opf.softlims.default', 0);
mpopt = try_opt(mpopt, 'opf.start', 2);
r = safe_runopf(mpo, mpopt);
att = 'MIPS';
if ~r.success
    r2 = safe_runopf(mpo, mpoption(mpopt, 'mips.step_control', 1));
    att = 'MIPS>MIPS-sc';
    if r2.success, r = r2; end
end
it = NaN;
try, it = r.raw.output.iterations; catch, end
E = dali_eval_ac(r, meta, cfg, vpen, sprintf('acots_row%d', k), opfs);
if isline_k, ty = 'line'; else, ty = 'xfmr'; end
rec = struct('row', k, 'from_bus', meta.ids(meta.f(k)), 'to_bus', meta.ids(meta.t(k)), 'type', ty, ...
    'kv_from', meta.base_kv(meta.f(k)), 'kv_to', meta.base_kv(meta.t(k)), 'converged', E.converged, ...
    'attempts', att, 'iterations', it, 'J_AC', E.J_AC, 'dJ_AC', E.J_AC - Eref.J_AC, ...
    'loss_MW', E.loss_MW, 'dLoss_MW', E.loss_MW - Eref.loss_MW, ...
    'viol_pu', E.sum_v_viol_opf_scope, 'dViol_pu', E.sum_v_viol_opf_scope - Eref.sum_v_viol_opf_scope, ...
    'tbVQ_pct', E.tb_vq_rate_110_35kV_pct, 'time_s', toc(tj), 'new_bridges', NaN);
end

function print_rec(r, j, n)
fprintf('  [%3d/%3d] row %4d (%d-%d, %s): conv %d | dJ_AC %+9.4f $/h | dLoss %+8.3f MW | dViol %+8.4f pu | new br %d | %4g it | %.2f s\n', ...
    j, n, r.row, r.from_bus, r.to_bus, r.type, r.converged, r.dJ_AC, r.dLoss_MW, r.dViol_pu, r.new_bridges, r.iterations, r.time_s);
end

function mpopt = try_opt(mpopt, name, val)
try
    mpopt = mpoption(mpopt, name, val);
catch
end
end

function res = safe_runopf(mpo, mpopt)
try
    res = runopf(mpo, mpopt);
catch
    res = struct('success', 0, 'f', NaN);
end
end

function s = ternary(c, a, b)
if c, s = a; else, s = b; end
end
