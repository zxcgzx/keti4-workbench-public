function dali_acots_report(cfg, Tm, E0, Ebest, opened, tab1, n1log, Sb, mpc, meta)
%DALI_ACOTS_REPORT  生成完整 AC-OTS 的汇报（Markdown，UTF-8），数字全部来自本次运行；
%   若 cfg.acots.prev_csv 给出上一次“不带 N-1 约束、全部非桥支路”的结果，则一并汇总对比。
define_constants;
fn = fullfile(cfg.outdir, 'ACOTS_report.md');
fid = fopen(fn, 'w', 'n', 'UTF-8');
w = @(varargin) fprintf(fid, varargin{:});

%% previous unconstrained run (optional)
P = [];
if isfield(cfg.acots, 'prev_csv') && ~isempty(cfg.acots.prev_csv) && exist(cfg.acots.prev_csv, 'file')
    T = readtable(cfg.acots.prev_csv);
    nb = size(mpc.bus, 1);
    on = mpc.branch(:, BR_STATUS) > 0;
    isbr = dali_bridges(nb, meta.f, meta.t, on);
    nbz = nan(height(T), 1);
    for j = 1:height(T)
        on2 = on; on2(T.row(j)) = false;
        nbz(j) = sum(dali_bridges(nb, meta.f, meta.t, on2) & ~isbr);
    end
    ok = T.converged == 1;
    P.n = height(T); P.nconv = sum(ok); P.sum_s = sum(T.time_s); P.mean_s = mean(T.time_s);
    P.median_s = median(T.time_s); P.max_s = max(T.time_s); P.nimp = sum(ok & T.dJ_AC < -1e-6);
    [~, ib] = min(T.dJ_AC(ok)); Tok = T(ok, :); nbok = nbz(ok);
    P.best_row = Tok.row(ib); P.best_dJ = Tok.dJ_AC(ib); P.best_type = Tok.type{ib};
    P.best_kv = sprintf('%g/%g', Tok.kv_from(ib), Tok.kv_to(ib)); P.best_newbr = nbok(ib);
    P.best_dloss = Tok.dLoss_MW(ib); P.best_dviol = Tok.dViol_pu(ib);
    P.nsafe = sum(nbz == 0);
    P.top_newbr = nbok;  % for statement on the top openings
    [~, o] = sort(Tok.dJ_AC); P.ntop_bridge = sum(nbok(o(1:min(15, numel(o)))) > 0);
end

nsel = ~isempty(opened);
w('# 大理 905 节点断面：完整 AC-OTS 测试报告\n\n');
w('%s（程序 run_dali_acots，自动生成；硬件同 P0：i7-1165G7 笔记本，MATLAB R2022b + MATPOWER 8.0 MIPS，单线程）\n\n', ...
    datestr(now, 'yyyy-mm-dd HH:MM'));

%% 1. conclusion
w('## 1. 结论\n\n');
if ~isempty(P)
    w(['不加 N-1 约束时，对全部 %d 条可开断非桥支路逐条求完整非线性交流 OPF 共用时 %.0f s（约 %.1f 分钟），', ...
        '最优为断开第 %d 行（%s，%s kV），目标下降 %.2f $/h；但该操作新增 %d 个桥，削弱 N-1 冗余，', ...
        '目标改善最大的前 15 个开断中有 %d 个都会新增桥。\n\n'], P.n, P.sum_s + Tm.base_opf_s, (P.sum_s + Tm.base_opf_s) / 60, ...
        P.best_row, P.best_type, P.best_kv, -P.best_dJ, P.best_newbr, P.ntop_bridge);
end
if cfg.acots.n1_constrained
    if nsel
        w(['加入 N-1 约束后（先剔除会新增桥的开断，再对候选做静态交流 N-1 校验），完整 AC-OTS 用时 %.1f s，', ...
            '最优为断开第 %s 行，目标由 %.2f 降至 %.2f $/h（%+.2f），N-1 紧急判据通过率 %.1f%%，与基准相同。\n\n'], ...
            Tm.total_n1_constrained_s, dali_rows2str(opened), E0.J_AC, Ebest.J_AC, Ebest.J_AC - E0.J_AC, ...
            n1log(find([n1log.pass] == 1, 1)).emerg_pct);
    else
        w('加入 N-1 约束后，完整 AC-OTS 用时 %.1f s，没有既改善目标又通过 N-1 的开断，保持现有拓扑。\n\n', ...
            Tm.total_n1_constrained_s);
    end
end

%% 2. method
w('## 2. 方法\n\n');
w(['逐条断开候选支路，对每个拓扑求一次完整非线性交流 OPF（不做线性化、不用代理模型、不用 COPT），', ...
    '目标与 P0 相同：网损 × %g $/MWh + 电压越限 × %g $/p.u.（任务书电压口径），电流限值、机组无功与电压权限同 P0。', ...
    '候选为全部在运非桥支路（断开后不解列），扣除外网边界端点禁止开断的 1 条。'], cfg.obj.c_loss, cfg.acots.vpen);
w(['N-1 约束分两步：先剔除断开后会新增桥（使其他元件成为单点）的开断；再按目标改善从大到小，', ...
    '对候选拓扑做静态交流 N-1（≥110 kV 非桥线路与主变，紧急电压带 0.90–1.10、不新增越限与过载），', ...
    '要求全部收敛、紧急判据通过率不低于基准、故障后切负荷的解列元件不多于基准，第一个通过者即为最优。\n\n']);

%% 3. timing
w('## 3. 用时\n\n| 项目 | 用时 |\n| --- | --- |\n');
w('| 一次交流潮流（905 节点） | %.2f s |\n', Tm.one_acpf_s);
w('| 一次完整交流 OPF（基准拓扑） | %.2f s |\n', Tm.base_opf_s);
if ~isempty(Sb) && isfield(Sb, 'time_s'), w('| 一次静态交流 N-1（%d 个故障） | %.1f s |\n', Sb.n_contingencies, Sb.time_s); end
if ~isempty(P)
    w('| 不加 N-1：%d 次 OPF 合计（收敛 %d） | %.0f s（单次中位 %.2f s、平均 %.2f s、最长 %.1f s） |\n', ...
        P.n, P.nconv, P.sum_s, P.median_s, P.mean_s, P.max_s);
    w('| 不加 N-1：精确枚举两条开断（C(%d,2) = %d 次 OPF） | 估计约 %.0f h |\n', P.n, nchoosek(P.n, 2), ...
        nchoosek(P.n, 2) * P.mean_s / 3600);
end
if cfg.acots.n1_constrained
    if isempty(P), sn = '全部非桥'; else, sn = sprintf('%d', P.n); end
    w('| 加 N-1：连通性筛选（%s 条中保留 %d 条） | %.2f s |\n', sn, numel(tab1), Tm.bridge_screen_s);
    w('| 加 N-1：%d 次候选 OPF | %.1f s |\n', numel(tab1), Tm.enum_wall_s);
    w('| 加 N-1：基准 N-1 + %d 个候选的 N-1 校验 | %.1f s + %.1f s |\n', numel(n1log), Tm.n1_base_s, Tm.n1_stage_s);
    if isfield(Tm, 'n1_time_to_first_pass_s')
        w('| 加 N-1：找到第一个通过者为止 | %.1f s（候选 N-1 部分） |\n', Tm.n1_time_to_first_pass_s);
    end
    w('| **加 N-1 的完整 AC-OTS 合计** | **%.1f s** |\n', Tm.total_n1_constrained_s);
end
w('| 参考：P0 线性化代理 OTS（8 条候选，COPT） | 约 8–13 s |\n\n');

%% 4. results
w('## 4. 结果\n\n| 指标 | 基准（不开断） | 最优开断 %s |\n| --- | --- | --- |\n', dali_rows2str(opened));
w('| 目标 J_AC（$/h） | %.4f | %.4f |\n', E0.J_AC, Ebest.J_AC);
w('| 网损（MW） | %.3f | %.3f |\n', E0.loss_MW, Ebest.loss_MW);
w('| 电压越限量（p.u.） | %.4f | %.4f |\n', E0.sum_v_viol_opf_scope, Ebest.sum_v_viol_opf_scope);
w('| 110/35 kV 电压合格率 | %.1f%% | %.1f%% |\n', E0.tb_vq_rate_110_35kV_pct, Ebest.tb_vq_rate_110_35kV_pct);
if ~isempty(Sb) && ~isempty(n1log) && nsel
    k = find([n1log.pass] == 1, 1);
    w('| N-1 紧急判据通过率 | %.1f%% | %.1f%% |\n', Sb.pass_rate_emergency_pct, n1log(k).emerg_pct);
    w('| N-1 窄带增量判据通过率 | %.1f%% | %.1f%% |\n', Sb.pass_rate_incremental_pct, n1log(k).incr_pct);
    w('| 故障后切负荷的解列元件数 | %d | %d |\n', Sb.n_islands_load_gt_1MW, n1log(k).islands_load);
end
w('\n');
if ~isempty(P)
    w(['不加 N-1 的全集最优为第 %d 行（%s，%s kV）：目标 %+.4f $/h、网损 %+.3f MW、电压越限 %+.4f p.u.，新增桥 %d 个；', ...
        '全部 %d 条候选中只有 %d 条断开后不新增桥。\n\n'], P.best_row, P.best_type, P.best_kv, P.best_dJ, P.best_dloss, ...
        P.best_dviol, P.best_newbr, P.n, P.nsafe);
end
if ~isempty(n1log)
    w('N-1 校验明细（按目标改善排序）：\n\n| 行号 | 类型 | ΔJ_AC（$/h） | N-1 紧急 | N-1 增量 | 切负荷解列元件 | 结论 | 用时 |\n| --- | --- | --- | --- | --- | --- | --- | --- |\n');
    for q = 1:numel(n1log)
        L = n1log(q);
        w('| %d | %s | %+.4f | %.1f%% | %.1f%% | %d | %s | %.1f s |\n', L.row, L.type, L.dJ_AC, L.emerg_pct, L.incr_pct, ...
            L.islands_load, ternary(L.pass == 1, '通过', '不通过'), L.time_s);
    end
    w('\n');
end

%% 5. caveats
w('## 5. 口径说明\n\n');
w(['每个拓扑的交流 OPF 是非凸问题，MIPS 给出局部最优；“完整”指离散开断在候选集内精确穷举（每次断开一条）。', ...
    'N-1 为开断后的静态交流校验，故障后不重新优化控制量（非 SCOPF）。电压限值、事故电压带、额定值单位、外网等值', ...
    '与 905/666 节点映射仍为待数据方确认的假设，结果为诊断性结果。嘉明老师团队在该模型上目前只做过常规潮流', ...
    '（约零点几秒），尚无 OPF/OTS 结果可对比。\n']);
fclose(fid);
fprintf('  report written: %s\n', fn);
end

function s = ternary(c, a, b)
if c, s = a; else, s = b; end
end
