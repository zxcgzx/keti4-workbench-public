function dali_acots_post(csvfile)
%DALI_ACOTS_POST  对已完成的完整 AC-OTS 结果做后处理（不重跑 OPF，几秒钟）：
%   (1) 逐条计算开断后新增的桥数（N-1 连通性），给出“保持 N-1 连通性”的开断排名；
%   (2) 按收敛与否拆分用时。
%   例：dali_acots_post('out_ACOTS_nonbridge_k1_taskbook_proxy\ACOTS_stage1_enumeration.csv')
here = fileparts(mfilename('fullpath'));
addpath(here);
define_constants;
cfg = dali_p0_config();
T = readtable(csvfile);
raw = dali_read_pasexp(cfg.txtfile);
topo = dali_topology_audit(raw, cfg);
[mpc, ~, meta] = dali_build_case(raw, topo, cfg);
nb = size(mpc.bus, 1); nl = size(mpc.branch, 1);
on = mpc.branch(:, BR_STATUS) > 0;
isbr = dali_bridges(nb, meta.f, meta.t, on);
newb = nan(height(T), 1);
for j = 1:height(T)
    on2 = on; on2(T.row(j)) = false;
    newb(j) = sum(dali_bridges(nb, meta.f, meta.t, on2) & ~isbr);
end
T.new_bridges = newb;
ok = T.converged == 1;
fprintf('\n%d openings, converged %d | N-1 connectivity kept (no new bridge): %d (lines %d, transformers %d)\n', ...
    height(T), sum(ok), sum(newb == 0), sum(newb == 0 & strcmp(T.type, 'line')), sum(newb == 0 & strcmp(T.type, 'xfmr')));
fprintf('time: total %.1f s | converged %.1f s (mean %.2f, median %.2f) | not converged %d: %.1f s (mean %.2f)\n', ...
    sum(T.time_s), sum(T.time_s(ok)), mean(T.time_s(ok)), median(T.time_s(ok)), sum(~ok), sum(T.time_s(~ok)), mean(T.time_s(~ok)));
S = sortrows(T(ok, :), 'dJ_AC');
fprintf('\nbest 10 overall:\n');
disp(S(1:min(10, height(S)), {'row', 'from_bus', 'to_bus', 'type', 'kv_from', 'kv_to', 'dJ_AC', 'dLoss_MW', 'dViol_pu', 'tbVQ_pct', 'new_bridges'}));
Ss = S(S.new_bridges == 0, :);
fprintf('openings that keep N-1 connectivity (%d), ranked:\n', height(Ss));
disp(Ss(:, {'row', 'from_bus', 'to_bus', 'type', 'kv_from', 'kv_to', 'dJ_AC', 'dLoss_MW', 'dViol_pu', 'tbVQ_pct'}));
fprintf('not converged rows: %s\n', mat2str(T.row(~ok).'));
[p, n] = fileparts(csvfile);
writetable(T, fullfile(p, [n '_with_n1flag.csv']));
fprintf('written: %s\n', fullfile(p, [n '_with_n1flag.csv']));
end
