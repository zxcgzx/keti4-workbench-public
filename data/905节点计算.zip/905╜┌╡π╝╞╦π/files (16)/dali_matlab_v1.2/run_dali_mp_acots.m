function run_dali_mp_acots(varargin)
%RUN_DALI_MP_ACOTS  16 时段“完整 AC-OTS + 机组出力 + N-1”基准（Baseline，不追求时间）。
%   每个时段、每种拓扑（不开断 + 断开后不新增桥的单条开断）求一次完整非线性交流 OPF（MATPOWER MIPS），
%   同时调整可调机组有功（±20%，与平衡机同价，即最小化网损）与无功/电压；开关序列在时间方向用动态规划
%   精确求解（全程动作 <= mp.max_actions，动作后保持 >= mp.min_hold 个时段，与线性化多时段模型同一约束）；
%   N-1 采用懒校验：对 DP 最优路径上的拓扑做静态交流 N-1，不通过则剔除并重新规划，直到每个时段都通过。
%   分接头保持当前挡位（完整交流下的离散挡位是 MINLP，现有工具不解）。最后自动生成汇报 md。
%
%   例：run_dali_mp_acots
%       run_dali_mp_acots('mpac.cand_mode', 'nonbridge')   % 每时段 225 种拓扑（约 3600 次 OPF，数小时）

here = fileparts(mfilename('fullpath'));
addpath(here);
cfg = dali_p0_config();
cfg.vlim.opf_source = 'taskbook_proxy';
if mod(numel(varargin), 2) ~= 0
    error('dali:mpac', 'Overrides must be name/value pairs');
end
for i = 1:2:numel(varargin)
    fpath = strsplit(varargin{i}, '.');
    cfg = setfield(cfg, fpath{:}, varargin{i+1}); %#ok<SFLD>
end
if isempty(cfg.outdir)
    cfg.outdir = fullfile(here, sprintf('out_MPACOTS_T%d_%s', cfg.mp.T, cfg.mpac.cand_mode));
end
if ~exist(cfg.outdir, 'dir'), mkdir(cfg.outdir); end
stamp = datestr(now, 'yyyymmdd_HHMMSS');
logf = fullfile(cfg.outdir, ['MPAC_log_' stamp '.txt']);
diary(logf);
cleaner = onCleanup(@() diary('off')); %#ok<NASGU>
fprintf('Dali 16-period full AC-OTS baseline (AC-OPF per period x topology, DP over switching, lazy N-1) run %s (package v1.2)\n', stamp);
for i = 1:2:numel(varargin)
    fprintf('  override: %s = %s\n', varargin{i}, mat2str(varargin{i+1}));
end
try
    main_mpac(cfg);
catch err
    fprintf(2, '\n*** RUN FAILED ***\n%s\n', getReport(err, 'extended', 'hyperlinks', 'off'));
    fprintf('\nPlease upload the log file: %s\n', logf);
end
end

%% =======================================================================
function main_mpac(cfg)
define_constants;
Tm = struct();
t_all = tic;
env = dali_p0_step0_env(cfg);
if ~env.matpower_ok, error('dali:mpac', 'MATPOWER >= 7 required'); end
raw = dali_read_pasexp(cfg.txtfile);
topo = dali_topology_audit(raw, cfg);
[mpc, ~, meta] = dali_build_case(raw, topo, cfg);
[pf0, ~] = dali_run_acpf(mpc, meta, 'equivalent_v1', false, false);
vpen = cfg.mp.vpen;
[mpo, opfset] = dali_setup_opf(mpc, pf0, meta, cfg, vpen, []);
[r1, i1] = dali_run_acopf(mpo, opfset, cfg, env, 'period-0 controls (S1)');
if ~i1.success, error('dali:mpac', 'S1 AC-OPF failed'); end
Tm.prep_s = toc(t_all);

%% ---------------- periods (same data as run_dali_mp) ----------------
T = cfg.mp.T; dt = cfg.mp.dt_h;
lam = linspace(cfg.mp.load_start, cfg.mp.load_end, T);
sel = mpc.bus(:, PD) > 0 & meta.base_kv <= cfg.mp.load_kv_max & ~meta.is_boundary;
gon = mpc.gen(:, GEN_STATUS) > 0;
dispg = gon & ~ismember(mpc.gen(:, GEN_BUS), cfg.boundary.buses) & meta.snap_gen_PG >= cfg.mp.disp_min_MW;
dispg(opfset.slackgen) = false;
pg_init = r1.gen(:, PG);
Rr = cfg.mp.ramp_frac * abs(pg_init);
lo_all = (1 - cfg.mp.disp_range) * pg_init; hi_all = (1 + cfg.mp.disp_range) * pg_init;
lo1 = max(lo_all, pg_init - Rr); hi1 = min(hi_all, pg_init + Rr);       % period 1 also respects the ramp from S1
m0 = mpc; m0.gen(:, QMIN) = opfset.qmin; m0.gen(:, QMAX) = opfset.qmax;
mpopt_pf = mpoption('pf.alg', 'NR', 'pf.tol', 1e-8, 'pf.nr.max_it', 30, 'verbose', 0, 'out.all', 0, 'pf.enforce_q_lims', 1);
cases = cell(1, T); bases = cell(1, T);
tb = tic;
for t = 1:T
    mt = m0;
    mt.bus(sel, PD) = mpc.bus(sel, PD) * lam(t);
    mt.bus(sel, QD) = mpc.bus(sel, QD) * lam(t);
    cases{t} = mt;
    rt = runpf(dali_pf_case_from_state(mt, r1, meta, []), mpopt_pf);
    if ~rt.success, error('dali:mpac', 'Base ACPF failed at period %d', t); end
    bases{t} = rt;
end
Tm.period_acpf_s = toc(tb);
fprintf('\n===== %d periods (load x%.3f -> x%.3f) | dispatchable units %d (%.1f MW, +-%.0f%%, ramp %.0f%%/period) | base PFs %.2f s =====\n', ...
    T, lam(1), lam(end), sum(dispg), sum(pg_init(dispg)), 100 * cfg.mp.disp_range, 100 * cfg.mp.ramp_frac, Tm.period_acpf_s);

%% ---------------- topology states ----------------
tsc = tic;
nb = size(mpc.bus, 1); nl = size(mpc.branch, 1);
on = mpc.branch(:, BR_STATUS) > 0;
isbr = dali_bridges(nb, meta.f, meta.t, on);
keep = on & ~isbr & ~topo.forbidden;
if strcmpi(cfg.mpac.cand_mode, 'n1safe')
    for k = find(keep).'
        on2 = on; on2(k) = false;
        if any(dali_bridges(nb, meta.f, meta.t, on2) & ~isbr), keep(k) = false; end
    end
end
cand = find(keep);
S = numel(cand) + 1;                                   % state 1 = no opening, state s = open cand(s-1)
Tm.topology_screen_s = toc(tsc);
fprintf('  topology states per period: %d (no opening + %d single openings, mode %s; screen %.2f s)\n', ...
    S, numel(cand), cfg.mpac.cand_mode, Tm.topology_screen_s);

%% ---------------- stage costs: full AC-OPF for every period x topology ----------------
fprintf('\n===== Stage costs: %d x %d = %d full AC-OPFs =====\n', T, S, T * S);
J = inf(T, S); Jloss = nan(T, S); Jviol = nan(T, S); Jvq = nan(T, S); topf = nan(T, S);
RES = cell(T, S); OPFS = cell(T, S);
to = tic;
for t = 1:T
    if t == 1, lo = lo1; hi = hi1; else, lo = lo_all; hi = hi_all; end
    for s = 1:S
        if s == 1, open = []; else, open = cand(s - 1); end
        [rm, opfs, E, ts] = solve_period_opf(cases{t}, bases{t}, meta, cfg, vpen, open, dispg, lo, hi);
        topf(t, s) = ts;
        if E.converged
            J(t, s) = E.J_AC; Jloss(t, s) = E.loss_MW; Jviol(t, s) = E.sum_v_viol_opf_scope; Jvq(t, s) = E.tb_vq_rate_110_35kV_pct;
            RES{t, s} = rm; OPFS{t, s} = opfs;
        end
    end
    [~, sb] = min(J(t, :));
    fprintf('  t%02d x%.3f: %d/%d OPFs converged | no opening J %.3f $/h | best single opening %s J %.3f $/h (%+.3f) | %.1f s\n', ...
        t, lam(t), sum(isfinite(J(t, :))), S, J(t, 1), ternary(sb == 1, '-', sprintf('row %d', cand(max(sb - 1, 1)))), ...
        J(t, sb), J(t, sb) - J(t, 1), sum(topf(t, :)));
    if ~isfinite(J(t, 1)), error('dali:mpac', 'AC-OPF without switching failed at period %d', t); end
end
Tm.opf_stage_s = toc(to); Tm.n_opf = T * S;
fprintf('  stage costs: %d AC-OPFs in %.1f s (mean %.2f s, median %.2f s, max %.2f s), converged %d\n', T * S, Tm.opf_stage_s, ...
    mean(topf(:)), median(topf(:)), max(topf(:)), sum(isfinite(J(:))));

%% ---------------- DP over switching sequences with lazy N-1 ----------------
fprintf('\n===== DP over switching sequences (actions <= %d, hold >= %d periods) with lazy static AC N-1 =====\n', ...
    cfg.mp.max_actions, cfg.mp.min_hold);
n1st = zeros(T, S);                                    % 0 unknown, 1 pass, -1 fail
SB = cell(T, 1); SC = cell(T, S);
Tm.dp_s = 0; Tm.n1_s = 0; nn1 = 0; it = 0;
while true
    it = it + 1;
    td = tic;
    Jc = J; Jc(n1st == -1) = inf;
    [path, cost] = dp_path(Jc, dt, cfg.mp.min_hold, cfg.mp.max_actions, cfg.mp.action_cost);
    Tm.dp_s = Tm.dp_s + toc(td);
    if ~isfinite(cost), error('dali:mpac', 'DP found no feasible switching sequence'); end
    fprintf('  DP iteration %d: horizon cost %.3f $ | path %s\n', it, cost, path_str(path, cand));
    changed = false;
    for t = 1:T
        s = path(t);
        tn = tic;
        if isempty(SB{t})
            SB{t} = dali_n1_check(cases{t}, RES{t, 1}, [], OPFS{t, 1}, meta, cfg, sprintf('MPAC_t%02d_no_opening', t));
            nn1 = nn1 + 1;
        end
        if s > 1 && n1st(t, s) == 0
            Sx = dali_n1_check(cases{t}, RES{t, s}, cand(s - 1), OPFS{t, s}, meta, cfg, sprintf('MPAC_t%02d_open_%d', t, cand(s - 1)));
            nn1 = nn1 + 1;
            SC{t, s} = Sx;
            pass = strcmp(Sx.status, 'EVALUATED') && Sx.n_fail_nonconv == 0 && ...
                Sx.pass_rate_emergency_pct >= SB{t}.pass_rate_emergency_pct - 1e-9 && ...
                Sx.n_islands_load_gt_1MW <= SB{t}.n_islands_load_gt_1MW;
            n1st(t, s) = 2 * pass - 1;
            fprintf('    t%02d open row %d: N-1 emergency %.1f%% (no opening %.1f%%), load-cutting islanding %d (%d) -> %s\n', ...
                t, cand(s - 1), Sx.pass_rate_emergency_pct, SB{t}.pass_rate_emergency_pct, Sx.n_islands_load_gt_1MW, ...
                SB{t}.n_islands_load_gt_1MW, ternary(pass, 'PASS', 'FAIL'));
            if ~pass, changed = true; end
        end
        Tm.n1_s = Tm.n1_s + toc(tn);
    end
    if ~changed, break; end
end
Tm.n_n1_checks = nn1; Tm.dp_iterations = it;

%% ---------------- final decision, ramp check, per-period table ----------------
dpg = zeros(sum(dispg), T); prev = pg_init(dispg); ramp_ratio = zeros(1, T);
P = struct('t', {}, 'load_factor', {}, 'open_row', {}, 'J_AC', {}, 'J_AC_no_opening', {}, 'loss_MW', {}, ...
    'loss_no_opening_MW', {}, 'viol_pu', {}, 'vq_pct', {}, 'n1_emergency_pct', {}, 'n1_incremental_pct', {}, ...
    'n1_load_cutting_islanding', {}, 'n1_status', {}, 'disp_pg_MW', {}, 'ramp_use_max', {});
fprintf('\n===== Final 16-period decision =====\n');
for t = 1:T
    s = path(t);
    g = RES{t, s}.gen(dispg, PG);
    ramp_ratio(t) = max(abs(g - prev) ./ max(Rr(dispg), 1e-6));
    prev = g; dpg(:, t) = g;
    if s == 1
        Sx = SB{t}; orow = 0; st = 'reference';
    else
        Sx = SC{t, s}; orow = cand(s - 1); st = 'PASS';
    end
    P(end+1) = struct('t', t, 'load_factor', lam(t), 'open_row', orow, 'J_AC', J(t, s), 'J_AC_no_opening', J(t, 1), ...
        'loss_MW', Jloss(t, s), 'loss_no_opening_MW', Jloss(t, 1), 'viol_pu', Jviol(t, s), 'vq_pct', Jvq(t, s), ...
        'n1_emergency_pct', Sx.pass_rate_emergency_pct, 'n1_incremental_pct', Sx.pass_rate_incremental_pct, ...
        'n1_load_cutting_islanding', Sx.n_islands_load_gt_1MW, 'n1_status', st, 'disp_pg_MW', sum(g), ...
        'ramp_use_max', ramp_ratio(t)); %#ok<AGROW>
    fprintf(['  t%02d x%.3f | open %-5s | J %.3f (no opening %.3f) $/h | loss %.2f MW | viol %.4f pu | 110/35kV %.1f%% | ', ...
        'N-1 emergency %.1f%% incremental %.1f%% | disp %.1f MW | ramp use %.2f\n'], t, lam(t), ...
        ternary(orow == 0, '-', sprintf('%d', orow)), J(t, s), J(t, 1), Jloss(t, s), Jviol(t, s), Jvq(t, s), ...
        Sx.pass_rate_emergency_pct, Sx.pass_rate_incremental_pct, sum(g), ramp_ratio(t));
end
acts = sum(arrayfun(@(t) nact(ternary(t == 1, 1, path(max(t - 1, 1))), path(t)), 1:T));
Jsum = dt * sum(J(sub2ind(size(J), 1:T, path)));
J0sum = dt * sum(J(:, 1));
Tm.total_s = toc(t_all);
Tm.baseline_core_s = Tm.period_acpf_s + Tm.topology_screen_s + Tm.opf_stage_s + Tm.dp_s + Tm.n1_s;
nviol_ramp = sum(ramp_ratio > 1 + 1e-6);
fprintf(['\n  horizon: AC objective %.2f $ (no switching %.2f $, %+.2f) | energy loss %.2f MWh (no switching %.2f) | ', ...
    'switching actions %d | N-1 checks %d | ramp limit exceeded in %d periods (max use %.2f)\n'], Jsum, J0sum, Jsum - J0sum, ...
    dt * sum(Jloss(sub2ind(size(J), 1:T, path))), dt * sum(Jloss(:, 1)), acts, nn1, nviol_ramp, max(ramp_ratio));
fprintf(['  >>> 16-period full AC-OTS baseline time: %.1f s = period PFs %.1f + topology screen %.1f + %d AC-OPFs %.1f ', ...
    '+ DP %.2f + %d N-1 checks %.1f\n'], Tm.baseline_core_s, Tm.period_acpf_s, Tm.topology_screen_s, Tm.n_opf, ...
    Tm.opf_stage_s, Tm.dp_s, nn1, Tm.n1_s);

%% ---------------- outputs ----------------
writetable(struct2table(P), fullfile(cfg.outdir, 'MPAC_periods.csv'));
writetable(array2table([lam(:), J], 'VariableNames', [{'load_factor'}, {'no_opening'}, ...
    arrayfun(@(k) sprintf('open_%d', k), cand(:).', 'UniformOutput', false)]), fullfile(cfg.outdir, 'MPAC_stage_costs.csv'));
writematrix(n1st, fullfile(cfg.outdir, 'MPAC_n1_status.csv'));
write_report(cfg, Tm, P, cand, S, Jsum, J0sum, acts, nn1, nviol_ramp, max(ramp_ratio), lam, dispg, pg_init, dpg, dt);
fprintf('\nTimings (s):\n'); disp(Tm);
fprintf('\n===== DONE. Upload %s (MPAC_log_*, MPAC_periods.csv, MPAC_report.md) =====\n', cfg.outdir);
end

%% =======================================================================
function [rm, opfs, E, ts] = solve_period_opf(mc, init, meta, cfg, vpen, open, dispg, lo, hi)
define_constants;
tj = tic;
[mpo, opfs] = dali_setup_opf(mc, init, meta, cfg, vpen, open);
mpo.gen(dispg, PMIN) = lo(dispg);                      % dispatchable units: P free within the period bounds,
mpo.gen(dispg, PMAX) = hi(dispg);                      % same price as the slack -> objective = network loss
mpo.gencost(dispg, 5) = cfg.obj.c_loss;
opfs.pmin(dispg) = lo(dispg); opfs.pmax(dispg) = hi(dispg);
mpopt = mpoption('opf.ac.solver', cfg.opf.solver, 'verbose', 0, 'out.all', 0, ...
    'opf.flow_lim', opfs.flow_lim, 'mips.max_it', cfg.opf.max_it);
mpopt = try_opt(mpopt, 'opf.softlims.default', 0);
mpopt = try_opt(mpopt, 'opf.start', 2);
r = safe_runopf(mpo, mpopt);
if ~r.success
    r2 = safe_runopf(mpo, mpoption(mpopt, 'mips.step_control', 1));
    if r2.success, r = r2; end
end
E = dali_eval_ac(r, meta, cfg, vpen, 'mpac', opfs);
if r.success
    rm = struct('baseMVA', r.baseMVA, 'bus', r.bus, 'gen', r.gen, 'branch', r.branch, 'success', 1);
else
    rm = struct('success', 0);
end
ts = toc(tj);
end

function [path, best] = dp_path(J, dt, L, Umax, ac)
% Exact DP over topology sequences. State (s, h, u): topology s (1 = no opening), h-1 periods still locked
% after the last change, u-1 actions used. Start s = 1 (all in service).
[T, S] = size(J);
C = inf(S, L, Umax + 1); C(1, 1, 1) = 0;
BP = zeros(T, S, L, Umax + 1);
sz = [S, L, Umax + 1];
for t = 1:T
    Cn = inf(sz); B = zeros(sz);
    for s = 1:S
        for h = 1:L
            for u = 1:Umax + 1
                c0 = C(s, h, u);
                if ~isfinite(c0), continue; end
                if h > 1
                    cand_s = s;
                else
                    cand_s = 1:S;
                end
                for s2 = cand_s
                    if h > 1
                        a = 0; h2 = h - 1; u2 = u;
                    else
                        a = nact(s, s2);
                        u2 = u + a;
                        if u2 > Umax + 1, continue; end
                        if a > 0, h2 = L; else, h2 = 1; end
                    end
                    v = c0 + dt * J(t, s2) + ac * a;
                    if v < Cn(s2, h2, u2)
                        Cn(s2, h2, u2) = v;
                        B(s2, h2, u2) = sub2ind(sz, s, h, u);
                    end
                end
            end
        end
    end
    C = Cn; BP(t, :, :, :) = reshape(B, [1, sz]);
end
[best, idx] = min(C(:));
path = zeros(1, T);
if ~isfinite(best), return; end
for t = T:-1:1
    [s, h, u] = ind2sub(sz, idx);
    path(t) = s;
    idx = BP(t, s, h, u);
end
end

function a = nact(s, s2)
if s == s2, a = 0; elseif s == 1 || s2 == 1, a = 1; else, a = 2; end
end

function str = path_str(path, cand)
parts = cell(1, numel(path));
for t = 1:numel(path)
    if path(t) == 1, parts{t} = '-'; else, parts{t} = sprintf('%d', cand(path(t) - 1)); end
end
str = strjoin(parts, ' ');
end

function write_report(cfg, Tm, P, cand, S, Jsum, J0sum, acts, nn1, nviol_ramp, maxramp, lam, dispg, pg_init, dpg, dt)
fn = fullfile(cfg.outdir, 'MPAC_report.md');
fid = fopen(fn, 'w', 'n', 'UTF-8');
w = @(varargin) fprintf(fid, varargin{:});
T = numel(P);
w('# 大理 905 节点：16 时段完整 AC-OTS 基准（含机组出力与 N-1）\n\n');
w('%s 自动生成（run_dali_mp_acots；i7-1165G7 笔记本，MATLAB R2022b + MATPOWER 8.0 MIPS，单线程）\n\n', datestr(now, 'yyyy-mm-dd HH:MM'));
w('## 1. 结论\n\n');
w(['16 个时段（15 min，负荷系数 %.2f→%.2f）全部跑通：%d 次完整非线性交流 OPF、%d 次静态交流 N-1，', ...
    '基准总用时 %.0f s（约 %.1f 分钟）。最终开关序列共 %d 次动作，4 小时 AC 目标 %.2f $（全程不开断 %.2f $，%+.2f），', ...
    '每个时段的 N-1 紧急判据均不低于不开断方式；可调机组爬坡限制超限时段 %d 个（最大使用率 %.2f）。\n\n'], ...
    lam(1), lam(end), Tm.n_opf, nn1, Tm.baseline_core_s, Tm.baseline_core_s / 60, acts, Jsum, J0sum, Jsum - J0sum, ...
    nviol_ramp, maxramp);
w('## 2. 方法\n\n');
w(['每个时段有 %d 种拓扑：不开断，或断开 %d 条“断开后不新增桥”的支路之一（候选模式 %s）。对每个时段×拓扑求一次完整交流 OPF，', ...
    '决策为 %d 台可调机组有功（±%.0f%%，与平衡机同价，即目标为网损）以及机组无功/电压；目标 J_AC = 网损 + %g × 电压越限（任务书电压口径）。', ...
    '开关序列在时间方向用动态规划精确求解（全程动作 ≤ %d 次，动作后保持 ≥ %d 个时段，每次动作成本 %g）。', ...
    'N-1 为懒校验：对 DP 最优路径上的拓扑做静态交流 N-1（≥110 kV 非桥线路与主变，紧急电压带 0.90–1.10），', ...
    '要求全部收敛、紧急判据通过率不低于该时段不开断方式、切负荷解列元件不多于不开断方式，不通过则剔除并重新规划。', ...
    '分接头保持当前挡位。\n\n'], S, numel(cand), cfg.mpac.cand_mode, sum(dispg), 100 * cfg.mp.disp_range, cfg.mp.vpen, ...
    cfg.mp.max_actions, cfg.mp.min_hold, cfg.mp.action_cost);
w('## 3. 用时\n\n| 环节 | 次数 | 用时 |\n| --- | --- | --- |\n');
w('| 16 个时段基准潮流 | %d | %.1f s |\n', T, Tm.period_acpf_s);
w('| 拓扑筛选（不新增桥） | - | %.1f s |\n', Tm.topology_screen_s);
w('| 完整交流 OPF（时段 × 拓扑） | %d | %.1f s |\n', Tm.n_opf, Tm.opf_stage_s);
w('| 动态规划（%d 轮） | - | %.2f s |\n', Tm.dp_iterations, Tm.dp_s);
w('| 静态交流 N-1 | %d | %.1f s |\n', nn1, Tm.n1_s);
w('| **合计** | | **%.1f s** |\n\n', Tm.baseline_core_s);
w('## 4. 逐时段结果\n\n| 时段 | 负荷系数 | 开断 | J_AC（$/h） | 不开断 J_AC | 网损（MW） | 电压越限（p.u.） | 110/35 kV 合格率 | N-1 紧急 | N-1 增量 | 可调出力（MW） |\n');
w('| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |\n');
for t = 1:T
    p = P(t);
    w('| %d | %.3f | %s | %.3f | %.3f | %.2f | %.4f | %.1f%% | %.1f%% | %.1f%% | %.1f |\n', p.t, p.load_factor, ...
        ternary(p.open_row == 0, '—', sprintf('%d', p.open_row)), p.J_AC, p.J_AC_no_opening, p.loss_MW, p.viol_pu, p.vq_pct, ...
        p.n1_emergency_pct, p.n1_incremental_pct, p.disp_pg_MW);
end
dE = dpg - pg_init(dispg) * ones(1, T);
w(['\n可调机组相对 S1 出力：4 小时增发 %.1f MWh、压减 %.1f MWh（目标只计网损，未计入水电价值与新能源消纳，', ...
    '压减部分需在汇报中单列）。\n\n'], dt * sum(max(dE(:), 0)), dt * sum(max(-dE(:), 0)));
w('## 5. 口径说明\n\n');
w(['“完整”指每个时段×拓扑都用完整非线性交流 OPF 求解，开关序列在候选集内精确优化；每个 OPF 为非凸问题的局部最优。', ...
    '候选集限于单条开断且断开后不新增桥（需要时可改为全部非桥支路，OPF 次数约增加 16 倍）。机组爬坡仅第 1 时段写入约束，', ...
    '其余时段事后核查。分接头未参与优化。N-1 为静态交流校验，故障后不重新优化（非 SCOPF）。负荷曲线为合成曲线，', ...
    '电压限值、额定值单位、外网等值等仍为待确认假设。\n']);
fclose(fid);
fprintf('  report written: %s\n', fn);
end

function mpopt = try_opt(mpopt, name, val)
try
    mpopt = mpoption(mpopt, name, val);
catch
end
end

function res = safe_runopf(mpo, mpopt)
try
    res = runopf(mpo, mpopt);
catch
    res = struct('success', 0, 'f', NaN);
end
end

function s = ternary(c, a, b)
if c, s = a; else, s = b; end
end
