function run_dali_mp(varargin)
%RUN_DALI_MP  课题4 指标4.1 多时段参考模型 v1.0-a：16 时段 × 8 候选开关 + 可调机组出力（含爬坡）。
%   流程：P0 准备（读数、建算例、S1 AC-OPF，不计入 4.1 时钟）→
%         MP-1 生成时段数据与线性化点（逐时段 ACPF）→ MP-2 逐时段建块 → MP-3 COPT 整体 MIQP
%         （4.1 时钟到此为止：从输入数据到可行解）→ 对照：同模型固定全在运的连续 QP →
%         MP-4 逐时段 MATPOWER AC 校核与指标。
%   默认电压口径为任务书口径（P0 结论）。覆盖配置同 run_dali_p0，例如 run_dali_mp('mp.max_actions', 8)。

here = fileparts(mfilename('fullpath'));
addpath(here);
cfg = dali_p0_config();
cfg.vlim.opf_source = 'taskbook_proxy';
if mod(numel(varargin), 2) ~= 0
    error('dali:mp', 'Overrides must be name/value pairs');
end
for i = 1:2:numel(varargin)
    fpath = strsplit(varargin{i}, '.');
    cfg = setfield(cfg, fpath{:}, varargin{i+1}); %#ok<SFLD>
end
if isempty(cfg.outdir)
    cfg.outdir = fullfile(here, sprintf('out_MP_T%d_%s', cfg.mp.T, cfg.vlim.opf_source));
end
if ~exist(cfg.outdir, 'dir'), mkdir(cfg.outdir); end
stamp = datestr(now, 'yyyymmdd_HHMMSS');
logf = fullfile(cfg.outdir, ['MP_log_' stamp '.txt']);
diary(logf);
cleaner = onCleanup(@() diary('off')); %#ok<NASGU>
fprintf('Dali multi-period reference model run %s (package v1.0-a2)\n', stamp);
for i = 1:2:numel(varargin)
    fprintf('  override: %s = %s\n', varargin{i}, mat2str(varargin{i+1}));
end
try
    main_mp(cfg, stamp, logf);
catch err
    fprintf(2, '\n*** RUN FAILED ***\n%s\n', getReport(err, 'extended', 'hyperlinks', 'off'));
    fprintf('\nPlease upload the log file: %s\n', logf);
end
end

%% =======================================================================
function main_mp(cfg, stamp, logf)
Tm = struct();
t0 = tic;
env = dali_p0_step0_env(cfg);
if ~env.matpower_ok, error('dali:mp', 'MATPOWER >= 7 required'); end
if ~env.copt.ok, error('dali:mp', 'COPT interface not available'); end
define_constants;
raw = dali_read_pasexp(cfg.txtfile);
topo = dali_topology_audit(raw, cfg);
[mpc, ~, meta] = dali_build_case(raw, topo, cfg);
[pf0, ~] = dali_run_acpf(mpc, meta, 'equivalent_v1', false, false);
vpen = cfg.mp.vpen;
[mpo, opfset] = dali_setup_opf(mpc, pf0, meta, cfg, vpen, []);
[r1, i1] = dali_run_acopf(mpo, opfset, cfg, env, 'MP period-0 controls (S1)');
if ~i1.success, error('dali:mp', 'S1 AC-OPF failed; cannot set period controls'); end
Tm.p0_prep_s = toc(t0);

%% ---------------- MP-1: period data + linearisation points (4.1 clock starts) ----------------
T = cfg.mp.T;
fprintf('\n===== MP-1: %d periods of %.2f h, load factor %.3f -> %.3f =====\n', T, cfg.mp.dt_h, ...
    cfg.mp.load_start, cfg.mp.load_end);
tclock = tic; tt = tic;
lam = linspace(cfg.mp.load_start, cfg.mp.load_end, T);
sel = mpc.bus(:, PD) > 0 & meta.base_kv <= cfg.mp.load_kv_max & ~meta.is_boundary;
gon = mpc.gen(:, GEN_STATUS) > 0;
dispg = gon & ~ismember(mpc.gen(:, GEN_BUS), cfg.boundary.buses) & meta.snap_gen_PG >= cfg.mp.disp_min_MW;
dispg(opfset.slackgen) = false;
pg_init = r1.gen(:, PG);
opm = opfset;
opm.pmin(dispg) = (1 - cfg.mp.disp_range) * pg_init(dispg);
opm.pmax(dispg) = (1 + cfg.mp.disp_range) * pg_init(dispg);
fprintf('  scaled load: %d buses, %.1f MW at factor 1 | dispatchable units: %d (%.1f MW), range +-%.0f%%, ramp %.0f%%/period\n', ...
    sum(sel), sum(mpc.bus(sel, PD)), sum(dispg), sum(pg_init(dispg)), 100 * cfg.mp.disp_range, 100 * cfg.mp.ramp_frac);
m0 = mpc;
m0.gen(:, QMIN) = opfset.qmin;
m0.gen(:, QMAX) = opfset.qmax;
mpopt_pf = mpoption('pf.alg', 'NR', 'pf.tol', 1e-8, 'pf.nr.max_it', 30, 'verbose', 0, 'out.all', 0, ...
    'pf.enforce_q_lims', 1);
cases = cell(1, T); bases = cell(1, T);
for t = 1:T
    mt = m0;
    mt.bus(sel, PD) = mpc.bus(sel, PD) * lam(t);
    mt.bus(sel, QD) = mpc.bus(sel, QD) * lam(t);
    cases{t} = mt;
    rt = runpf(dali_pf_case_from_state(mt, r1, meta, []), mpopt_pf);
    if ~rt.success
        error('dali:mp', 'Base ACPF failed at period %d (load factor %.3f)', t, lam(t));
    end
    bases{t} = rt;
end
Tm.mp1_period_acpf_s = toc(tt);
fprintf('  %d base power flows converged in %.2f s\n', T, Tm.mp1_period_acpf_s);

%% ---------------- MP-2: blocks ----------------
fprintf('\n===== MP-2: build %d period blocks =====\n', T);
tt = tic;
blocks = cell(1, T);
for t = 1:T
    blocks{t} = dali_mp_build_period(bases{t}, opm, meta, cfg, vpen, cfg.mp.dt_h, t == 1);
end
Tm.mp2_build_s = toc(tt);
fprintf('  blocks built in %.2f s\n', Tm.mp2_build_s);

%% ---------------- MP-3: COPT (v1.0-a2: QP first, then MIQP warm-started from it) ----------------
fprintf('\n===== MP-3a: continuous QP, all candidates in service (dispatch only) =====\n');
info = struct('disp', dispg, 'pg_init', pg_init, 'base', mpc.baseMVA, 'fix_z_all_on', true);
S0 = dali_mp_solve(blocks, info, cfg, env);
Tm.mp3a_qp_s = S0.solve_time_s;
Tm.clock_first_feasible_s = toc(tclock);
if ~S0.ok
    error('dali:mp', 'Multi-period QP (no switching) returned no solution (status %s)', S0.status);
end
fprintf('\n  >>> 4.1 clock to FIRST feasible solution (QP): %.2f s  [ACPF %.2f + build %.2f + QP %.2f]\n', ...
    Tm.clock_first_feasible_s, Tm.mp1_period_acpf_s, Tm.mp2_build_s, Tm.mp3a_qp_s);

fprintf('\n===== MP-3b: MIQP with switching, MIP start = QP solution =====\n');
info.fix_z_all_on = false;
info.start = S0.x;
S = dali_mp_solve(blocks, info, cfg, env);
Tm.mp3b_miqp_s = S.solve_time_s;
Tm.clock_input_to_solution_s = toc(tclock);
used = 'MIQP';
if ~S.ok
    fprintf(2, '  MIQP returned no solution (%s): keeping the QP solution (no switching) as the decision\n', S.status);
    S = S0; used = 'QP_FALLBACK';
end
fprintf('\n  >>> 4.1 clock to FINAL solution (%s): %.2f s  [ACPF %.2f + build %.2f + QP %.2f + MIQP %.2f]\n', ...
    used, Tm.clock_input_to_solution_s, Tm.mp1_period_acpf_s, Tm.mp2_build_s, Tm.mp3a_qp_s, Tm.mp3b_miqp_s);
fprintf('  value of switching in proxy: %.4f $ over the horizon (final %.4f vs no-switching QP %.4f), gap %g\n', ...
    S.objval - S0.objval, S.objval, S0.objval, S.bestgap);

%% ---------------- MP-4: AC check per period ----------------
fprintf('\n===== MP-4: MATPOWER AC check per period =====\n');
tt = tic;
R = struct('t', {}, 'load_factor', {}, 'load_MW', {}, 'open_rows', {}, 'disp_pg_MW', {}, ...
    'base_loss_MW', {}, 'proxy_loss_MW', {}, 'dec_loss_MW', {}, 'base_viol_pu', {}, 'proxy_viol_pu', {}, ...
    'dec_viol_pu', {}, 'base_tbVQ_pct', {}, 'dec_tbVQ_pct', {}, 'dec_converged', {}, 'proxy_row_viol', {});
for t = 1:T
    open = meta.cand_rows(S.z(:, t) < 0.5);
    st = bases{t};
    st.gen(:, PG) = S.pg(:, t);
    st.bus(:, VM) = blocks{t}.vm0 + S.dV{t}(blocks{t}.sidx(:));
    rchk = safe_pf(dali_pf_case_from_state(cases{t}, st, meta, open), mpopt_pf);
    Eb = dali_eval_ac(bases{t}, meta, cfg, vpen, sprintf('t%02d_base', t), opm);
    Ed = dali_eval_ac(rchk, meta, cfg, vpen, sprintf('t%02d_decision', t), opm);
    R(end+1) = struct('t', t, 'load_factor', lam(t), 'load_MW', sum(cases{t}.bus(sel, PD)), ...
        'open_rows', dali_rows2str(open), 'disp_pg_MW', sum(S.pg(dispg, t)), ...
        'base_loss_MW', Eb.loss_MW, 'proxy_loss_MW', S.loss_proxy(t), 'dec_loss_MW', Ed.loss_MW, ...
        'base_viol_pu', Eb.sum_v_viol_opf_scope, 'proxy_viol_pu', S.viol_proxy(t), 'dec_viol_pu', Ed.sum_v_viol_opf_scope, ...
        'base_tbVQ_pct', Eb.tb_vq_rate_110_35kV_pct, 'dec_tbVQ_pct', Ed.tb_vq_rate_110_35kV_pct, ...
        'dec_converged', Ed.converged, 'proxy_row_viol', S.max_row_viol(t)); %#ok<AGROW>
    fprintf(['  t%02d load x%.3f | open %-6s | disp %.1f MW | loss base %.3f -> AC %.3f (proxy %.3f) MW | ', ...
        'viol %.4f -> %.4f pu | 110/35kV qualified %.1f%% -> %.1f%% | conv %d\n'], t, lam(t), R(end).open_rows, ...
        R(end).disp_pg_MW, Eb.loss_MW, Ed.loss_MW, S.loss_proxy(t), Eb.sum_v_viol_opf_scope, ...
        Ed.sum_v_viol_opf_scope, Eb.tb_vq_rate_110_35kV_pct, Ed.tb_vq_rate_110_35kV_pct, Ed.converged);
end
Tm.mp4_ac_check_s = toc(tt);
dt = cfg.mp.dt_h;
Eloss_base = dt * sum([R.base_loss_MW]);
Eloss_dec = dt * sum([R.dec_loss_MW]);
fprintf(['\n  horizon: energy loss base %.2f MWh -> decision %.2f MWh (%.2f MWh, %.2f%%) | switching actions %.0f | ', ...
    'AC converged %d/%d\n'], Eloss_base, Eloss_dec, Eloss_dec - Eloss_base, 100 * (Eloss_dec - Eloss_base) / Eloss_base, ...
    S.actions, sum([R.dec_converged]), T);

%% ---------------- outputs ----------------
writetable(struct2table(R), fullfile(cfg.outdir, 'MP_periods.csv'));
Ssum = rmfield(S, {'z', 'pg', 'dV', 'loss_proxy', 'viol_proxy', 'max_row_viol', 'x'});
Ssum.decision_from = used;
Ssum.ref_qp_objval = S0.objval; Ssum.ref_qp_time_s = S0.solve_time_s;
Ssum.Eloss_base_MWh = Eloss_base; Ssum.Eloss_dec_MWh = Eloss_dec;
writetable(struct2table(Ssum, 'AsArray', true), fullfile(cfg.outdir, 'MP_solve_summary.csv'));
writetable(array2table(S.z.', 'VariableNames', arrayfun(@(k) sprintf('row%d', k), meta.cand_rows(:).', ...
    'UniformOutput', false)), fullfile(cfg.outdir, 'MP_switch_schedule.csv'));
S = rmfield(S, 'x'); S0 = rmfield(S0, 'x');
save(fullfile(cfg.outdir, 'MP_workspace.mat'), 'cfg', 'S', 'S0', 'R', 'Tm', 'lam', 'dispg', '-v7');
Tm.total_s = toc(t0);
fprintf('\nTimings (s):\n'); disp(Tm);
fprintf('\n===== DONE. Upload %s (MP_log_*, MP_periods.csv, MP_solve_summary.csv, MP_switch_schedule.csv) =====\n', cfg.outdir);
end

function r = safe_pf(m, mpopt)
try
    r = runpf(m, mpopt);
catch
    r = struct('success', 0);
end
end
