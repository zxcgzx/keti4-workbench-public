function M = dali_mp_build_period(res0, opfset, meta, cfg, vpen, dt, verbose)
%DALI_MP_BUILD_PERIOD  多时段模型的单时段块。
%   与 dali_ots_copt 的代理模型逐行相同（线性化 AC、近零阻抗超节点、Big-M 开断、额定值八边形、
%   电压软约束、每时段开断数上限），区别只有三点：只建模不求解；目标乘以时段长度 dt（h）；
%   开断动作成本不在块内计（由 dali_mp_solve 中的动作变量计）。返回模型 P 与变量索引。
%   本文件由 gen_mp_builder.py 从 dali_ots_copt.m 机械截取生成，勿手工修改。
define_constants;
zmode = 'miqp'; zfix = []; nogood = {}; %#ok<NASGU>
cfg.ots.switch_cost = 0;
if nargin < 7, verbose = false; end

base = res0.baseMVA;
bus = res0.bus; gen = res0.gen; br = res0.branch;
nb = size(bus, 1); ng = size(gen, 1); nl = size(br, 1);
f = meta.f(:); t = meta.t(:);
cand = meta.cand_rows(:); nc = numel(cand);
on0 = br(:, BR_STATUS) == 1;
if any(~on0(cand))
    error('dali:ots', 'All candidate branches must be in service at the linearisation point.');
end

%% ---------------- base point quantities (p.u.) ----------------
vm0 = bus(:, VM); va0 = bus(:, VA) * pi / 180;
V0 = vm0 .* exp(1j * va0);
r = br(:, BR_R); x = br(:, BR_X); bb = br(:, BR_B);
tp = br(:, TAP); tp(tp == 0) = 1;
tau = tp .* exp(1j * br(:, SHIFT) * pi / 180);
ys = 1 ./ (r + 1j * x);
ytt = ys + 1j * bb / 2;
yff = ytt ./ (tau .* conj(tau));
yft = -ys ./ conj(tau);
ytf = -ys ./ tau;
yff(~on0) = 0; ytt(~on0) = 0; yft(~on0) = 0; ytf(~on0) = 0;
Vf = V0(f); Vt = V0(t);
Sf0 = Vf .* conj(yff .* Vf + yft .* Vt);
St0 = Vt .* conj(ytf .* Vf + ytt .* Vt);
dSf_thf = 1j * Vf .* conj(yft .* Vt);            dSf_tht = -dSf_thf;
dSf_vf  = 2 * abs(Vf) .* conj(yff) + (Vf ./ abs(Vf)) .* conj(yft .* Vt);
dSf_vt  = Vf .* conj(yft) .* conj(Vt) ./ abs(Vt);
dSt_tht = 1j * Vt .* conj(ytf .* Vf);            dSt_thf = -dSt_tht;
dSt_vt  = 2 * abs(Vt) .* conj(ytt) + (Vt ./ abs(Vt)) .* conj(ytf .* Vf);
dSt_vf  = Vt .* conj(ytf) .* conj(Vf) ./ abs(Vf);
% v1.0-b: sensitivity of end flows to the (real) off-nominal ratio on the from side
% (prototype: one 1.25% step on the 6 most loaded transformers, linear vs AC within 2.5%)
dSf_dtau = -(2 ./ tp) .* abs(Vf).^2 .* conj(yff) - (1 ./ tp) .* Vf .* conj(yft .* Vt);
dSt_dtau = -(1 ./ tp) .* Vt .* conj(ytf .* Vf);

rows0 = (1:nl).';
Cf = sparse(f, rows0, 1, nb, nl);
Ct = sparse(t, (1:nl).', 1, nb, nl);
Ysh = (bus(:, GS) + 1j * bus(:, BS)) / base;
gon = gen(:, GEN_STATUS) > 0;
gbi = meta.map(gen(:, GEN_BUS));
Cg = sparse(gbi(gon), find(gon), 1, nb, ng);
Sg0 = (gen(:, PG) + 1j * gen(:, QG)) / base; Sg0(~gon) = 0;
Sd = (bus(:, PD) + 1j * bus(:, QD)) / base;

%% ---------------- self checks ----------------
chk = struct();
busI = bus(:, 1:13); busI(:, BUS_I) = (1:nb).';
brI = br(:, 1:13); brI(:, F_BUS) = f; brI(:, T_BUS) = t;
Ybus_mp = makeYbus(base, busI, brI);
Yf = sparse(rows0, f, yff, nl, nb) + sparse(rows0, t, yft, nl, nb);
Yt = sparse(rows0, f, ytf, nl, nb) + sparse(rows0, t, ytt, nl, nb);
Ybus_me = Cf * Yf + Ct * Yt + spdiags(Ysh, 0, nb, nb);
chk.ybus_maxdiff = full(max(max(abs(Ybus_me - Ybus_mp))));
mis0 = Cf * Sf0 + Ct * St0 + abs(V0).^2 .* conj(Ysh) - (Cg * Sg0 - Sd);
chk.base_mismatch_MW = max(abs(real(mis0))) * base;
chk.base_mismatch_Mvar = max(abs(imag(mis0))) * base;
h = 1e-7;
Vfh = Vf .* exp(1j * h);
fd = (Vfh .* conj(yff .* Vfh + yft .* Vt) - Sf0) / h;
chk.deriv_rel_err_theta = max(abs(fd - dSf_thf)) / max(1, max(abs(dSf_thf)));
Vfh = (abs(Vf) + h) .* exp(1j * angle(Vf));
fd = (Vfh .* conj(yff .* Vfh + yft .* Vt) - Sf0) / h;
chk.deriv_rel_err_vm = max(abs(fd - dSf_vf)) / max(1, max(abs(dSf_vf)));
chk.n_negative_R = sum(r(on0) < 0);
if verbose
    fprintf(['  proxy self-check: |Ybus_me-Ybus_mp|max=%.2e, base mismatch %.2e MW / %.2e Mvar, ', ...
        'dS/dθ rel.err %.1e, dS/dV rel.err %.1e, negative R: %d\n'], chk.ybus_maxdiff, ...
        chk.base_mismatch_MW, chk.base_mismatch_Mvar, chk.deriv_rel_err_theta, chk.deriv_rel_err_vm, chk.n_negative_R);
end

%% ---------------- ideal connections: merge near-zero-impedance branches into supernodes (v0.9) ----------------
% 近零阻抗支路（|z| <= cfg.ots.ideal_zmax）按理想连接处理：两端角度/电压增量相同，节点平衡按超节点合并，
% 支路潮流成为内部量。原型验证：与原线性化逐位一致，最大系数 23246 -> 3392，用于恢复 COPT 预处理。
isZ = false(nl, 1);
if isfield(cfg.ots, 'merge_ideal') && cfg.ots.merge_ideal
    isZ = on0 & abs(r + 1j * x) <= cfg.ots.ideal_zmax;
    isZ(cand) = false;
end
par = (1:nb).';
for k = find(isZ).'
    a = uf_root(par, f(k)); b = uf_root(par, t(k));
    if a ~= b, par(a) = b; end
end
root = zeros(nb, 1);
for i = 1:nb, root(i) = uf_root(par, i); end
[~, rep, sidx] = unique(root);
nsn = numel(rep);
Msn = sparse((1:nb).', sidx(:), 1, nb, nsn);
chk.n_ideal = sum(isZ); chk.n_supernodes = nsn;
if verbose && chk.n_ideal > 0
    fprintf('  ideal connections merged: %d branches, buses %d -> %d supernodes\n', chk.n_ideal, nb, nsn);
end

%% ---------------- variable layout ----------------
iTh = 1:nsn;  iV = nsn + (1:nsn);
o = 2 * nsn;
iPg = o + (1:ng); iQg = o + ng + (1:ng); o = o + 2 * ng;
iPf = o + (1:nl); iQf = o + nl + (1:nl); o = o + 2 * nl;
iPt = o + (1:nc); iQt = o + nc + (1:nc); o = o + 2 * nc;
iZ = o + (1:nc); o = o + nc;
soft = opfset.soft_idx(:); ns = numel(soft);
iSp = o + (1:ns); iSm = o + ns + (1:ns); o = o + 2 * ns;
istap = false(nl, 1);
if isfield(cfg.ots, 'taps') && cfg.ots.taps
    istap = on0 & br(:, TAP) ~= 0 & ~isZ;
    istap(cand) = false;
    if isfield(cfg.ots, 'tap_kv_min') && ~isempty(cfg.ots.tap_kv_min)
        istap = istap & max(meta.base_kv(f), meta.base_kv(t)) >= cfg.ots.tap_kv_min;
    end
end
tapk = find(istap); ntap = numel(tapk);
iN = o + (1:ntap); o = o + ntap;
nv = o;

lb = -inf(nv, 1); ub = inf(nv, 1);
lb(iTh) = -cfg.ots.theta_trust; ub(iTh) = cfg.ots.theta_trust;
refi = find(bus(:, BUS_TYPE) == REF);
lb(iTh(sidx(refi))) = 0; ub(iTh(sidx(refi))) = 0;
lb(iV) = -cfg.ots.dv_trust; ub(iV) = cfg.ots.dv_trust;
sfix = accumarray(sidx(:), double(opfset.fixv(:)), [nsn 1]) > 0;
lb(iV(sfix)) = 0; ub(iV(sfix)) = 0;
lb(iPg) = opfset.pmin / base; ub(iPg) = opfset.pmax / base;
lb(iQg) = opfset.qmin / base; ub(iQg) = opfset.qmax / base;
lb(iPg(~gon)) = 0; ub(iPg(~gon)) = 0; lb(iQg(~gon)) = 0; ub(iQg(~gon)) = 0;
lb([iSp iSm]) = 0;
lb(iPf(isZ)) = real(Sf0(isZ)); ub(iPf(isZ)) = real(Sf0(isZ));   % internal flows: fixed, irrelevant
lb(iQf(isZ)) = imag(Sf0(isZ)); ub(iQf(isZ)) = imag(Sf0(isZ));
vtype = repmat('C', 1, nv);
if strcmpi(zmode, 'miqp')
    lb(iZ) = 0; ub(iZ) = 1; vtype(iZ) = 'B';
else
    zf = double(zfix(:) > 0.5);
    lb(iZ) = zf; ub(iZ) = zf;
end
tstep = 0; tau0 = tp(tapk);
if ntap > 0
    tstep = cfg.ots.tap_step;
    tlo = max(-cfg.ots.tap_max_steps, ceil((cfg.ots.tap_range(1) - tau0) / tstep - 1e-9));
    thi = min(cfg.ots.tap_max_steps, floor((cfg.ots.tap_range(2) - tau0) / tstep + 1e-9));
    tlo = min(tlo, 0); thi = max(thi, 0);
    lb(iN) = tlo; ub(iN) = thi; vtype(iN) = 'I';
    chk.n_taps = ntap; chk.tap_binary_equiv = sum(ceil(log2(thi - tlo + 1)));
end

%% ---------------- linearised branch flows ----------------
rows = (1:nl).';
mkJ = @(a, b, c, d) sparse([rows; rows; rows; rows], [sidx(f); sidx(t); nsn + sidx(f); nsn + sidx(t)], [a; b; c; d], nl, nv);
JfP = mkJ(real(dSf_thf), real(dSf_tht), real(dSf_vf), real(dSf_vt));
JfQ = mkJ(imag(dSf_thf), imag(dSf_tht), imag(dSf_vf), imag(dSf_vt));
JtP = mkJ(real(dSt_thf), real(dSt_tht), real(dSt_vf), real(dSt_vt));
JtQ = mkJ(imag(dSt_thf), imag(dSt_tht), imag(dSt_vf), imag(dSt_vt));
if ntap > 0                                         % flows depend on tap steps n: dS/dtau * tap_step * n
    JfP = JfP + sparse(tapk, iN(:), real(dSf_dtau(tapk)) * tstep, nl, nv);
    JfQ = JfQ + sparse(tapk, iN(:), imag(dSf_dtau(tapk)) * tstep, nl, nv);
    JtP = JtP + sparse(tapk, iN(:), real(dSt_dtau(tapk)) * tstep, nl, nv);
    JtQ = JtQ + sparse(tapk, iN(:), imag(dSt_dtau(tapk)) * tstep, nl, nv);
end
sel = @(ix) sparse((1:numel(ix)).', ix(:), 1, numel(ix), nv);
isC = false(nl, 1); isC(cand) = true;
nonC = find(~isC & ~isZ);

Arows = {}; L = {}; U = {}; Bn = {};
% (E1) non-candidate from-end flows
A1 = [sel(iPf(nonC)) - JfP(nonC, :); sel(iQf(nonC)) - JfQ(nonC, :)];
b1 = [real(Sf0(nonC)); imag(Sf0(nonC))];
Arows{end+1} = A1; L{end+1} = b1; U{end+1} = b1; Bn{end+1} = 'E1_flowdef';
% (E2) nodal balance
CtN = Ct(:, nonC); CtC = Ct(:, cand);
dPsh = 2 * real(Ysh) .* vm0;  Psh0 = real(Ysh) .* vm0.^2;
dQsh = -2 * imag(Ysh) .* vm0; Qsh0 = -imag(Ysh) .* vm0.^2;
A2P = Msn.' * (Cf(:, ~isZ) * sel(iPf(~isZ)) + CtN * JtP(nonC, :) + CtC * sel(iPt) + sparse((1:nb).', iV(sidx(:)).', dPsh, nb, nv) - Cg * sel(iPg));
b2P = Msn.' * (-real(Sd) - Psh0 - CtN * real(St0(nonC)) - Cf(:, isZ) * real(Sf0(isZ)) - Ct(:, isZ) * real(St0(isZ)));
A2Q = Msn.' * (Cf(:, ~isZ) * sel(iQf(~isZ)) + CtN * JtQ(nonC, :) + CtC * sel(iQt) + sparse((1:nb).', iV(sidx(:)).', dQsh, nb, nv) - Cg * sel(iQg));
b2Q = Msn.' * (-imag(Sd) - Qsh0 - CtN * imag(St0(nonC)) - Cf(:, isZ) * imag(Sf0(isZ)) - Ct(:, isZ) * imag(St0(isZ)));
Arows{end+1} = [A2P; A2Q]; L{end+1} = [b2P; b2Q]; U{end+1} = [b2P; b2Q]; Bn{end+1} = 'E2_nodal';

% (C) candidate disjunction (Big-M) + angle-difference limit
dth0 = va0(f) - va0(t);
delta = max(cfg.ots.angdiff_open_max, 2 * abs(dth0(cand)) + 0.05);
dv_open = 2 * cfg.ots.dv_trust;                    % 'fixed' mode: |dVf - dVt| only bounded by trust region
if isfield(cfg.ots, 'bigm_mode') && strcmpi(cfg.ots.bigm_mode, 'lodf') && nc > 0
    % v1.0-a3: open-branch angle estimated by DC line-outage sensitivity (prototype: within 2% of AC
    % for all 8 candidates; actual open angles 0.35-4.0 deg vs 20.1 deg used before).
    est = open_angle_lodf(nb, f, t, x, on0, cand, refi, dth0(cand));
    dl = max(cfg.ots.angdiff_margin * abs(est), cfg.ots.angdiff_floor);
    dl(~isfinite(dl)) = delta(~isfinite(dl));
    delta = max(dl, abs(dth0(cand)) + 0.005);
    dv_open = cfg.ots.dv_open;                     % explicit |dVf - dVt| <= dv_open on candidates
end
chk.bigm_delta_deg_max = max([0; delta(:)]) * 180 / pi;
rate_pu = meta.rate_MVA_opf / base;
if ~cfg.rate.enforce_in_opf, rate_pu(:) = 0; end
Mon = max([2 * rate_pu(cand), 4 * abs(Sf0(cand)), 4 * abs(St0(cand)), ones(nc, 1)], [], 2);
Zs = sparse((1:nc).', iZ(:), 1, nc, nv);
spd = @(v) spdiags(v(:), 0, nc, nc);
blk = {iPf(cand), JfP(cand, :), real(Sf0(cand)), real(dSf_thf(cand)), real(dSf_vf(cand)), real(dSf_vt(cand));
       iQf(cand), JfQ(cand, :), imag(Sf0(cand)), imag(dSf_thf(cand)), imag(dSf_vf(cand)), imag(dSf_vt(cand));
       iPt,       JtP(cand, :), real(St0(cand)), real(dSt_tht(cand)), real(dSt_vf(cand)), real(dSt_vt(cand));
       iQt,       JtQ(cand, :), imag(St0(cand)), imag(dSt_tht(cand)), imag(dSt_vf(cand)), imag(dSt_vt(cand))};
Mdev_all = zeros(nc, 4);
if nc > 0
    for q = 1:4
        ivar = blk{q, 1}; Jr = blk{q, 2}; s0 = blk{q, 3};
        av = blk{q, 5}; bv = blk{q, 6};            % a*dVf + b*dVt = (a+b)/2*(dVf+dVt) + (a-b)/2*(dVf-dVt)
        Mdev = 1.1 * (abs(s0) + abs(blk{q, 4}) .* (delta + abs(dth0(cand))) + ...
            abs(av + bv) * cfg.ots.dv_trust + abs(av - bv) / 2 * dv_open) + 1e-3;
        Mdev_all(:, q) = Mdev;
        Vsel = sel(ivar);
        ex = Vsel - Jr;
        Arows{end+1} = [ex + spd(Mdev) * Zs; -ex + spd(Mdev) * Zs; Vsel - spd(Mon) * Zs; -Vsel - spd(Mon) * Zs]; %#ok<AGROW>
        L{end+1} = -inf(4 * nc, 1); %#ok<AGROW>
        U{end+1} = [s0 + Mdev; -s0 + Mdev; zeros(nc, 1); zeros(nc, 1)]; %#ok<AGROW>
        Bn{end+1} = 'C_bigM'; %#ok<AGROW>
    end
    % (C2) branch-loss consistency cut (v1.0-a3): |(pf+pt) - S0*z| <= Lw*z for P and Q. Valid for z in {0,1}
    % (on: the sum is the linearised branch loss, whose sensitivity is small; off: both ends are 0); it stops
    % fractional z from creating power through inconsistent end flows. Prototype: LP-relaxation gap -97%,
    % integer optimum unchanged.
    if isfield(cfg.ots, 'loss_cut') && cfg.ots.loss_cut
        lc = {iPf(cand), iPt, Sf0(cand) + St0(cand), dSf_thf(cand) + dSt_thf(cand), ...
              dSf_vf(cand) + dSt_vf(cand), dSf_vt(cand) + dSt_vt(cand)};
        for q = 1:2
            if q == 1, pr = @real; ivf = lc{1}; ivt = lc{2}; else, pr = @imag; ivf = iQf(cand); ivt = iQt; end
            S0c = pr(lc{3}); cth = pr(lc{4}); cvf = pr(lc{5}); cvt = pr(lc{6});
            Lw = 1.1 * (abs(cth) .* (delta + abs(dth0(cand))) + abs(cvf + cvt) * cfg.ots.dv_trust + ...
                abs(cvf - cvt) / 2 * dv_open) + 1e-4;
            bs = sel(ivf) + sel(ivt);
            Arows{end+1} = [bs - spd(S0c + Lw) * Zs; -bs + spd(S0c - Lw) * Zs]; %#ok<AGROW>
            L{end+1} = -inf(2 * nc, 1); U{end+1} = zeros(2 * nc, 1); Bn{end+1} = 'C_losscut'; %#ok<AGROW>
        end
    end
    Aang = sparse([1:nc, 1:nc].', [sidx(f(cand)); sidx(t(cand))], [ones(nc, 1); -ones(nc, 1)], nc, nv);
    Arows{end+1} = Aang; L{end+1} = -delta - dth0(cand); U{end+1} = delta - dth0(cand); Bn{end+1} = 'C_angle';
    Avd = sparse([1:nc, 1:nc].', [iV(sidx(f(cand))).'; iV(sidx(t(cand))).'], [ones(nc, 1); -ones(nc, 1)], nc, nv);
    Arows{end+1} = Avd; L{end+1} = -dv_open * ones(nc, 1); U{end+1} = dv_open * ones(nc, 1); Bn{end+1} = 'C_dVopen';
end

% (R) rating octagon (outer approximation), from end for all rated branches, to end for candidates
alph = [0 pi/4 pi/2 3*pi/4];
ca = round(cos(alph) * 1e12) / 1e12; sa = round(sin(alph) * 1e12) / 1e12;
rated = find(on0 & rate_pu > 0);
nr = numel(rated);
Slim = rate_pu(rated) .* vm0(f(rated));
for a = 1:4
    Arows{end+1} = ca(a) * sparse((1:nr).', iPf(rated).', 1, nr, nv) + sa(a) * sparse((1:nr).', iQf(rated).', 1, nr, nv); %#ok<AGROW>
    L{end+1} = -Slim; U{end+1} = Slim; Bn{end+1} = 'R_octagon'; %#ok<AGROW>
end
cr = find(rate_pu(cand) > 0);
if ~isempty(cr)
    Slim_t = rate_pu(cand(cr)) .* vm0(t(cand(cr)));
    for a = 1:4
        Arows{end+1} = ca(a) * sparse((1:numel(cr)).', iPt(cr).', 1, numel(cr), nv) + ...
            sa(a) * sparse((1:numel(cr)).', iQt(cr).', 1, numel(cr), nv); %#ok<AGROW>
        L{end+1} = -Slim_t; U{end+1} = Slim_t; Bn{end+1} = 'R_octagon_to'; %#ok<AGROW>
    end
end

% (V) soft voltage limits
if ns > 0
    ri = (1:ns).';
    Asv = [sparse(ri, iV(sidx(soft)).', 1, ns, nv) - sparse(ri, iSp(:), 1, ns, nv); ...
          -sparse(ri, iV(sidx(soft)).', 1, ns, nv) - sparse(ri, iSm(:), 1, ns, nv)];
    Arows{end+1} = Asv;
    L{end+1} = -inf(2 * ns, 1);
    U{end+1} = [opfset.vmax(soft) - vm0(soft); vm0(soft) - opfset.vmin(soft)];
    Bn{end+1} = 'V_soft';
end

% (K) number of openings, (NG) no-good cuts for disconnected combinations
if nc > 0 && strcmpi(zmode, 'miqp')
    Arows{end+1} = sparse(ones(nc, 1), iZ(:), 1, 1, nv); L{end+1} = nc - cfg.ots.kmax; U{end+1} = inf; Bn{end+1} = 'K_count';
    for g = 1:numel(nogood)
        S = nogood{g};
        Arows{end+1} = sparse(ones(numel(S), 1), iZ(S).', 1, 1, nv); L{end+1} = 1; U{end+1} = inf; Bn{end+1} = 'NG_cut'; %#ok<AGROW>
    end
end

A0 = vertcat(Arows{:});
lhs0 = vertcat(L{:});
rhs0 = vertcat(U{:});
rowblk = repelem(1:numel(Arows), cellfun(@(M) size(M, 1), Arows));
% numerical hygiene (v0.2): drop |coef| < 1e-12, then equilibrate rows (feasible set unchanged)
[ii, jj, vv] = find(A0);
keep = abs(vv) >= 1e-12;
A = sparse(ii(keep), jj(keep), vv(keep), size(A0, 1), nv);
rs = full(max(abs(A), [], 2));
rs(rs == 0) = 1;
A = spdiags(1 ./ rs, 0, numel(rs), numel(rs)) * A;
lhs = lhs0 ./ rs;
rhs = rhs0 ./ rs;

%% ---------------- objective ----------------
w = zeros(nl, 1);
w(on0) = max(r(on0), 0) .* abs(tau(on0)).^2 ./ vm0(f(on0)).^2;
cch = (bb / 2) .* vm0(f).^2 ./ abs(tau).^2;
kL = cfg.obj.c_loss * base;
qd = zeros(nv, 1);
qd(iPf) = kL * w; qd(iQf) = kL * w;
c = zeros(nv, 1);
c(iQf) = kL * 2 * w .* cch;
c(iSp) = vpen; c(iSm) = vpen;
c(iZ) = kL * w(cand) .* cch(cand).^2 - cfg.ots.switch_cost;
objcon = kL * sum(w(nonC) .* cch(nonC).^2) + cfg.ots.switch_cost * nc;

P = struct('A', A, 'lhs', lhs, 'rhs', rhs, 'obj', dt * c, 'Qd', spdiags(dt * qd, 0, nv, nv), ...
    'objcon', dt * objcon, 'lb', lb, 'ub', ub, 'vtype', vtype);
if verbose
    fprintf('  period block: %d vars (%d binary), %d rows, nnz(A)=%d\n', nv, ...
        sum(vtype == 'B'), size(A, 1), nnz(A));
end
M = struct();
M.P = P; M.nv = nv; M.base = base; M.nb = nb; M.ng = ng; M.nl = nl; M.nc = nc;
M.idx = struct('iTh', iTh, 'iV', iV, 'iPg', iPg, 'iQg', iQg, 'iPf', iPf, 'iQf', iQf, ...
    'iPt', iPt, 'iQt', iQt, 'iZ', iZ, 'iSp', iSp, 'iSm', iSm, 'iN', iN);
M.cand = cand; M.w = w; M.cch = cch; M.on0 = on0; M.sidx = sidx; M.nsn = nsn;
M.vm0 = vm0; M.va0 = va0; M.Pg0 = gen(:, PG); M.Qg0 = gen(:, QG); M.gon = gon; M.chk = chk;
M.A0 = A0; M.lhs0 = lhs0; M.rhs0 = rhs0; M.Sf0 = Sf0; M.nv0 = nv;
M.tapk = tapk; M.tau0 = tau0; M.tapstep = tstep; M.rowblk = rowblk(:); M.Bn = Bn;
end

function a = uf_root(par, a)
while par(a) ~= a
    a = par(a);
end
end

function est = open_angle_lodf(nb, f, t, x, on, cand, refi, dth0c)
% DC estimate of the angle across candidate k after it is opened: dth0 / (1 - PTDF_kk).
E = find(on);
bk = 1 ./ x(E);
Bd = sparse([f(E); t(E); f(E); t(E)], [f(E); t(E); t(E); f(E)], [bk; bk; -bk; -bk], nb, nb);
keep = setdiff((1:nb).', refi(:));
pos = zeros(nb, 1); pos(keep) = 1:numel(keep);
[Lf, Uf, Pf, Qf] = lu(Bd(keep, keep));
est = inf(numel(cand), 1);
for j = 1:numel(cand)
    k = cand(j);
    e = zeros(numel(keep), 1);
    if pos(f(k)) > 0, e(pos(f(k))) = 1; end
    if pos(t(k)) > 0, e(pos(t(k))) = e(pos(t(k))) - 1; end
    xv = Qf * (Uf \ (Lf \ (Pf * e)));
    Xij = 0;
    if pos(f(k)) > 0, Xij = Xij + xv(pos(f(k))); end
    if pos(t(k)) > 0, Xij = Xij - xv(pos(t(k))); end
    s = Xij / x(k);
    if s < 1 - 1e-6
        est(j) = dth0c(j) / (1 - s);
    end
end
end

