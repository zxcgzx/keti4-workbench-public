function S = dali_n1_check(mpc, state, open_rows, opfset, meta, cfg, label)
%DALI_N1_CHECK  静态 N-1 校验（交流潮流；控制量固定为该方案的解，平衡机吸收功率变化）。
%
%   故障集（cfg.n1）：在运、两端最高电压 >= kv_min 的线路/变压器中的非桥元件；
%   桥元件（单独断开即解列）默认不计入通过率，单独报告被切除区域的负荷与出力（MW）；
%   可选纳入机组故障（include_gens）。
%   判据（与同设置下的 N-0 参考潮流比较）：
%     严格判据   ：故障后潮流收敛，且无任何过载、无任何电压越限；
%     增量判据   ：故障后潮流收敛，且不产生新的过载/电压越限，既有过载/越限恶化不超过容差。
%     事故判据   ：宽电压带 cfg.n1.emerg_vband 下的增量判据——不产生新的出带母线、既有出带不恶化超过容差，
%                  且无新增/恶化过载。N-0 出带母线少（8–33 个），方案间偏差远小于窄带增量判据。（v0.7 修正）
%   v0.7：电压检查只计 >= cfg.n1.v_kv_min 的母线（任务书终期考核范围 35 kV 及以上）。
%   电压限值与优化口径一致（dali_opf_vlims）；负载率按 RATE_A 单位解释（dali_branch_loading）。
%   v0.6：逐故障记录引起过载的支路与新增越限母线，并汇总过载责任支路。
%   频率：静态潮流无法计算，记 NOT_COMPUTABLE。

define_constants;
t0 = tic;
fprintf('\n--- Static N-1 [%s] ---\n', label);
nb = meta.nb; nl = meta.nl; f = meta.f; t = meta.t;
if nargin < 3 || isempty(open_rows), open_rows = zeros(0, 1); end
open_rows = open_rows(:);

%% case and options
m0 = mpc;
if cfg.n1.enforce_q_lims && ~isempty(opfset)
    m0.gen(:, QMIN) = opfset.qmin;
    m0.gen(:, QMAX) = opfset.qmax;
end
mpopt = mpoption('pf.alg', 'NR', 'pf.tol', 1e-6, 'pf.nr.max_it', 30, 'verbose', 0, 'out.all', 0, ...
    'pf.enforce_q_lims', double(cfg.n1.enforce_q_lims));
[vmin, vmax] = dali_opf_vlims(meta, cfg);
vmask = meta.base_kv >= cfg.n1.v_kv_min;
lim = cfg.n1.overload_limit;

%% contingency set on this scenario's topology
on = mpc.branch(:, BR_STATUS) == 1;
on(open_rows) = false;
isbr = dali_bridges(nb, f, t, on);
kvmax = max(meta.base_kv(f), meta.base_kv(t));
typ = (any(strcmpi(cfg.n1.types, 'line')) & meta.is_line) | (any(strcmpi(cfg.n1.types, 'xfmr')) & ~meta.is_line);
elig = on & kvmax >= cfg.n1.kv_min & typ;
cont_br = find(elig & ~isbr);
br_isl = find(elig & isbr);
gon = mpc.gen(:, GEN_STATUS) > 0;
cont_gen = zeros(0, 1);
if cfg.n1.include_gens
    cont_gen = find(gon & ~ismember(mpc.gen(:, GEN_BUS), cfg.boundary.buses) & ...
        abs(state.gen(:, PG)) >= cfg.n1.gen_min_MW);
end
fprintf('  contingencies: %d branches (%d lines, %d transformers) + %d generators | islanding (bridge) elements: %d\n', ...
    numel(cont_br), sum(meta.is_line(cont_br)), sum(~meta.is_line(cont_br)), numel(cont_gen), numel(br_isl));

%% N-0 reference under identical settings
mref = dali_pf_case_from_state(m0, state, meta, open_rows);
rref = safe_runpf(mref, mpopt);
S = new_summary(label, cfg);
S.n_contingencies = numel(cont_br) + numel(cont_gen);
S.n_branch = numel(cont_br); S.n_gen = numel(cont_gen);
S.n_islanding_elements = numel(br_isl);
if ~rref.success
    fprintf(2, '  N-0 reference power flow failed: N-1 not evaluated for %s\n', label);
    S.status = 'REFERENCE_PF_FAILED';
    return;
end
Lref = dali_branch_loading(rref, meta, cfg);
vref = rref.bus(:, VM);
violref = max(max(vref - vmax, vmin - vref), 0);
violref(~vmask) = 0;
S.ref_max_loading_pct = 100 * max(Lref(~isnan(Lref)));
S.ref_n_overload = sum(Lref > lim);
S.ref_n_vviol = sum(violref > cfg.n1.v_tol);
ve = cfg.n1.emerg_vband;
ve_vref = max(max(vref - ve(2), ve(1) - vref), 0);
ve_vref(~vmask) = 0;
S.ref_n_outside_emerg = sum(ve_vref > cfg.n1.v_tol);

%% contingency loop
nC = S.n_contingencies;
D = struct();
D.scenario = repmat({label}, nC, 1);
D.type = [repmat({'branch'}, numel(cont_br), 1); repmat({'gen'}, numel(cont_gen), 1)];
D.element_row = [cont_br; cont_gen];
D.from_bus = nan(nC, 1); D.to_bus = nan(nC, 1); D.kV = nan(nC, 1);
D.converged = zeros(nC, 1);
D.max_loading_pct = nan(nC, 1); D.worst_branch_row = nan(nC, 1);
D.n_new_overload = nan(nC, 1); D.n_worse_overload = nan(nC, 1);
D.n_new_vviol = nan(nC, 1); D.n_worse_vviol = nan(nC, 1);
D.max_added_vviol_pu = nan(nC, 1); D.worst_bus = nan(nC, 1);
D.pass_strict = zeros(nC, 1); D.pass_incremental = zeros(nC, 1);
D.fail_reason = repmat({''}, nC, 1);
D.overload_rows = repmat({''}, nC, 1); D.overload_max_pct = nan(nC, 1);
D.vviol_buses = repmat({''}, nC, 1);
D.n_outside_emerg = nan(nC, 1); D.pass_emergency = zeros(nC, 1);
ve = cfg.n1.emerg_vband;
all_ov = zeros(0, 1);
for c = 1:nC
    if c <= numel(cont_br)
        k = cont_br(c);
        D.from_bus(c) = meta.ids(f(k)); D.to_bus(c) = meta.ids(t(k)); D.kV(c) = kvmax(k);
        m = dali_pf_case_from_state(m0, state, meta, [open_rows; k]);
    else
        g = cont_gen(c - numel(cont_br));
        D.from_bus(c) = mpc.gen(g, GEN_BUS); D.kV(c) = meta.base_kv(meta.map(mpc.gen(g, GEN_BUS)));
        m = dali_pf_case_from_state(m0, state, meta, open_rows);
        m.gen(g, GEN_STATUS) = 0;
    end
    r = safe_runpf(m, mpopt);
    D.converged(c) = r.success;
    if ~r.success
        D.fail_reason{c} = 'NONCONV';
        continue;
    end
    L = dali_branch_loading(r, meta, cfg);
    v = r.bus(:, VM);
    viol = max(max(v - vmax, vmin - v), 0);
    viol(~vmask) = 0;
    newov = (L > lim) & ~(Lref > lim);
    worse = (Lref > lim) & (L > Lref + cfg.n1.worsen_tol_load);
    newv = (viol > cfg.n1.v_tol) & (violref <= cfg.n1.v_tol);
    worsev = (violref > cfg.n1.v_tol) & (viol > violref + cfg.n1.worsen_tol_v);
    [mx, iw] = max(L);
    if ~isnan(mx)
        D.max_loading_pct(c) = 100 * mx; D.worst_branch_row(c) = iw;
    end
    D.n_new_overload(c) = sum(newov); D.n_worse_overload(c) = sum(worse);
    D.n_new_vviol(c) = sum(newv); D.n_worse_vviol(c) = sum(worsev);
    added = (viol - violref) .* (newv | worsev);
    [ma, ib] = max(added);
    if ma > 0
        D.max_added_vviol_pu(c) = ma; D.worst_bus(c) = meta.ids(ib);
    else
        D.max_added_vviol_pu(c) = 0;
    end
    D.pass_strict(c) = ~any(L > lim) && ~any(viol > cfg.n1.v_tol);
    fo = any(newov | worse); fv = any(newv | worsev);
    ovr = find(newov | worse);
    if ~isempty(ovr)
        [~, o] = sort(L(ovr), 'descend'); ovr = ovr(o);
        D.overload_rows{c} = dali_rows2str(ovr(1:min(5, numel(ovr))));
        D.overload_max_pct(c) = 100 * L(ovr(1));
        all_ov = [all_ov; ovr(:)]; %#ok<AGROW>
    end
    vb = find(newv | worsev);
    if ~isempty(vb)
        [~, o] = sort(viol(vb) - violref(vb), 'descend'); vb = vb(o);
        D.vviol_buses{c} = dali_rows2str(meta.ids(vb(1:min(5, numel(vb)))));
    end
    ve_v = max(max(v - ve(2), ve(1) - v), 0);
    ve_v(~vmask) = 0;
    ne = (ve_v > cfg.n1.v_tol & ve_vref <= cfg.n1.v_tol) | ...
        (ve_vref > cfg.n1.v_tol & ve_v > ve_vref + cfg.n1.worsen_tol_v);
    D.n_outside_emerg(c) = sum(ne);
    D.pass_emergency(c) = ~any(ne) && ~fo;
    D.pass_incremental(c) = ~fo && ~fv;
    if fo && fv
        D.fail_reason{c} = 'OVERLOAD+VOLTAGE';
    elseif fo
        D.fail_reason{c} = 'OVERLOAD';
    elseif fv
        D.fail_reason{c} = 'VOLTAGE';
    end
end

%% islanding elements (topology only)
I = struct();
I.scenario = repmat({label}, numel(br_isl), 1);
I.branch_row = br_isl;
I.from_bus = meta.ids(f(br_isl)); I.to_bus = meta.ids(t(br_isl)); I.kV = kvmax(br_isl);
I.island_buses = zeros(numel(br_isl), 1);
I.lost_load_MW = zeros(numel(br_isl), 1); I.lost_gen_MW = zeros(numel(br_isl), 1);
refi = find(mpc.bus(:, BUS_TYPE) == REF, 1);
E = find(on);
A = sparse([f(E); t(E)], [t(E); f(E)], 1, nb, nb);
gbi = meta.map(mpc.gen(:, GEN_BUS));
pdpos = max(state.bus(:, PD), 0);
for j = 1:numel(br_isl)
    k = br_isl(j);
    Ak = A;
    Ak(f(k), t(k)) = Ak(f(k), t(k)) - 1;
    Ak(t(k), f(k)) = Ak(t(k), f(k)) - 1;
    seen = false(nb, 1); seen(refi) = true; q = refi;
    while ~isempty(q)
        [nbrs, ~] = find(Ak(:, q) > 0);
        nbrs = unique(nbrs); nbrs = nbrs(~seen(nbrs));
        seen(nbrs) = true; q = nbrs;
    end
    isl = ~seen;
    I.island_buses(j) = sum(isl);
    I.lost_load_MW(j) = sum(pdpos(isl));
    I.lost_gen_MW(j) = sum(state.gen(gon & isl(gbi), PG));
end

%% summary
S.n_converged = sum(D.converged);
S.n_fail_nonconv = sum(~D.converged);
S.n_pass_strict = sum(D.pass_strict);
S.n_pass_incremental = sum(D.pass_incremental);
S.n_pass_emergency = sum(D.pass_emergency);
S.n_fail_emerg_voltage = sum(D.converged & D.n_outside_emerg > 0);
if ~isempty(all_ov)
    [u, ~, ic] = unique(all_ov);
    cnt = accumarray(ic, 1);
    [cnt, o] = sort(cnt, 'descend'); u = u(o);
    parts = arrayfun(@(a, b) sprintf('row%d(%d-%d)x%d', a, meta.ids(f(a)), meta.ids(t(a)), b), ...
        u(1:min(8, numel(u))), cnt(1:min(8, numel(u))), 'UniformOutput', false);
    S.overload_culprits = strjoin(parts.', ' ');
end
S.n_fail_overload = sum(contains(D.fail_reason, 'OVERLOAD'));
S.n_fail_voltage = sum(contains(D.fail_reason, 'VOLTAGE'));
S.n_fail_voltage_gt_0p01 = sum(contains(D.fail_reason, 'VOLTAGE') & D.max_added_vviol_pu > 0.01);
den = nC;
if cfg.n1.count_bridges
    den = nC + numel(br_isl);     % islanding elements count as failures
end
if den > 0
    S.pass_rate_strict_pct = 100 * S.n_pass_strict / den;
    S.pass_rate_incremental_pct = 100 * S.n_pass_incremental / den;
    S.pass_rate_emergency_pct = 100 * S.n_pass_emergency / den;
end
fail = find(~D.pass_incremental);
if ~isempty(fail)
    [~, w] = max(D.max_added_vviol_pu(fail) + (D.n_new_overload(fail) > 0) * 10);
    c = fail(w);
    S.worst_contingency = sprintf('%s %d (%g-%g, %g kV): %s', D.type{c}, D.element_row(c), D.from_bus(c), ...
        D.to_bus(c), D.kV(c), D.fail_reason{c});
end
if any(~isnan(D.max_loading_pct)), S.max_post_loading_pct = max(D.max_loading_pct); end
if ~isempty(br_isl)
    S.n_islands_load_gt_1MW = sum(I.lost_load_MW > 1);
    S.max_island_lost_load_MW = max(I.lost_load_MW);
    S.max_island_lost_gen_MW = max(I.lost_gen_MW);
end
S.time_s = toc(t0);
S.status = 'EVALUATED';
safe = matlab.lang.makeValidName(label);
writetable(struct2table(D), fullfile(cfg.outdir, ['n1_detail_' safe '.csv']));
writetable(struct2table(I), fullfile(cfg.outdir, ['n1_islanding_' safe '.csv']));
fprintf(['  N-1 [%s]: %d contingencies, converged %d | pass strict %d (%.1f%%), incremental %d (%.1f%%) | ', ...
    'fails: overload %d, voltage %d (of which >0.01 pu: %d), nonconv %d | %.1f s\n'], label, nC, S.n_converged, ...
    S.n_pass_strict, S.pass_rate_strict_pct, S.n_pass_incremental, S.pass_rate_incremental_pct, ...
    S.n_fail_overload, S.n_fail_voltage, S.n_fail_voltage_gt_0p01, S.n_fail_nonconv, S.time_s);
fprintf(['  emergency criterion (band [%.2f, %.2f] at >= %g kV, no new departure / no worsening, no new overload): ', ...
    'pass %d (%.1f%%); N-0 buses outside band %d\n'], cfg.n1.emerg_vband(1), cfg.n1.emerg_vband(2), cfg.n1.v_kv_min, ...
    S.n_pass_emergency, S.pass_rate_emergency_pct, S.ref_n_outside_emerg);
fprintf('  overload culprits (row x #contingencies): %s\n', S.overload_culprits);
fprintf('  N-0 reference: max loading %.1f%%, overloaded %d, voltage-violating buses %d | worst: %s\n', ...
    S.ref_max_loading_pct, S.ref_n_overload, S.ref_n_vviol, S.worst_contingency);
fprintf('  islanding elements: %d, of which %d cut >1 MW load; max lost load %.1f MW, max lost generation %.1f MW\n', ...
    S.n_islanding_elements, S.n_islands_load_gt_1MW, S.max_island_lost_load_MW, S.max_island_lost_gen_MW);
end

%% ------------------------------------------------------------------------
function S = new_summary(label, cfg)
S = struct();
S.label = label;
S.vlim_source = cfg.vlim.opf_source;
S.count_bridges = double(cfg.n1.count_bridges);
S.enforce_q_lims = double(cfg.n1.enforce_q_lims);
S.n_contingencies = 0; S.n_branch = 0; S.n_gen = 0; S.n_islanding_elements = 0;
S.ref_max_loading_pct = NaN; S.ref_n_overload = NaN; S.ref_n_vviol = NaN; S.ref_n_outside_emerg = NaN;
S.n_converged = NaN; S.n_fail_nonconv = NaN;
S.n_pass_strict = NaN; S.pass_rate_strict_pct = NaN;
S.n_pass_incremental = NaN; S.pass_rate_incremental_pct = NaN;
S.n_pass_emergency = NaN; S.pass_rate_emergency_pct = NaN; S.n_fail_emerg_voltage = NaN;
S.overload_culprits = '';
S.n_fail_overload = NaN; S.n_fail_voltage = NaN; S.n_fail_voltage_gt_0p01 = NaN;
S.worst_contingency = '';
S.max_post_loading_pct = NaN;
S.n_islands_load_gt_1MW = NaN; S.max_island_lost_load_MW = NaN; S.max_island_lost_gen_MW = NaN;
S.frequency = 'NOT_COMPUTABLE_STATIC';
S.time_s = NaN;
S.status = 'NOT_EVALUATED';
end

function r = safe_runpf(m, mpopt)
try
    r = runpf(m, mpopt);
catch
    r = struct('success', 0);
end
end
