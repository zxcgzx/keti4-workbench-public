function isbr = dali_bridges(nb, f, t, on)
%DALI_BRIDGES  多重图桥判定：逐条删除一个在运支路ID后检查两端可达性（并联支路保留独立ID）。
nl = numel(f);
E = find(on(:));
isbr = false(nl, 1);
deg = accumarray([f(E); t(E)], 1, [nb 1]);
adjN = cell(nb, 1); adjE = cell(nb, 1);
for i = 1:nb
    adjN{i} = zeros(1, deg(i)); adjE{i} = zeros(1, deg(i));
end
pos = zeros(nb, 1);
for k = E.'
    a = f(k); b = t(k);
    pos(a) = pos(a) + 1; adjN{a}(pos(a)) = b; adjE{a}(pos(a)) = k;
    pos(b) = pos(b) + 1; adjN{b}(pos(b)) = a; adjE{b}(pos(b)) = k;
end
stack = zeros(nb, 1);
for k = E.'
    s = f(k); tg = t(k);
    if s == tg, continue; end
    seen = false(nb, 1); seen(s) = true;
    top = 1; stack(1) = s; found = false;
    while top > 0 && ~found
        u = stack(top); top = top - 1;
        nu = adjN{u}; ne = adjE{u};
        for j = 1:numel(nu)
            v = nu(j);
            if ne(j) ~= k && ~seen(v)
                if v == tg, found = true; break; end
                seen(v) = true; top = top + 1; stack(top) = v;
            end
        end
    end
    isbr(k) = ~found;
end
end
