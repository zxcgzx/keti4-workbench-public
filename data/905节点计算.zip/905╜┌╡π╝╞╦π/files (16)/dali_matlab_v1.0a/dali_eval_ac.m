function E = dali_eval_ac(res, meta, cfg, vpen, label, opfset)
%DALI_EVAL_AC  统一的AC评价函数：所有方案（断面复现、固定拓扑OPF、OTS校核）都用它复算。
%   不读取任何求解器目标值；统一目标 J_AC = c_loss*网损MW + vpen*Σ电压越限(p.u.,优化口径母线)。
%   电压按文件VMIN/VMAX与任务书代理口径分别统计；负载率按 RATE_A 两种单位解释分别给出。
%   N-1、CPF、新能源消纳率、真实发电成本：NOT_COMPUTABLE。

define_constants;
if nargin < 6, opfset = []; end
nb = meta.nb;
E = struct();
E.label = label;
E.vpen = vpen;
E.converged = double(isstruct(res) && isfield(res, 'success') && res.success == 1 && isfield(res, 'bus'));
num = {'n_branch_out', 'loss_MW', 'loss_Mvar', 'P_slack_MW', 'max_mis_MW', 'max_mis_Mvar', ...
    'vm_min', 'vm_max', 'n_v_over', 'n_v_under', 'max_v_over', 'max_v_under', 'sum_v_viol', ...
    'n_v_viol_nonboundary', 'sum_v_viol_opf_scope', ...
    'nviol_500kV', 'nviol_220kV', 'nviol_110kV', 'nviol_35kV', 'nviol_10kV', 'nviol_6kV', ...
    'tb_vq_rate_110_35kV_pct', 'tb_n_110_35kV', 'dU_mean', 'dU_std', 'dU_absmean', 'I_VD_literal', 'I_VD_abs', ...
    'line_n', 'lineP_mean_pct', 'lineP_std_pct', 'lineP_max_pct', 'I_LR', ...
    'lineI_mean_pct', 'lineI_max_pct', 'lineS_literal_max_pct', 'n_line_I_over100', ...
    'xfmr_I_max_pct', 'n_xfmr_I_over100', 'n_islands', 'n_gen_Q_outside_trial', ...
    'loss_rate_posPD_nonboundary_pct', 'loss_rate_posPD_le110kV_pct', 'J_AC'};
for i = 1:numel(num)
    E.(num{i}) = NaN;
end
E.open_rows = '';
E.status = 'NOT_EVALUATED';
E.N1 = 'NOT_COMPUTABLE';
E.renewable_curtailment = 'NOT_COMPUTABLE';
E.gen_cost = 'NOT_COMPUTABLE';
if ~E.converged
    E.status = 'NOT_CONVERGED';
    return;
end

bus = res.bus; gen = res.gen; br = res.branch;
on = br(:, BR_STATUS) == 1;
pf = br(:, PF); qf = br(:, QF); pt = br(:, PT); qt = br(:, QT);
pf(~on) = 0; qf(~on) = 0; pt(~on) = 0; qt(~on) = 0;
E.n_branch_out = sum(~on);
E.open_rows = dali_rows2str(find(~on));
E.loss_MW = sum(pf + pt);
E.loss_Mvar = sum(qf + qt);
gon = gen(:, GEN_STATUS) > 0;
E.P_slack_MW = sum(gen(gon & gen(:, GEN_BUS) == meta.ref_bus, PG));

%% physics check: nodal mismatch of the returned state
busI = bus(:, 1:13); busI(:, BUS_I) = (1:nb).';
brI = br(:, 1:13); brI(:, F_BUS) = meta.map(br(:, F_BUS)); brI(:, T_BUS) = meta.map(br(:, T_BUS));
genI = gen(:, 1:21); genI(:, GEN_BUS) = meta.map(gen(:, GEN_BUS));
Ybus = makeYbus(res.baseMVA, busI, brI);
V = bus(:, VM) .* exp(1j * bus(:, VA) * pi / 180);
Sbus = makeSbus(res.baseMVA, busI, genI);
mis = (V .* conj(Ybus * V) - Sbus) * res.baseMVA;
E.max_mis_MW = max(abs(real(mis)));
E.max_mis_Mvar = max(abs(imag(mis)));

%% voltages (file limits = evaluation scope)
vm = bus(:, VM);
over = max(vm - meta.eval_vmax, 0);
under = max(meta.eval_vmin - vm, 0);
viol = over + under;
E.vm_min = min(vm); E.vm_max = max(vm);
E.n_v_over = sum(over > 1e-6);
E.n_v_under = sum(under > 1e-6);
E.max_v_over = max(over);
E.max_v_under = max(under);
E.sum_v_viol = sum(viol);
E.n_v_viol_nonboundary = sum(viol > 1e-6 & ~meta.is_boundary);
kvs = [500 220 110 35 10 6];
for k = kvs
    E.(sprintf('nviol_%dkV', k)) = sum(viol > 1e-6 & meta.base_kv == k);
end
% optimization scope (same limits/buses as the soft-limit penalty)
[vmin_o, vmax_o] = dali_opf_vlims(meta, cfg);
scope = true(nb, 1);
if cfg.boundary.fix_voltage, scope = ~meta.is_boundary; end
viol_o = max(vm - vmax_o, 0) + max(vmin_o - vm, 0);
E.sum_v_viol_opf_scope = sum(viol_o(scope));

% task-book proxy: 110/35 kV buses within [0.97, 1.07] (no substation mapping yet)
sel = ismember(meta.base_kv, cfg.taskbook.v_kv);
okb = vm >= cfg.taskbook.v_band(1) - 1e-9 & vm <= cfg.taskbook.v_band(2) + 1e-9;
E.tb_n_110_35kV = sum(sel);
E.tb_vq_rate_110_35kV_pct = 100 * mean(okb(sel));
% voltage deviation (U_N = 1 p.u.); I_VD read from task book p.8, interpretation to confirm
du = vm - 1;
mu = mean(du); sg = std(du, 1);
E.dU_mean = mu; E.dU_std = sg; E.dU_absmean = mean(abs(du));
if sg > 0
    E.I_VD_literal = 1 - mu * 0.5 * erfc((-1 - mu) / (sg * sqrt(2)));
end
% v0.8: same formula with the mean ABSOLUTE deviation (literal signed mean can exceed 1 when voltages
% sit below nominal on average); the integral term is ~1 for any realistic voltage, so I_VD ~ 1 - mean.
ma = mean(abs(du)); sa = std(abs(du), 1);
if sa > 0
    E.I_VD_abs = 1 - ma * 0.5 * erfc((-1 - ma) / (sa * sqrt(2)));
end

%% loading
kvf = meta.base_kv(meta.f); kvt = meta.base_kv(meta.t);
vmf = vm(meta.f); vmt = vm(meta.t);
Sf = abs(pf + 1j * qf); St = abs(pt + 1j * qt);
If_A = Sf * 1000 ./ (sqrt(3) * vmf .* kvf);
It_A = St * 1000 ./ (sqrt(3) * vmt .* kvt);
ra = meta.rateA_src;
isl = meta.is_line & on & ra > 0;
lp = max(abs(pf), abs(pt)) ./ meta.rate_MVA_if_A;     % task book: P / P_max (A interpretation)
li = max(If_A, It_A) ./ ra;                            % current loading (A interpretation)
ls = max(Sf, St) ./ ra;                                % literal MVA interpretation
E.line_n = sum(isl);
if any(isl)
    x = lp(isl);
    E.lineP_mean_pct = 100 * mean(x);
    E.lineP_std_pct = 100 * std(x, 1);
    E.lineP_max_pct = 100 * max(x);
    m1 = mean(x); s1 = std(x, 1);
    if s1 > 0
        E.I_LR = (1 - m1) * 0.5 * erfc(-(1 - m1) / (s1 * sqrt(2)));
    end
    E.lineI_mean_pct = 100 * mean(li(isl));
    E.lineI_max_pct = 100 * max(li(isl));
    E.lineS_literal_max_pct = 100 * max(ls(isl));
    E.n_line_I_over100 = sum(li(isl) > 1);
end
isx = ~meta.is_line & on & ra > 0;
if any(isx)
    lx = If_A(isx) ./ ra(isx);    % HV (from) side current vs rating
    E.xfmr_I_max_pct = 100 * max(lx);
    E.n_xfmr_I_over100 = sum(lx > 1);
end

%% connectivity, generator Q vs trial permissions
E.n_islands = dali_ncomp(nb, meta.f, meta.t, on);
if ~isempty(opfset)
    q = gen(:, QG);
    E.n_gen_Q_outside_trial = sum(gon & (q > opfset.qmax + 1e-4 | q < opfset.qmin - 1e-4));
end

%% loss rate (denominator NOT confirmed -> two candidates)
E.loss_rate_posPD_nonboundary_pct = 100 * E.loss_MW / meta.posPD_nonboundary;
E.loss_rate_posPD_le110kV_pct = 100 * E.loss_MW / meta.posPD_le110kV;

%% unified objective
E.J_AC = cfg.obj.c_loss * E.loss_MW + vpen * E.sum_v_viol_opf_scope;

clean = E.n_v_over == 0 && E.n_v_under == 0 && ...
    (isnan(E.n_line_I_over100) || E.n_line_I_over100 == 0) && ...
    (isnan(E.n_xfmr_I_over100) || E.n_xfmr_I_over100 == 0) && E.n_islands == 1;
if clean
    E.status = 'NO_VIOLATION_IN_EVALUATED_SCOPE';
else
    E.status = 'DIAGNOSTIC_ONLY';
end
end
