function C = dali_cpf_margin(mpc, state, open_rows, opfset, meta, cfg, label)
%DALI_CPF_MARGIN  静态电压稳定负荷裕度（任务书 4.2 稳定性指标，MATPOWER 连续潮流）。
%   负荷增长方向：非边界、<= cfg.cpf.kv_max 母线上的正 PD（恒功率因数同比放大）；
%   本地机组有功固定（K_G = 0），平衡机承担增量；机组无功按试验范围限制。
%   lambda_max 为到达鼻点时的负荷增长倍数（target_scale = 1 时即增长百分比/100）。
%   v0.8：只有 done_msg 表明到达鼻点（steady state loading limit）才记 EVALUATED；
%         校正步不收敛等提前终止时先以 step/4 重试，仍未到鼻点则记 LOWER_BOUND（lambda 为下界）。
%         步数取 results.cpf.iterations（results.cpf.steps 是各步步长向量，v0.7 误用导致打印乱行）。
define_constants;
t0 = tic;
C = struct('label', label, 'scope', '', 'P_scaled_MW', NaN, 'lambda_max', NaN, 'margin_MW', NaN, ...
    'margin_pct', NaN, 'steps', NaN, 'nose_reached', 0, 'retry', '', 'stop_reason', '', 'time_s', NaN, ...
    'status', 'NOT_EVALUATED');
if nargin < 3 || isempty(open_rows), open_rows = zeros(0, 1); end
mb = dali_pf_case_from_state(mpc, state, meta, open_rows(:));
if cfg.cpf.enforce_q_lims && ~isempty(opfset)
    mb.gen(:, QMIN) = opfset.qmin;
    mb.gen(:, QMAX) = opfset.qmax;
end
sel = mb.bus(:, PD) > 0 & meta.base_kv <= cfg.cpf.kv_max & ~meta.is_boundary;
C.scope = sprintf('positive PD, non-boundary buses <= %g kV (%d buses), const. PF; local gen P fixed', ...
    cfg.cpf.kv_max, sum(sel));
C.P_scaled_MW = sum(mb.bus(sel, PD));
mt = mb;
mt.bus(sel, PD) = mb.bus(sel, PD) * (1 + cfg.cpf.target_scale);
mt.bus(sel, QD) = mb.bus(sel, QD) * (1 + cfg.cpf.target_scale);
fprintf('--- CPF load margin [%s]: scaling %.1f MW of load ---\n', label, C.P_scaled_MW);

[lam, it, msg, nose, err] = run_once(mb, mt, cfg, cfg.cpf.step);
if isempty(err) && ~nose
    fprintf('  first CPF stopped before the nose (%s) -> retry with step %.4f\n', msg, cfg.cpf.step / 4);
    [lam2, it2, msg2, nose2, err2] = run_once(mb, mt, cfg, cfg.cpf.step / 4);
    if isempty(err2) && (nose2 || lam2 > lam)
        lam = lam2; it = it2; msg = msg2; nose = nose2;
        C.retry = 'step/4 accepted';
    else
        C.retry = 'step/4 not better';
    end
end
C.time_s = toc(t0);
if ~isempty(err)
    C.status = ['ERROR: ' err];
    fprintf(2, '  runcpf raised: %s\n', err);
    return;
end
C.lambda_max = lam;
C.steps = it;
C.stop_reason = msg;
C.nose_reached = double(nose);
C.margin_pct = 100 * lam * cfg.cpf.target_scale;
C.margin_MW = lam * cfg.cpf.target_scale * C.P_scaled_MW;
if nose
    C.status = 'EVALUATED';
elseif isfinite(lam)
    C.status = 'LOWER_BOUND';
else
    C.status = 'NO_LAMBDA';
end
fprintf('  CPF [%s]: lambda_max %.4f -> load margin %.1f%% (%.1f MW) | %s | %d steps, %.1f s | %s\n', label, ...
    lam, C.margin_pct, C.margin_MW, C.status, it, C.time_s, msg);
end

%% ------------------------------------------------------------------------
function [lam, it, msg, nose, err] = run_once(mb, mt, cfg, step)
lam = NaN; it = NaN; msg = ''; nose = false; err = '';
mpopt = mpoption('verbose', 0, 'out.all', 0, 'pf.tol', 1e-6);
mpopt = try_opt(mpopt, 'cpf.stop_at', 'NOSE');
mpopt = try_opt(mpopt, 'cpf.step', step);
mpopt = try_opt(mpopt, 'cpf.adapt_step', 1);
mpopt = try_opt(mpopt, 'cpf.enforce_q_lims', double(cfg.cpf.enforce_q_lims));
try
    r = runcpf(mb, mt, mpopt);
catch e
    err = e.message;
    return;
end
if ~isfield(r, 'cpf'), err = 'no cpf field in results'; return; end
cp = r.cpf;
if isfield(cp, 'max_lam') && ~isempty(cp.max_lam)
    lam = cp.max_lam(1);
elseif isfield(cp, 'lam') && ~isempty(cp.lam)
    lam = max(cp.lam(:));
end
if isfield(cp, 'iterations') && ~isempty(cp.iterations)
    it = cp.iterations(1);
elseif isfield(cp, 'lam')
    it = numel(cp.lam) - 1;
end
if isfield(cp, 'done_msg'), msg = char(cp.done_msg); end
nose = contains(lower(msg), 'steady state loading limit') || contains(lower(msg), 'nose');
end

function mpopt = try_opt(mpopt, name, val)
try
    mpopt = mpoption(mpopt, name, val);
catch e
    fprintf('  (mpoption %s not available: %s)\n', name, e.message);
end
end
