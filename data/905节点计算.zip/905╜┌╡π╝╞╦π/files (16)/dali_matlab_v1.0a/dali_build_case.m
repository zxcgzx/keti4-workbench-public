function [mpc, mpc_raw, meta, rev, calib] = dali_build_case(raw, topo, cfg)
%DALI_BUILD_CASE  生成 MATPOWER 算例：
%   mpc_raw : 字段直接搬运（字面解释，仅对照，不作计算口径）
%   mpc     : equivalent_v1，按 cfg 中的临时假设逐项修订，每项写入 rev（revision_log）
%   meta    : 评价所需的原始限值、映射、额定值换算、导出潮流等（不进入 mpc，避免被求解器改写）
%   calib   : 1000 条支路逐条阻抗反算对照（branch_calibration.csv）

define_constants;
fprintf('\n===== STEP 1b: build MATPOWER cases =====\n');
bc = raw.bus_col; gc = raw.gen_col; rc = raw.branch_col;
base = raw.baseMVA;
Bm = raw.bus; Gm = raw.gen; Rm = raw.branch;
nb = size(Bm, 1); ng = size(Gm, 1); nl = size(Rm, 1);
ids = Bm(:, bc.BUS_I);
map = topo.map;
f = topo.f; t = topo.t;

%% ---------------- raw literal case ----------------
bus = zeros(nb, 13);
bus(:, [BUS_I BUS_TYPE PD QD GS BS BUS_AREA VM VA BASE_KV ZONE VMAX VMIN]) = ...
    Bm(:, [bc.BUS_I bc.BUS_TYPE bc.PD bc.QD bc.GS bc.BS bc.BUS_AREA bc.VM bc.VA bc.BASE_KV bc.ZONE bc.VMAX bc.VMIN]);
gen = zeros(ng, 21);
gen(:, [GEN_BUS PG QG QMAX QMIN VG MBASE GEN_STATUS PMAX PMIN]) = ...
    Gm(:, [gc.GEN_BUS gc.PG gc.QG gc.QMAX gc.QMIN gc.VG gc.MBASE gc.GEN_STATUS gc.PMAX gc.PMIN]);
branch = zeros(nl, 13);
branch(:, [F_BUS T_BUS BR_R BR_X BR_B RATE_A RATE_B RATE_C TAP SHIFT BR_STATUS ANGMIN ANGMAX]) = ...
    Rm(:, [rc.F_BUS rc.T_BUS rc.BR_R rc.BR_X rc.BR_B rc.RATE_A rc.RATE_B rc.RATE_C rc.TAP rc.SHIFT rc.BR_STATUS rc.ANGMIN rc.ANGMAX]);
mpc_raw = struct('version', '2', 'baseMVA', base, 'bus', bus, 'gen', gen, 'branch', branch);
mpc_raw.gencost = repmat([2 0 0 2 0 0], ng, 1);

mpc = mpc_raw;
rev = new_rev();

%% ---------------- R1: VA unit ----------------
if strcmpi(cfg.conv.va_unit, 'rad')
    va_rad = Bm(:, bc.VA);
    mpc.bus(:, VA) = va_rad * 180 / pi;
    rev = add_rev(rev, 'GLOBAL', 'bus', NaN, NaN, 'ALL', 'VA', NaN, NaN, 'VA_RAD_TO_DEG', ...
        'source VA treated as radians (supported by flow back-calculation)');
else
    va_rad = Bm(:, bc.VA) * pi / 180;
end

%% ---------------- R2: BR_B per-end -> total ----------------
mpc.branch(:, BR_B) = cfg.conv.b_factor * Rm(:, rc.BR_B);
rev = add_rev(rev, 'GLOBAL', 'branch', NaN, NaN, 'ALL', 'BR_B', NaN, cfg.conv.b_factor, ...
    'BR_B_TIMES_FACTOR', 'source BR_B treated as per-end susceptance; MATPOWER total = factor * source');

%% ---------------- R3: per-branch impedance calibration ----------------
vm_s = Bm(:, bc.VM);
Vs = vm_s .* exp(1j * va_rad);
Sfx = Rm(:, rc.PF) + 1j * Rm(:, rc.QF);
Stx = Rm(:, rc.PT) + 1j * Rm(:, rc.QT);
r0 = Rm(:, rc.BR_R); x0 = Rm(:, rc.BR_X);
bt = mpc.branch(:, BR_B);
tp = Rm(:, rc.TAP); tpc = tp; tpc(tp == 0) = 1;
shd = Rm(:, rc.SHIFT);
on = Rm(:, rc.BR_STATUS) == 1;
if any(r0 == 0 & x0 == 0)
    error('dali:case', 'Exact zero-impedance branch needs an explicit ideal-connection model');
end
flag = tp ~= 0 & x0 > 0 & Rm(:, rc.BR_B) == 0 & ...
    (real(Sfx) + real(Stx)) > 1e-9 & (imag(Sfx) + imag(Stx)) < -1e-9;
nz = tp ~= 0;
xflip = x0 .* (1 - 2 * flag);
TR = [r0, r0, r0 ./ tpc, r0 ./ tpc];
TX = [x0, xflip, x0 ./ tpc, xflip ./ tpc];
applic = [true(nl, 1), flag, nz, flag & nz];
tnames = {'H2_RAW_RX', 'FLIP_X_LOSS_SIGN', 'RX_DIV_TAP', 'FLIP_X_AND_RX_DIV_TAP'};
err = inf(nl, 4); errP = inf(nl, 4); errQ = inf(nl, 4);
for j = 1:4
    [sf, st] = branch_flows(Vs, f, t, TR(:, j), TX(:, j), bt, tpc, shd, base);
    dsf = sf - Sfx; dst = st - Stx;
    err(:, j)  = max(abs(dsf), abs(dst));
    errP(:, j) = max(abs(real(dsf)), abs(real(dst)));
    errQ(:, j) = max(abs(imag(dsf)), abs(imag(dst)));
end
err(~applic) = Inf; errP(~applic) = Inf; errQ(~applic) = Inf;
choice = ones(nl, 1);
switch lower(cfg.conv.imp_policy)
    case 'perbranch_bestfit'
        [emin, jmin] = min(err, [], 2);
        use = on & (emin < err(:, 1) - cfg.conv.imp_min_improve_MVA);
        choice(use) = jmin(use);
    case 'rule_all'
        choice(nz & ~flag) = 3;
        choice(nz & flag) = 4;
    case 'none'
    otherwise
        error('dali:case', 'Unknown cfg.conv.imp_policy');
end
lin = sub2ind([nl 4], (1:nl).', choice);
r_new = TR(lin); x_new = TX(lin);
mpc.branch(:, BR_R) = r_new;
mpc.branch(:, BR_X) = x_new;
for k = find(choice > 1).'
    note = sprintf('S_err %.4f -> %.4f MVA at exported V (calibration uses exported flows; not independent validation)', ...
        err(k, 1), err(k, choice(k)));
    if r_new(k) ~= r0(k)
        rev = add_rev(rev, 'BRANCH_IMPEDANCE', 'branch', k, raw.branch_line(k), ...
            sprintf('%d-%d', ids(f(k)), ids(t(k))), 'BR_R', r0(k), r_new(k), tnames{choice(k)}, note);
    end
    if x_new(k) ~= x0(k)
        rev = add_rev(rev, 'BRANCH_IMPEDANCE', 'branch', k, raw.branch_line(k), ...
            sprintf('%d-%d', ids(f(k)), ids(t(k))), 'BR_X', x0(k), x_new(k), tnames{choice(k)}, note);
    end
end
err_final = err(lin);
fprintf('Impedance policy %s: changed %d branches (', cfg.conv.imp_policy, sum(choice > 1));
for j = 2:4, fprintf(' %s=%d', tnames{j}, sum(choice == j)); end
fprintf(' )\n');
fprintf('Branches with S_err > 1 MVA: H2 %d -> final %d (max %.3f MVA)\n', ...
    sum(err(on, 1) > 1), sum(err_final(on) > 1), max(err_final(on)));

calib = struct();
calib.branch_row = (1:nl).';
calib.source_line = raw.branch_line(:);
calib.from_bus = ids(f); calib.to_bus = ids(t);
calib.from_kV = Bm(f, bc.BASE_KV); calib.to_kV = Bm(t, bc.BASE_KV);
calib.TAP = tp; calib.loss_sign_flag = double(flag);
calib.R_src = r0; calib.X_src = x0; calib.B_src = Rm(:, rc.BR_B);
calib.R_used = r_new; calib.X_used = x_new; calib.B_used = bt;
for j = 1:4
    calib.(['Serr_' tnames{j}]) = err(:, j);
end
calib.Perr_used = errP(lin); calib.Qerr_used = errQ(lin); calib.Serr_used = err_final;
calib.choice = tnames(choice).';
calib.confirmed = repmat({'NO'}, nl, 1);

%% ---------------- R4: boundary PD ----------------
for b = cfg.boundary.zero_PD_buses(:).'
    i = map(b);
    old = mpc.bus(i, PD);
    mpc.bus(i, PD) = 0;
    rev = add_rev(rev, 'BOUNDARY', 'bus', i, raw.bus_line(i), num2str(b), 'PD', old, 0, ...
        'ZERO_DUPLICATE_NEGATIVE_PD', 'temporary assumption: negative PD appears double counted with generator PG');
end

%% ---------------- R5: merge offsetting generators ----------------
for b = cfg.boundary.merge_gen_buses(:).'
    rows = find(mpc.gen(:, GEN_BUS) == b & mpc.gen(:, GEN_STATUS) > 0);
    if numel(rows) < 2, continue; end
    keep = rows(1);
    others = rows(2:end);
    old = mpc.gen(rows, [PG QG QMAX QMIN]);
    mpc.gen(keep, PG) = sum(old(:, 1));
    mpc.gen(keep, QG) = sum(old(:, 2));
    mpc.gen(keep, QMAX) = sum(old(:, 3));
    mpc.gen(keep, QMIN) = sum(old(:, 4));
    mpc.gen(others, GEN_STATUS) = 0;
    mpc.gen(others, [PG QG]) = 0;
    rev = add_rev(rev, 'BOUNDARY', 'gen', keep, raw.gen_line(keep), num2str(b), 'PG', old(1, 1), ...
        mpc.gen(keep, PG), 'MERGE_OFFSETTING_GEN', sprintf('net PG of rows %s; bus PD kept', mat2str(rows.')));
    rev = add_rev(rev, 'BOUNDARY', 'gen', keep, raw.gen_line(keep), num2str(b), 'QG', old(1, 2), ...
        mpc.gen(keep, QG), 'MERGE_OFFSETTING_GEN', 'sum of QG');
    for o = others(:).'
        rev = add_rev(rev, 'BOUNDARY', 'gen', o, raw.gen_line(o), num2str(b), 'GEN_STATUS', 1, 0, ...
            'MERGE_OFFSETTING_GEN', 'merged into first row; row kept for traceability');
    end
end

%% ---------------- R6: reactive equivalents at PQ buses ----------------
[Scalc, ~] = nodal_injection(mpc, Vs, f, t, base);
on_g = mpc.gen(:, GEN_STATUS) > 0;
gi = map(mpc.gen(:, GEN_BUS));
Sg = accumarray(gi(on_g), mpc.gen(on_g, PG) + 1j * mpc.gen(on_g, QG), [nb 1]);
Sd = mpc.bus(:, PD) + 1j * mpc.bus(:, QD);
res_before = (Sg - Sd) - Scalc;              % >0: more injection than the network takes
dQ = -imag(res_before);                       % missing injection (Mvar)
pq = mpc.bus(:, BUS_TYPE) == PQ;
apply = pq & abs(dQ) > cfg.qeq.threshold_Mvar;
if ~cfg.qeq.allow_negative
    apply = apply & dQ > 0;
end
switch upper(cfg.qeq.mode)
    case 'BS'
        for i = find(apply).'
            old = mpc.bus(i, BS);
            mpc.bus(i, BS) = old + dQ(i) / vm_s(i)^2;
            rev = add_rev(rev, 'Q_EQUIVALENT', 'bus', i, raw.bus_line(i), num2str(ids(i)), 'BS', old, ...
                mpc.bus(i, BS), 'BS_FROM_Q_RESIDUAL', sprintf('dQ=%.4f Mvar at VM=%.5f; equivalent only, not a switchable device', dQ(i), vm_s(i)));
        end
    case 'QD'
        for i = find(apply).'
            old = mpc.bus(i, QD);
            mpc.bus(i, QD) = old - dQ(i);
            rev = add_rev(rev, 'Q_EQUIVALENT', 'bus', i, raw.bus_line(i), num2str(ids(i)), 'QD', old, ...
                mpc.bus(i, QD), 'CONST_Q_FROM_Q_RESIDUAL', sprintf('dQ=%.4f Mvar; equivalent only', dQ(i)));
        end
    case 'NONE'
        apply(:) = false;
    otherwise
        error('dali:case', 'Unknown cfg.qeq.mode');
end
[Scalc2, ~] = nodal_injection(mpc, Vs, f, t, base);
Sd2 = mpc.bus(:, PD) + 1j * mpc.bus(:, QD);
res_after = (Sg - Sd2) - Scalc2;
fprintf('Q equivalents (%s): %d PQ buses | capacitive %d (%.2f Mvar) | inductive %d (%.2f Mvar)\n', ...
    cfg.qeq.mode, sum(apply), sum(apply & dQ > 0), sum(dQ(apply & dQ > 0)), ...
    sum(apply & dQ < 0), sum(dQ(apply & dQ < 0)));
fprintf('PQ |Q residual| max: before %.3f -> after %.3f Mvar; PQ |P residual| max %.3f MW (sum %.3f MW, not equivalenced)\n', ...
    max(abs(imag(res_before(pq)))), max(abs(imag(res_after(pq)))), max(abs(real(res_after(pq)))), sum(real(res_after(pq))));
for b = cfg.boundary.buses(:).'
    i = map(b);
    fprintf('  boundary bus %d (type %d): residual P %.3f MW, Q %.3f Mvar (absorbed by PV/slack)\n', ...
        b, mpc.bus(i, BUS_TYPE), real(res_after(i)), imag(res_after(i)));
end

%% ---------------- meta (evaluation side, never fed to solvers) ----------------
meta = struct();
meta.base = base; meta.ids = ids; meta.map = map; meta.f = f; meta.t = t;
meta.nb = nb; meta.nl = nl; meta.ng = ng;
meta.base_kv = Bm(:, bc.BASE_KV);
meta.eval_vmin = Bm(:, bc.VMIN);
meta.eval_vmax = Bm(:, bc.VMAX);
meta.snap_vm = vm_s;
meta.snap_va_deg = va_rad * 180 / pi;
meta.is_boundary = ismember(ids, cfg.boundary.buses);
meta.ref_bus = ids(mpc.bus(:, BUS_TYPE) == REF);
meta.is_line = Rm(:, rc.TAP) == 0;
meta.rateA_src = Rm(:, rc.RATE_A);
meta.rate_MVA_if_A = sqrt(3) * meta.base_kv(f) .* meta.rateA_src / 1000;
meta.rate_MVA_literal = meta.rateA_src;
if strcmpi(cfg.rate.unit, 'A')
    meta.rate_MVA = meta.rate_MVA_if_A;
else
    meta.rate_MVA = meta.rate_MVA_literal;
end
meta.exp_Sf = Sfx; meta.exp_St = Stx;
% ratings used by OPF/COPT: relax only where the snapshot itself already exceeds the rating
if strcmpi(cfg.rate.unit, 'A')
    load_pu = max(abs(Sfx) ./ vm_s(f), abs(Stx) ./ vm_s(t)) / base;   % current magnitude, p.u.
else
    load_pu = max(abs(Sfx), abs(Stx)) / base;                         % apparent power, p.u.
end
rate_pu = meta.rate_MVA / base;
meta.snap_loading_ratio = zeros(nl, 1);
meta.snap_loading_ratio(rate_pu > 0) = load_pu(rate_pu > 0) ./ rate_pu(rate_pu > 0);
meta.rate_MVA_opf = meta.rate_MVA;
over = on & rate_pu > 0 & load_pu > rate_pu;
if cfg.rate.relax_preexisting
    meta.rate_MVA_opf(over) = cfg.rate.relax_margin * load_pu(over) * base;
    for k = find(over).'
        rev = add_rev(rev, 'RATING_RELAX_OPF_ONLY', 'branch', k, raw.branch_line(k), ...
            sprintf('%d-%d', ids(f(k)), ids(t(k))), 'RATE_A_opf_MVA', meta.rate_MVA(k), meta.rate_MVA_opf(k), ...
            'RELAX_PREEXISTING_OVERLOAD', sprintf(['snapshot loading %.1f%% of rating (unit %s); relaxed for ', ...
            'optimisation feasibility only, still reported as overload in evaluation'], 100 * meta.snap_loading_ratio(k), cfg.rate.unit));
    end
end
fprintf('Branches already above rating in the snapshot (unit %s): %s\n', cfg.rate.unit, dali_rows2str(find(over)));
for k = find(over).'
    fprintf('  row %d (%d-%d, %g/%g kV, RATE_A=%.3f): %.1f%% -> OPF/COPT limit %.2f MVA\n', k, ids(f(k)), ids(t(k)), ...
        Bm(f(k), bc.BASE_KV), Bm(t(k), bc.BASE_KV), meta.rateA_src(k), 100 * meta.snap_loading_ratio(k), meta.rate_MVA_opf(k));
end
meta.exported_loss_MW = sum(real(Sfx(on)) + real(Stx(on)));
nbd = ~meta.is_boundary;
meta.posPD_nonboundary = sum(max(Bm(nbd, bc.PD), 0));
meta.posPD_le110kV = sum(max(Bm(nbd & meta.base_kv <= 110, bc.PD), 0));
meta.cand_rows = topo.cand_rows(:);
meta.forbidden_rows = find(topo.forbidden);
meta.src_branch_line = raw.branch_line(:);
meta.snap_gen_PG = mpc.gen(:, PG);
meta.snap_gen_QG = mpc.gen(:, QG);
meta.sha256 = raw.sha256;

fprintf('Exported branch active loss (file PF+PT): %.3f MW\n', meta.exported_loss_MW);
fprintf('Revision records: %d\n', numel(rev));
end

%% ======================================================================
function [sf, st] = branch_flows(V, f, t, r, x, btot, tpc, shift_deg, base)
tau = tpc .* exp(1j * shift_deg * pi / 180);
ys = 1 ./ (r + 1j * x);
ytt = ys + 1j * btot / 2;
yff = ytt ./ (tau .* conj(tau));
yft = -ys ./ conj(tau);
ytf = -ys ./ tau;
Vf = V(f); Vt = V(t);
sf = base * Vf .* conj(yff .* Vf + yft .* Vt);
st = base * Vt .* conj(ytf .* Vf + ytt .* Vt);
end

function [Scalc, Sbr] = nodal_injection(mpc, V, f, t, base)
% network-required injection at each bus (MVA): sum of branch end powers + bus shunt
define_constants;
nb = size(mpc.bus, 1);
on = mpc.branch(:, BR_STATUS) == 1;
tp = mpc.branch(:, TAP); tp(tp == 0) = 1;
[sf, st] = branch_flows(V, f, t, mpc.branch(:, BR_R), mpc.branch(:, BR_X), ...
    mpc.branch(:, BR_B), tp, mpc.branch(:, SHIFT), base);
sf(~on) = 0; st(~on) = 0;
Sbr = [sf st];
Scalc = accumarray(f, sf, [nb 1]) + accumarray(t, st, [nb 1]) + ...
    (mpc.bus(:, GS) - 1j * mpc.bus(:, BS)) .* abs(V).^2;
end

function rev = new_rev()
rev = struct('id', {}, 'category', {}, 'object', {}, 'row', {}, 'source_line', {}, ...
    'element', {}, 'field', {}, 'old_value', {}, 'new_value', {}, 'rule', {}, ...
    'evidence', {}, 'confirmed_by_data_provider', {});
end

function rev = add_rev(rev, cat, obj, row, srcline, element, field, oldv, newv, rule, evidence)
rev(end+1) = struct('id', numel(rev) + 1, 'category', cat, 'object', obj, 'row', row, ...
    'source_line', srcline, 'element', element, 'field', field, 'old_value', oldv, ...
    'new_value', newv, 'rule', rule, 'evidence', evidence, 'confirmed_by_data_provider', 'NO');
end
