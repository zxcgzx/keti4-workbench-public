function R = dali_indicator_row(label, E, N, C)
%DALI_INDICATOR_ROW  任务书指标 4.2 的单方案指标行（安全性 / 稳定性 / 经济性）。
%   E: dali_eval_ac 结果；N: dali_n1_check 汇总（可空）；C: dali_cpf_margin 结果（可空）。
R = struct();
R.scenario = label;
R.converged = E.converged;
% ---- 安全性
R.n1_contingencies = getv(N, 'n_contingencies');
R.n1_pass_incremental_pct = getv(N, 'pass_rate_incremental_pct');
R.n1_pass_emergency_pct = getv(N, 'pass_rate_emergency_pct');
R.n1_pass_strict_pct = getv(N, 'pass_rate_strict_pct');
R.line_load_mean_pct = E.lineP_mean_pct;
R.line_load_max_pct = E.lineP_max_pct;
R.I_LR = E.I_LR;
% ---- 稳定性
R.voltage_qualified_110_35kV_pct = E.tb_vq_rate_110_35kV_pct;
R.I_VD = E.I_VD_literal;
R.I_VD_abs = E.I_VD_abs;
R.dU_mean = E.dU_mean;
R.dU_std = E.dU_std;
R.cpf_margin_pct = getv(C, 'margin_pct');
R.cpf_margin_MW = getv(C, 'margin_MW');
R.cpf_nose_reached = getv(C, 'nose_reached');
% ---- 经济性
R.loss_MW = E.loss_MW;
R.loss_rate_le110kV_load_pct = E.loss_rate_posPD_le110kV_pct;
R.renewable_accommodation = 'NOT_COMPUTABLE';
R.generation_cost = 'NOT_COMPUTABLE';
R.note = 'single snapshot; data revisions unconfirmed; voltage rate = level proxy; loss-rate denominator unconfirmed';
end

function v = getv(s, f)
v = NaN;
if ~isempty(s) && isstruct(s) && isfield(s, f) && isnumeric(s.(f)) && ~isempty(s.(f))
    v = s.(f);
end
end
