function [res, info] = dali_run_acopf(mpo, opfset, cfg, env, label)
%DALI_RUN_ACOPF  MATPOWER AC-OPF（软电压限值），失败时依次尝试 IPOPT、MIPS step_control。

fprintf('\n--- AC-OPF [%s] (vpen=%g $/pu, flow_lim=%s) ---\n', label, opfset.vpen, opfset.flow_lim);
mpopt = mpoption('opf.ac.solver', cfg.opf.solver, 'verbose', cfg.opf.verbose, 'out.all', 0, ...
    'opf.flow_lim', opfset.flow_lim, 'mips.max_it', cfg.opf.max_it);
mpopt = try_opt(mpopt, 'opf.softlims.default', 0);
mpopt = try_opt(mpopt, 'opf.start', 2);

attempts = {};
t0 = tic;
res = safe_runopf(mpo, mpopt);
attempts{end+1} = sprintf('%s:%d', cfg.opf.solver, res.success);
if ~res.success && cfg.opf.try_ipopt_on_fail && env.has_ipopt
    r2 = safe_runopf(mpo, mpoption(mpopt, 'opf.ac.solver', 'IPOPT'));
    attempts{end+1} = sprintf('IPOPT:%d', r2.success);
    if r2.success, res = r2; end
end
if ~res.success
    r3 = safe_runopf(mpo, mpoption(mpopt, 'opf.ac.solver', 'MIPS', 'mips.step_control', 1));
    attempts{end+1} = sprintf('MIPS-sc:%d', r3.success);
    if r3.success, res = r3; end
end
info = struct();
info.label = label;
info.time_s = toc(t0);
info.success = res.success;
info.attempts = strjoin(attempts, ' ');
info.f = NaN;
if isfield(res, 'f'), info.f = res.f; end
info.iterations = NaN;
info.message = '';
try
    info.iterations = res.raw.output.iterations;
catch
end
try
    info.message = res.raw.output.message;
catch
end
fprintf('AC-OPF [%s]: success=%d f=%.4f time=%.2fs iters=%g attempts={%s}\n', ...
    label, info.success, info.f, info.time_s, info.iterations, info.attempts);
end

function mpopt = try_opt(mpopt, name, val)
try
    mpopt = mpoption(mpopt, name, val);
catch err
    fprintf('  (mpoption %s not available: %s)\n', name, err.message);
end
end

function res = safe_runopf(mpo, mpopt)
try
    res = runopf(mpo, mpopt);
catch err
    fprintf(2, '  runopf raised: %s\n', err.message);
    res = struct('success', 0, 'f', NaN);
end
end
