function [res, info] = dali_run_acpf(mpc, meta, label, flat_start, compare_snapshot)
%DALI_RUN_ACPF  MATPOWER 牛顿法潮流；可选平启动；可选与导出断面逐项对比（复现度）。

define_constants;
if nargin < 4, flat_start = false; end
if nargin < 5, compare_snapshot = false; end
m = mpc;
if flat_start
    pq = m.bus(:, BUS_TYPE) == PQ;
    m.bus(pq, VM) = 1;
    m.bus(:, VA) = m.bus(m.bus(:, BUS_TYPE) == REF, VA);
end
mpopt = mpoption('pf.alg', 'NR', 'pf.tol', 1e-8, 'pf.nr.max_it', 50, 'verbose', 0, ...
    'out.all', 0, 'pf.enforce_q_lims', 0);
t0 = tic;
try
    res = runpf(m, mpopt);
catch err
    fprintf(2, 'runpf raised: %s\n', err.message);
    res = struct('success', 0);
end
info = struct();
info.label = label;
info.flat_start = flat_start;
info.success = res.success;
info.time_s = toc(t0);
info.iterations = NaN;
if isfield(res, 'iterations'), info.iterations = res.iterations; end
fprintf('ACPF [%s]%s: success=%d iters=%g time=%.2fs\n', label, ...
    ternary(flat_start, ' (flat start)', ''), info.success, info.iterations, info.time_s);

if compare_snapshot && res.success
    dvm = res.bus(:, VM) - meta.snap_vm;
    dva = res.bus(:, VA) - meta.snap_va_deg;
    Sf = res.branch(:, PF) + 1j * res.branch(:, QF);
    St = res.branch(:, PT) + 1j * res.branch(:, QT);
    serr = max(abs(Sf - meta.exp_Sf), abs(St - meta.exp_St));
    [~, iv] = max(abs(dvm));
    info.max_abs_dVM = max(abs(dvm));
    info.bus_max_dVM = meta.ids(iv);
    info.n_dVM_gt_0p005 = sum(abs(dvm) > 0.005);
    info.max_abs_dVA_deg = max(abs(dva));
    info.n_branch_Serr_gt_1MVA = sum(serr > 1);
    info.max_branch_Serr_MVA = max(serr);
    fprintf(['  vs snapshot: max|dVM|=%.5f pu (bus %d), #|dVM|>0.005: %d, max|dVA|=%.4f deg, ', ...
        '#branch S_err>1MVA: %d (max %.3f)\n'], info.max_abs_dVM, info.bus_max_dVM, ...
        info.n_dVM_gt_0p005, info.max_abs_dVA_deg, info.n_branch_Serr_gt_1MVA, info.max_branch_Serr_MVA);
end
end

function s = ternary(c, a, b)
if c, s = a; else, s = b; end
end
