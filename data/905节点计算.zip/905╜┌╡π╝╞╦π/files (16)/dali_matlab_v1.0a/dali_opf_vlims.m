function [vmin, vmax] = dali_opf_vlims(meta, cfg)
%DALI_OPF_VLIMS  优化中使用的电压上下限（与评价口径分开保存）。
vmin = meta.eval_vmin;
vmax = meta.eval_vmax;
if strcmpi(cfg.vlim.opf_source, 'taskbook_proxy')
    sel = ismember(meta.base_kv, cfg.taskbook.v_kv);
    vmin(sel) = cfg.taskbook.v_band(1);
    vmax(sel) = cfg.taskbook.v_band(2);
end
end
