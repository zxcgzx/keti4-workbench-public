function topo = dali_topology_audit(raw, cfg)
%DALI_TOPOLOGY_AUDIT  多重图拓扑统计（并联支路保留独立ID）与OTS候选初筛。
%   桥判定：逐条删除一个支路ID后检查两端可达性；简单图口径仅作对照。
%   候选 = 在运 & 多重图非桥 & TAP==0 & 非禁止端点对（175–176）。
%   注意：TAP==0 只是格式初筛，不代表现场可操作；组合开断的连通性另行检查。

fprintf('\n===== STEP 1a: topology audit (multigraph) =====\n');
bc = raw.bus_col; rc = raw.branch_col;
ids = raw.bus(:, bc.BUS_I);
nb = numel(ids);
map = zeros(max(ids), 1);
map(ids) = 1:nb;
F = raw.branch(:, rc.F_BUS);
T = raw.branch(:, rc.T_BUS);
f = map(F);
t = map(T);
nl = size(raw.branch, 1);
on = raw.branch(:, rc.BR_STATUS) == 1;
tap = raw.branch(:, rc.TAP);
E = find(on);

[adjN, adjE] = build_adj(nb, f, t, E);

% ---- multigraph bridges (remove exactly one branch ID)
t0 = tic;
isbr = false(nl, 1);
excl = false(nl, 1);
for k = E.'
    excl(k) = true;
    isbr(k) = ~reach(adjN, adjE, f(k), t(k), excl, nb);
    excl(k) = false;
end

% ---- parallel groups / simple graph
lo = min(f, t); hi = max(f, t);
key = (lo - 1) * nb + hi;
[ukey, ~, gid] = unique(key(E));
gsize = accumarray(gid, 1);
grp = zeros(nl, 1);
grp(E) = gid;
nsimple = numel(ukey);
simple_bridge = false(nsimple, 1);
for g = 1:nsimple
    members = E(gid == g);
    excl(members) = true;
    k = members(1);
    simple_bridge(g) = ~reach(adjN, adjE, lo(k), hi(k), excl, nb);
    excl(members) = false;
end
fprintf('Bridge tests finished in %.2f s\n', toc(t0));

% ---- forbidden endpoint pairs
forb = false(nl, 1);
fp = cfg.boundary.forbidden_pairs;
for i = 1:size(fp, 1)
    forb = forb | (min(F, T) == min(fp(i, :)) & max(F, T) == max(fp(i, :)));
end

prelim = on & ~isbr & tap == 0;
cand_default = prelim & ~forb;

% ---- counts
cnt = struct();
cnt.branch_on          = numel(E);
cnt.simple_edges       = nsimple;
cnt.simple_bridges     = sum(simple_bridge);
cnt.multigraph_bridges = sum(isbr);
cnt.nonbridge          = sum(on & ~isbr);
cnt.parallel_groups    = sum(gsize > 1);
cnt.nonbridge_tap0     = sum(prelim);
cnt.nonbridge_tapnz    = sum(on & ~isbr & tap ~= 0);
cnt.cand_after_excl    = sum(cand_default);
cnt.components         = dali_ncomp(nb, f, t, on);

fn = fieldnames(cfg.expect);
chk = struct('item', {}, 'expected', {}, 'computed', {}, 'result', {});
allpass = true;
for i = 1:numel(fn)
    ev = cfg.expect.(fn{i});
    cv = cnt.(fn{i});
    ok = (ev == cv);
    allpass = allpass && ok;
    chk(end+1) = struct('item', fn{i}, 'expected', ev, 'computed', cv, ...
        'result', ternary(ok, 'PASS', 'FAIL')); %#ok<AGROW>
    fprintf('  %-20s expected %5d  computed %5d  %s\n', fn{i}, ev, cv, ternary(ok, 'PASS', 'FAIL'));
end
fprintf('  connected components: %d\n', cnt.components);
if ~allpass
    fprintf(2, 'Topology counts differ from the revised report. Check before using results.\n');
end

% ---- N-1 connectivity screen: opening k must not create a new bridge
t1 = tic;
n1ok = false(nl, 1);
newbr = repmat({''}, nl, 1);
nonbr = find(on & ~isbr);
for k = find(cand_default).'
    excl(k) = true;
    created = [];
    for e = nonbr.'
        if e == k, continue; end
        excl(e) = true;
        if ~reach(adjN, adjE, f(e), t(e), excl, nb)
            created(end+1) = e; %#ok<AGROW>
        end
        excl(e) = false;
    end
    excl(k) = false;
    n1ok(k) = isempty(created);
    newbr{k} = dali_rows2str(created);
end
fprintf('N-1 connectivity screen (%.2f s): %d of %d candidates create no new bridge: %s\n', toc(t1), ...
    sum(n1ok & cand_default), sum(cand_default), dali_rows2str(find(n1ok & cand_default)));

% ---- candidate set actually used
cand_rows = find(cand_default);
if ~isempty(cfg.ots.candidate_rows)
    user = cfg.ots.candidate_rows(:);
    bad = user(~cand_default(user));
    if ~isempty(bad)
        error('dali:topo', ['cfg.ots.candidate_rows contains rows that are bridges, TAP~=0, ', ...
            'out of service or forbidden: %s'], mat2str(bad.'));
    end
    cand_rows = sort(user);
end
if cfg.ots.require_n1_connectivity
    dropped = cand_rows(~n1ok(cand_rows));
    cand_rows = cand_rows(n1ok(cand_rows));
    fprintf('Candidates dropped by N-1 connectivity screen: %s\n', dali_rows2str(dropped));
end
fprintf('Forbidden branch rows (endpoint rule): %s\n', dali_rows2str(find(forb & on)));
fprintf('OTS candidate rows used (%d): %s\n', numel(cand_rows), dali_rows2str(cand_rows));

% ---- group member strings for CSV
members_str = repmat({''}, nl, 1);
for k = E.'
    members_str{k} = strjoin(arrayfun(@num2str, E(gid == gid(E == k)).', 'UniformOutput', false), ';');
end

topo = struct();
topo.map = map; topo.ids = ids; topo.f = f; topo.t = t;
topo.isbridge = isbr; topo.prelim = prelim; topo.forbidden = forb;
topo.cand_default = cand_default; topo.cand_rows = cand_rows;
topo.group = grp; topo.group_members = members_str;
topo.counts = cnt; topo.checks = chk; topo.allpass = allpass;
topo.n1ok = n1ok; topo.newbr = newbr;
end

%% ------------------------------------------------------------------------
function [adjN, adjE] = build_adj(nb, f, t, E)
deg = accumarray([f(E); t(E)], 1, [nb 1]);
adjN = cell(nb, 1);
adjE = cell(nb, 1);
for i = 1:nb
    adjN{i} = zeros(1, deg(i));
    adjE{i} = zeros(1, deg(i));
end
pos = zeros(nb, 1);
for k = E.'
    a = f(k); b = t(k);
    pos(a) = pos(a) + 1; adjN{a}(pos(a)) = b; adjE{a}(pos(a)) = k;
    pos(b) = pos(b) + 1; adjN{b}(pos(b)) = a; adjE{b}(pos(b)) = k;
end
end

function ok = reach(adjN, adjE, s, target, excl, nb)
if s == target
    ok = true;
    return;
end
seen = false(nb, 1);
seen(s) = true;
stack = zeros(nb, 1);
top = 1;
stack(1) = s;
while top > 0
    u = stack(top);
    top = top - 1;
    nu = adjN{u};
    ne = adjE{u};
    for j = 1:numel(nu)
        v = nu(j);
        if ~seen(v) && ~excl(ne(j))
            if v == target
                ok = true;
                return;
            end
            seen(v) = true;
            top = top + 1;
            stack(top) = v;
        end
    end
end
ok = false;
end

function s = ternary(c, a, b)
if c, s = a; else, s = b; end
end
