function env = dali_p0_step0_env(cfg)
%DALI_P0_STEP0_ENV  环境检查：MATLAB、MATPOWER(>=7, softlims)、IPOPT(可选)、COPT。
%   COPT 冒烟测试同时探测 MATLAB 接口的约束写法(lhs/rhs 或 sense/rhs)
%   和二次目标约定(x'Qx 或 0.5x'Qx)，后续建模据此自动适配。

fprintf('\n===== STEP 0: environment check =====\n');
env = struct();
env.matlab   = version;
env.computer = computer;
env.time     = datestr(now, 31);
fprintf('MATLAB %s | %s | %s\n', env.matlab, env.computer, env.time);

%% MATPOWER
if exist('mpver', 'file') ~= 2 && ~isempty(cfg.matpower_path)
    addpath(genpath(cfg.matpower_path));
end
env.matpower_ok = (exist('mpver', 'file') == 2) && (exist('runopf', 'file') == 2);
env.matpower_version = 'NOT_FOUND';
env.has_softlims = false;
env.has_ipopt = false;
if env.matpower_ok
    v = mpver;
    env.matpower_version = v;
    major = str2double(strtok(v, '.'));
    env.has_softlims = exist('toggle_softlims', 'file') == 2;
    fprintf('MATPOWER %s | toggle_softlims: %d\n', v, env.has_softlims);
    if ~(major >= 7) || ~env.has_softlims
        fprintf(2, 'MATPOWER >= 7.0 with toggle_softlims is required.\n');
        env.matpower_ok = false;
    end
    try
        env.has_ipopt = logical(have_feature('ipopt'));
    catch
        try
            env.has_ipopt = logical(have_fcn('ipopt'));
        catch
            env.has_ipopt = false;
        end
    end
    fprintf('IPOPT visible to MATPOWER: %d (optional)\n', env.has_ipopt);
else
    fprintf(2, ['MATPOWER not found. In MATLAB: cd to the MATPOWER root and run ', ...
        'install_matpower(1,1,1), or set cfg.matpower_path.\n']);
end

%% COPT
if exist('copt_solve', 'file') == 0 && ~isempty(cfg.copt_matlab_path)
    addpath(cfg.copt_matlab_path);
end
env.copt_found = exist('copt_solve', 'file') > 0;
env.copt = struct('ok', false, 'rowfmt', '', 'qmult', NaN, 'fields', '', 'smoke_status', '');
if env.copt_found
    fprintf('copt_solve found at: %s\n', which('copt_solve'));
    env.copt = copt_smoke(env.copt);
else
    fprintf(2, 'copt_solve NOT found. Set cfg.copt_matlab_path to the COPT MATLAB interface folder.\n');
end
if env.copt.ok
    fprintf('COPT smoke test PASSED | row format: %s | Q multiplier: %g\n', env.copt.rowfmt, env.copt.qmult);
else
    fprintf(2, 'COPT smoke test FAILED: OTS steps will be skipped (ACPF / AC-OPF still run).\n');
end
end

%% ------------------------------------------------------------------------
function c = copt_smoke(c)
% min x^2 - 2x + 0.1y  s.t.  x - 3y <= 0,  x in [-10,10],  y binary
%   若目标为 x'Qx + c'x      : 最优 y=1, x=1, obj=-0.9
%   若目标为 0.5x'Qx + c'x   : 最优 y=1, x=2, obj=-1.9
%   若约束被忽略/理解错误   : y=0（据此判定写法是否正确）
fmts = {'lhsrhs', 'sense'};
for i = 1:numel(fmts)
    prob = struct();
    prob.objsen = 'min';
    prob.objcon = 0;
    prob.A      = sparse([1 -3]);
    prob.obj    = [-2; 0.1];
    prob.lb     = [-10; 0];
    prob.ub     = [10; 1];
    prob.vtype  = 'CB';
    prob.Q      = sparse([1 0; 0 0]);
    if strcmp(fmts{i}, 'lhsrhs')
        prob.lhs = -1e30;
        prob.rhs = 0;
    else
        prob.sense = 'L';
        prob.rhs   = 0;
    end
    par = struct('Logging', 1, 'TimeLimit', 10);
    try
        r = copt_solve(prob, par);
    catch err
        fprintf('COPT smoke test with %s format raised: %s\n', fmts{i}, err.message);
        continue;
    end
    flds = strjoin(fieldnames(r).', ',');
    fprintf('COPT result fields (%s): %s\n', fmts{i}, flds);
    st = '';
    if isfield(r, 'status'), st = char(r.status); end
    if ~isfield(r, 'x') || numel(r.x) ~= 2
        fprintf('  status=%s, no 2-element x returned\n', st);
        continue;
    end
    xx = r.x(1); yy = r.x(2);
    ov = NaN;
    if isfield(r, 'objval'), ov = r.objval; end
    fprintf('  status=%s x=%.6f y=%.6f objval=%.6f\n', st, xx, yy, ov);
    if abs(yy - 1) > 1e-6 || xx > 3*yy + 1e-6
        fprintf('  -> constraint not interpreted as x-3y<=0 with this format\n');
        continue;
    end
    if abs(xx - 1) < 1e-4
        qmult = 1;     % COPT objective = x'Qx + c'x
    elseif abs(xx - 2) < 1e-4
        qmult = 2;     % COPT objective = 0.5 x'Qx + c'x  -> pass 2*Q
    else
        fprintf('  -> unexpected x, cannot infer Q convention\n');
        continue;
    end
    c.ok = true;
    c.rowfmt = fmts{i};
    c.qmult = qmult;
    c.fields = flds;
    c.smoke_status = st;
    return;
end
end
