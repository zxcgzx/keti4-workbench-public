function m = dali_pf_case_from_state(mpc, state, meta, open_rows)
%DALI_PF_CASE_FROM_STATE  用已求得的控制量（PV电压、机组P/Q）构造潮流算例，并可断开支路。
%   用于“只改拓扑、不重新优化控制量”的纯拓扑效应校核（S2a）。
define_constants;
if nargin < 4, open_rows = []; end
m = mpc;
m.bus(:, VM) = state.bus(:, VM);
m.bus(:, VA) = state.bus(:, VA);
m.gen(:, PG) = state.gen(:, PG);
m.gen(:, QG) = state.gen(:, QG);
gon = m.gen(:, GEN_STATUS) > 0;
gbi = meta.map(m.gen(:, GEN_BUS));
m.gen(gon, VG) = state.bus(gbi(gon), VM);
if ~isempty(open_rows)
    m.branch(open_rows, BR_STATUS) = 0;
end
end
