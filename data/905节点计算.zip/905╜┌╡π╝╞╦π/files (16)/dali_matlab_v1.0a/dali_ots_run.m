function ots = dali_ots_run(res0, opfset, meta, cfg, env, vpen)
%DALI_OTS_RUN  COPT 代理OTS主流程：
%   1) MIQP 求开断方案 z*（kmax>1 时若解列则加 no-good 割重解）；
%   2) z 全为1 的连续QP（仅控制量在代理中再优化，作“无开断”对照）；
%   3) z = z* 的连续QP（消除 Big-M/整数容差残差，得到干净的代理目标值）。
%   代理收益 = J_proxy(z*) - J_proxy(全在运)，二者同一代理模型、同一权重。

define_constants;
fprintf('\n--- COPT proxy OTS (vpen=%g, kmax=%d, %d candidates) ---\n', vpen, cfg.ots.kmax, numel(meta.cand_rows));
nb = meta.nb;
nc = numel(meta.cand_rows);
nogood = {};
mi = [];
n_cuts = 0;
for it = 1:(cfg.ots.max_nogood + 1)
    mi = dali_ots_copt(res0, opfset, meta, cfg, env, vpen, 'miqp', [], nogood, true);
    retry_note = '';
    presolve_off = isfield(cfg.copt, 'extra_params') && isfield(cfg.copt.extra_params, 'Presolve') && ...
        cfg.copt.extra_params.Presolve == 0;
    if mi.ok && mi.max_row_viol > cfg.copt.viol_tol && cfg.copt.retry_miqp_without_presolve && ~presolve_off
        fprintf('  MIQP solution violates unscaled rows by %.3g > %.1g: re-solving MIQP with Presolve=0\n', ...
            mi.max_row_viol, cfg.copt.viol_tol);
        cfg2 = cfg;
        cfg2.copt.extra_params.Presolve = 0;
        mi2 = dali_ots_copt(res0, opfset, meta, cfg2, env, vpen, 'miqp', [], nogood, true);
        retry_note = sprintf('first: viol %.3g (%s), open %s | Presolve=0: ok %d, viol %.3g, open %s', ...
            mi.max_row_viol, mi.max_row_viol_block, dali_rows2str(mi.open_rows), mi2.ok, ...
            mi2.max_row_viol, dali_rows2str(mi2.open_rows));
        if mi2.ok && mi2.max_row_viol < mi.max_row_viol
            mi = mi2;
            retry_note = [retry_note ' -> using Presolve=0 solution']; %#ok<AGROW>
        else
            retry_note = [retry_note ' -> keeping first solution']; %#ok<AGROW>
        end
        fprintf('  %s\n', retry_note);
    end
    if ~mi.ok, break; end
    on = res0.branch(:, BR_STATUS) == 1;
    on(mi.open_rows) = false;
    if dali_ncomp(nb, meta.f, meta.t, on) == 1, break; end
    fprintf('  combination %s splits the network -> adding no-good cut\n', dali_rows2str(mi.open_rows));
    nogood{end+1} = find(~mi.zr); %#ok<AGROW>
    n_cuts = n_cuts + 1;
end

allon = dali_ots_copt(res0, opfset, meta, cfg, env, vpen, 'fixed', ones(nc, 1), {}, false);
fprintf('  proxy, all candidates in service (continuous re-opt): status=%s J=%.4f loss=%.4f MW viol=%.5f pu\n', ...
    allon.status, allon.J_proxy, allon.loss_proxy_MW, allon.viol_proxy_pu);
zs = struct('ok', false, 'J_proxy', NaN, 'loss_proxy_MW', NaN, 'viol_proxy_pu', NaN, 'status', '');
if mi.ok
    zs = dali_ots_copt(res0, opfset, meta, cfg, env, vpen, 'fixed', double(mi.zr), {}, false);
    fprintf('  proxy, z* fixed (clean re-solve): status=%s J=%.4f loss=%.4f MW viol=%.5f pu\n', ...
        zs.status, zs.J_proxy, zs.loss_proxy_MW, zs.viol_proxy_pu);
end

ots = struct();
ots.vpen = vpen;
ots.ok = mi.ok;
ots.miqp_status = mi.status;
ots.miqp_time_s = mi.time_s;
ots.miqp_objval = mi.objval;
ots.miqp_bestgap = mi.bestgap;
ots.miqp_nodecnt = mi.nodecnt;
ots.nvars = mi.nvars; ots.nrows = mi.nrows; ots.nbin = mi.nbin;
ots.n_nogood_cuts = n_cuts;
ots.open_rows = mi.open_rows(:).';
ots.open_rows_str = dali_rows2str(ots.open_rows);
if ~mi.ok
    ots.open_desc = 'COPT_NO_SOLUTION';
elseif isempty(ots.open_rows)
    ots.open_desc = 'NONE (zero opening within proxy and candidate set)';
else
    d = cell(1, numel(ots.open_rows));
    for i = 1:numel(ots.open_rows)
        k = ots.open_rows(i);
        d{i} = sprintf('row%d(%d-%d)', k, meta.ids(meta.f(k)), meta.ids(meta.t(k)));
    end
    ots.open_desc = strjoin(d, ';');
end
ots.base_J_proxy = mi.base_J_proxy;
ots.base_loss_proxy_MW = mi.base_loss_proxy_MW;
ots.base_viol_pu = mi.base_viol_pu;
ots.allon_J_proxy = allon.J_proxy;
ots.allon_loss_proxy_MW = allon.loss_proxy_MW;
ots.allon_viol_pu = allon.viol_proxy_pu;
ots.zstar_J_proxy = zs.J_proxy;
ots.zstar_loss_proxy_MW = zs.loss_proxy_MW;
ots.zstar_viol_pu = zs.viol_proxy_pu;
ots.proxy_gain_J = zs.J_proxy - allon.J_proxy;
ots.Mdev_max = mi.Mdev_max;
ots.chk_ybus = mi.chk.ybus_maxdiff;
ots.chk_base_mis_MW = mi.chk.base_mismatch_MW;
ots.chk_deriv = max(mi.chk.deriv_rel_err_theta, mi.chk.deriv_rel_err_vm);
ots.angdiff_binding = dali_rows2str(mi.angdiff_binding);
ots.miqp_max_row_viol = mi.max_row_viol;
ots.miqp_retry = retry_note;
ots.miqp_viol_detail = mi.viol_detail;
ots.miqp_max_row_viol_block = mi.max_row_viol_block;
ots.zstar_max_row_viol = NaN;
if isfield(zs, 'max_row_viol'), ots.zstar_max_row_viol = zs.max_row_viol; end
fprintf('  => COPT selected: %s | proxy gain vs all-on: %.4f $ (negative = improvement in proxy)\n', ...
    ots.open_desc, ots.proxy_gain_J);
end
