function L = dali_branch_loading(res, meta, cfg)
%DALI_BRANCH_LOADING  支路负载率（比值，非百分数），口径与 dali_eval_ac 一致：
%   RATE_A 按 A 解释时：线路取两端电流较大者，变压器取首端（高压侧）电流；按 MVA 解释时取两端视在功率较大者。
%   停运或无额定值的支路返回 NaN。
define_constants;
br = res.branch;
on = br(:, BR_STATUS) == 1;
vm = res.bus(:, VM);
Sf = abs(br(:, PF) + 1j * br(:, QF));
St = abs(br(:, PT) + 1j * br(:, QT));
ra = meta.rateA_src;
L = nan(size(br, 1), 1);
ok = on & ra > 0;
if strcmpi(cfg.rate.unit, 'A')
    If = Sf * 1000 ./ (sqrt(3) * vm(meta.f) .* meta.base_kv(meta.f));
    It = St * 1000 ./ (sqrt(3) * vm(meta.t) .* meta.base_kv(meta.t));
    I = If;
    I(meta.is_line) = max(If(meta.is_line), It(meta.is_line));
    L(ok) = I(ok) ./ ra(ok);
else
    L(ok) = max(Sf(ok), St(ok)) ./ ra(ok);
end
end
