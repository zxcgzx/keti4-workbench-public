function raw = dali_read_pasexp(fname)
%DALI_READ_PASEXP  只读解析大理导出TXT（Dict Info + Bus/Gen/Branch 三个矩阵块）。
%   源文件不被修改。返回各矩阵数值、列名、列号结构体、源文件行号(1-based)与SHA-256。

fprintf('\n===== STEP 1: read TXT (read-only) =====\n');
if exist(fname, 'file') ~= 2
    error('dali:read', 'Input TXT not found: %s', fname);
end
raw = struct();
raw.file = fname;
raw.sha256 = dali_sha256(fname);
txt = fileread(fname);
if ~isempty(txt) && double(txt(1)) == 65279      % UTF-8 BOM
    txt = txt(2:end);
end
L = regexp(txt, '\r\n|\n|\r', 'split');
L = strtrim(L);

%% Dict Info
i1 = find(strcmp(L, '#####Begin Dict Info#####'));
i2 = find(strcmp(L, '#####End Dict Info#####'));
if numel(i1) ~= 1 || numel(i2) ~= 1
    error('dali:read', 'Dict Info markers missing or duplicated');
end
info = struct();
for i = i1+1:i2-1
    s = L{i};
    p = strfind(s, '=');
    if isempty(p), continue; end
    key = matlab.lang.makeValidName(strtrim(s(1:p(1)-1)));
    info.(key) = strtrim(s(p(1)+1:end));
end
raw.info = info;
if ~isfield(info, 'baseMVA')
    error('dali:read', 'baseMVA missing in Dict Info');
end
raw.baseMVA = str2double(info.baseMVA);
if ~(isfinite(raw.baseMVA) && raw.baseMVA > 0)
    error('dali:read', 'baseMVA must be finite and positive');
end

%% Matrix blocks
names = {'Bus', 'Gen', 'Branch'};
for n = 1:numel(names)
    [M, hdr, srcline] = read_block(L, names{n});
    key = lower(names{n});
    raw.(key) = M;
    raw.([key '_hdr']) = hdr;
    raw.([key '_line']) = srcline;
    c = struct();
    for j = 1:numel(hdr)
        c.(hdr{j}) = j;
    end
    raw.([key '_col']) = c;
end

%% Sanity checks
bc = raw.bus_col; gc = raw.gen_col; rc = raw.branch_col;
ids = raw.bus(:, bc.BUS_I);
if any(ids ~= round(ids)) || any(ids <= 0), error('dali:read', 'Invalid bus IDs'); end
if numel(unique(ids)) ~= numel(ids), error('dali:read', 'Duplicate bus IDs'); end
if any(~ismember(raw.gen(:, gc.GEN_BUS), ids)), error('dali:read', 'Unknown generator bus'); end
if any(~ismember(raw.branch(:, rc.F_BUS), ids)) || any(~ismember(raw.branch(:, rc.T_BUS), ids))
    error('dali:read', 'Unknown branch bus');
end
if any(~ismember(raw.branch(:, rc.BR_STATUS), [0 1])), error('dali:read', 'BR_STATUS must be 0/1'); end
if any(raw.branch(:, rc.TAP) < 0), error('dali:read', 'Negative TAP needs explicit semantics'); end

fprintf('File: %s\nSHA-256: %s\n', fname, raw.sha256);
fprintf('baseMVA=%g | Bus %d | Gen %d | Branch %d\n', raw.baseMVA, size(raw.bus,1), ...
    size(raw.gen,1), size(raw.branch,1));
end

%% ------------------------------------------------------------------------
function [M, hdr, srcline] = read_block(L, name)
b = find(strcmp(L, sprintf('#####Begin Matrix %s#####', name)));
e = find(strcmp(L, sprintf('#####End Matrix %s#####', name)));
if numel(b) ~= 1 || numel(e) ~= 1 || e <= b + 1
    error('dali:read', '%s: block markers missing/duplicated/empty', name);
end
hdr = strtrim(strsplit(L{b+1}, ','));
nc = numel(hdr);
idx = (b+2):(e-1);
idx = idx(~cellfun(@isempty, L(idx)));
M = zeros(numel(idx), nc);
for r = 1:numel(idx)
    v = sscanf(L{idx(r)}, '%f,');
    if numel(v) ~= nc
        error('dali:read', '%s line %d: expected %d fields, got %d', name, idx(r), nc, numel(v));
    end
    M(r, :) = v.';
end
if any(~isfinite(M(:)))
    error('dali:read', '%s: non-finite values', name);
end
srcline = idx(:);
end
