function h = dali_sha256(fname)
%DALI_SHA256  文件 SHA-256（依赖 MATLAB 自带 Java；不可用时返回 UNAVAILABLE）。
h = 'UNAVAILABLE';
fid = fopen(fname, 'r');
if fid < 0
    return;
end
bytes = fread(fid, Inf, '*uint8');
fclose(fid);
try
    md = java.security.MessageDigest.getInstance('SHA-256');
    if ~isempty(bytes)
        md.update(typecast(bytes, 'int8'));
    end
    d = typecast(md.digest(), 'uint8');
    h = lower(reshape(dec2hex(d, 2).', 1, []));
catch
    h = 'UNAVAILABLE';
end
end
