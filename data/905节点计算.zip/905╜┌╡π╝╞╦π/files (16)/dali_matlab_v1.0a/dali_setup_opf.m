function [mpo, opfset, permtab] = dali_setup_opf(mpc, init, meta, cfg, vpen, open_rows)
%DALI_SETUP_OPF  由 equivalent_v1 生成 AC-OPF 输入（试验权限 + 代价 + 软电压限值）。
%   mpc   : equivalent_v1（权限按断面值定义）
%   init  : 初值状态（ACPF或上一次OPF结果，外部编号，行序与mpc一致）
%   open_rows : 需要断开的支路源行号（固定拓扑时为空）
%   目标：c_loss * P_slack($) + vpen * sum(电压越限 p.u.)；本地机组有功固定，
%   故最小化平衡机有功 == 最小化网损（相差常数）。

define_constants;
if nargin < 6, open_rows = []; end
mpo = mpc;
nb = size(mpo.bus, 1);
ng = size(mpo.gen, 1);
map = meta.map;
isb = meta.is_boundary;

%% initial state
mpo.bus(:, VM) = init.bus(:, VM);
mpo.bus(:, VA) = init.bus(:, VA);
mpo.gen(:, PG) = init.gen(:, PG);
mpo.gen(:, QG) = init.gen(:, QG);
gon = mpo.gen(:, GEN_STATUS) > 0;
gbi = map(mpo.gen(:, GEN_BUS));
mpo.gen(gon, VG) = init.bus(gbi(gon), VM);

%% voltage limits (optimization side)
[vmin, vmax] = dali_opf_vlims(meta, cfg);
fixv = false(nb, 1);
if cfg.boundary.fix_voltage
    fixv = isb;
    vmin(fixv) = meta.snap_vm(fixv);
    vmax(fixv) = meta.snap_vm(fixv);
end
mpo.bus(:, VMIN) = vmin;
mpo.bus(:, VMAX) = vmax;

%% generator permissions (TRIAL, from snapshot values)
pg_s = meta.snap_gen_PG;
qg_s = meta.snap_gen_QG;
gb = mpo.gen(:, GEN_BUS);
isbg = ismember(gb, cfg.boundary.buses);
cand = find(gon & gb == meta.ref_bus);
[~, j] = max(pg_s(cand));
slackgen = cand(j);
orig = mpo.gen(:, [PMIN PMAX QMIN QMAX]);

switch lower(cfg.gen.p_policy)
    case 'fixed_snapshot'
        mpo.gen(gon, PMIN) = pg_s(gon);
        mpo.gen(gon, PMAX) = pg_s(gon);
    otherwise
        error('dali:opf', 'Only p_policy = fixed_snapshot is implemented for P0');
end
mpo.gen(slackgen, PMIN) = cfg.gen.slack_P_range(1);
mpo.gen(slackgen, PMAX) = cfg.gen.slack_P_range(2);

loc = gon & ~isbg;
switch lower(cfg.gen.q_policy)
    case 'pf_trial'
        pp = max(pg_s, 0);
        qmx = tan(acos(cfg.gen.pf_lag)) * pp;
        qmn = -tan(acos(cfg.gen.pf_lead)) * pp;
        mpo.gen(loc, QMAX) = max(qmx(loc), qg_s(loc));
        mpo.gen(loc, QMIN) = min(qmn(loc), qg_s(loc));
    case 'fixed_snapshot'
        mpo.gen(loc, QMAX) = qg_s(loc);
        mpo.gen(loc, QMIN) = qg_s(loc);
    case 'raw'
        % keep the +-1000 placeholders (diagnostic only)
    otherwise
        error('dali:opf', 'Unknown cfg.gen.q_policy');
end

%% costs: only the external slack generator carries the loss proxy price
mpo.gencost = repmat([2 0 0 2 0 0], ng, 1);
mpo.gencost(slackgen, 5) = cfg.obj.c_loss;

%% branch ratings
if cfg.rate.enforce_in_opf
    mpo.branch(:, RATE_A) = meta.rate_MVA_opf;
    mpo.branch(:, RATE_B) = meta.rate_MVA_opf;
    mpo.branch(:, RATE_C) = meta.rate_MVA_opf;
else
    mpo.branch(:, [RATE_A RATE_B RATE_C]) = 0;
end
if strcmpi(cfg.rate.unit, 'A')
    flow_lim = 'I';      % |I| <= RATE_A/baseMVA (MVA at 1 p.u.) == current rating
else
    flow_lim = 'S';
end

%% topology
if ~isempty(open_rows)
    mpo.branch(open_rows, BR_STATUS) = 0;
end
ncomp = dali_ncomp(nb, meta.f, meta.t, mpo.branch(:, BR_STATUS) == 1);
if ncomp > 1
    error('dali:opf', 'Opening rows %s splits the network into %d islands', mat2str(open_rows(:).'), ncomp);
end

%% soft voltage limits (only VMAX / VMIN of non-fixed buses)
soft = find(~fixv);
mpo_nosoft = mpo;
mpo.softlims.VMAX.idx = soft;
mpo.softlims.VMAX.cost = vpen * ones(numel(soft), 1);
mpo.softlims.VMIN.idx = soft;
mpo.softlims.VMIN.cost = vpen * ones(numel(soft), 1);
mpo = toggle_softlims(mpo, 'on');

opfset = struct();
opfset.vpen = vpen;
opfset.flow_lim = flow_lim;
opfset.slackgen = slackgen;
opfset.pmin = mpo_nosoft.gen(:, PMIN); opfset.pmax = mpo_nosoft.gen(:, PMAX);
opfset.qmin = mpo_nosoft.gen(:, QMIN); opfset.qmax = mpo_nosoft.gen(:, QMAX);
opfset.vmin = vmin; opfset.vmax = vmax;
opfset.fixv = fixv;
opfset.soft_idx = soft;
opfset.open_rows = open_rows(:);
opfset.mpo_nosoft = mpo_nosoft;

permtab = struct();
permtab.gen_row = (1:ng).';
permtab.bus = gb;
permtab.status = double(gon);
permtab.is_boundary = double(isbg);
permtab.is_slack_main = double((1:ng).' == slackgen);
permtab.PG_snapshot = pg_s; permtab.QG_snapshot = qg_s;
permtab.PMIN_src = orig(:, 1); permtab.PMAX_src = orig(:, 2);
permtab.QMIN_src = orig(:, 3); permtab.QMAX_src = orig(:, 4);
permtab.PMIN_trial = opfset.pmin; permtab.PMAX_trial = opfset.pmax;
permtab.QMIN_trial = opfset.qmin; permtab.QMAX_trial = opfset.qmax;
permtab.policy = repmat({sprintf('P:%s|Q:%s', cfg.gen.p_policy, cfg.gen.q_policy)}, ng, 1);
permtab.confirmed = repmat({'NO'}, ng, 1);
end
