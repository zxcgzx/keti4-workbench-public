function [tab, summ] = dali_ots_enum_reference(mpc, res0, E0, opfset0, meta, cfg, env, vpen, copt_open_rows)
%DALI_OTS_ENUM_REFERENCE  逐条开断的独立参考（不是COPT拓扑优化，不能替代COPT结果）：
%   对每个候选：(a) 代理QP（z固定，COPT连续求解）的 ΔJ_proxy；
%              (b) MATPOWER AC-OPF（同权重、同权限）的 ΔJ_AC。
%   用于检验代理模型对“开断带来的变化”的排序/符号是否可信。

fprintf('\n===== Enumeration reference (vpen=%g): %d single openings =====\n', vpen, numel(meta.cand_rows));
cand = meta.cand_rows(:);
nc = numel(cand);
allon = dali_ots_copt(res0, opfset0, meta, cfg, env, vpen, 'fixed', ones(nc, 1), {}, false);
tab = struct('branch_row', {}, 'from_bus', {}, 'to_bus', {}, 'kV', {}, ...
    'proxy_status', {}, 'dJ_proxy', {}, 'dLoss_proxy_MW', {}, 'dViol_proxy_pu', {}, ...
    'ac_converged', {}, 'dJ_AC', {}, 'dLoss_AC_MW', {}, 'dViol_AC_pu', {}, ...
    'ac_n_v_viol', {}, 'ac_status', {}, 'selected_by_COPT', {});
t0 = tic;
for j = 1:nc
    k = cand(j);
    zf = ones(nc, 1); zf(j) = 0;
    pj = dali_ots_copt(res0, opfset0, meta, cfg, env, vpen, 'fixed', zf, {}, false);
    [mpo, opfset] = dali_setup_opf(mpc, res0, meta, cfg, vpen, k);
    cfg_q = cfg; cfg_q.opf.verbose = 0;
    [rk, ~] = dali_run_acopf(mpo, opfset, cfg_q, env, sprintf('enum row %d', k));
    Ek = dali_eval_ac(rk, meta, cfg, vpen, sprintf('enum_row%d', k), opfset);
    tab(end+1) = struct('branch_row', k, 'from_bus', meta.ids(meta.f(k)), 'to_bus', meta.ids(meta.t(k)), ...
        'kV', meta.base_kv(meta.f(k)), ...
        'proxy_status', pj.status, 'dJ_proxy', pj.J_proxy - allon.J_proxy, ...
        'dLoss_proxy_MW', pj.loss_proxy_MW - allon.loss_proxy_MW, ...
        'dViol_proxy_pu', pj.viol_proxy_pu - allon.viol_proxy_pu, ...
        'ac_converged', Ek.converged, 'dJ_AC', Ek.J_AC - E0.J_AC, 'dLoss_AC_MW', Ek.loss_MW - E0.loss_MW, ...
        'dViol_AC_pu', Ek.sum_v_viol_opf_scope - E0.sum_v_viol_opf_scope, ...
        'ac_n_v_viol', Ek.n_v_over + Ek.n_v_under, 'ac_status', Ek.status, ...
        'selected_by_COPT', double(ismember(k, copt_open_rows))); %#ok<AGROW>
    fprintf('  row %4d (%d-%d): dJ_proxy=%9.4f  dJ_AC=%9.4f | dLoss proxy %8.4f AC %8.4f MW | proxy status %s, own viol %.1e\n', k, ...
        meta.ids(meta.f(k)), meta.ids(meta.t(k)), tab(end).dJ_proxy, tab(end).dJ_AC, ...
        tab(end).dLoss_proxy_MW, tab(end).dLoss_AC_MW, pj.status, pj.max_row_viol);
end
fprintf('Enumeration finished in %.1f s\n', toc(t0));

ok = [tab.ac_converged] == 1 & isfinite([tab.dJ_proxy]);
x = [tab(ok).dJ_proxy]; y = [tab(ok).dJ_AC];
xl = [tab(ok).dLoss_proxy_MW]; yl = [tab(ok).dLoss_AC_MW];
summ = struct();
summ.n = sum(ok);
summ.pearson_dJ = corr_simple(x, y);
summ.spearman_dJ = corr_simple(rank_simple(x), rank_simple(y));
summ.pearson_dLoss = corr_simple(xl, yl);
summ.sign_agree_dJ = mean(sign(x) == sign(y));
okrows = [tab(ok).branch_row];
summ.best_AC_row = NaN; summ.best_AC_dJ = NaN;
if ~isempty(y)
    [~, ia] = min(y);
    summ.best_AC_row = okrows(ia);
    summ.best_AC_dJ = y(ia);
end
summ.n_AC_improving = sum(y < -1e-6);
fprintf(['Proxy vs AC over %d single openings: Pearson(dJ)=%.3f Spearman(dJ)=%.3f Pearson(dLoss)=%.3f ', ...
    'sign agreement=%.2f | best AC single opening: row %d (dJ_AC=%.4f) | #AC-improving: %d\n'], ...
    summ.n, summ.pearson_dJ, summ.spearman_dJ, summ.pearson_dLoss, summ.sign_agree_dJ, ...
    summ.best_AC_row, summ.best_AC_dJ, summ.n_AC_improving);
end

function c = corr_simple(a, b)
if numel(a) < 3, c = NaN; return; end
m = corrcoef(a(:), b(:));
c = m(1, 2);
end

function r = rank_simple(v)
[~, o] = sort(v(:));
r = zeros(numel(v), 1);
r(o) = 1:numel(v);
end
