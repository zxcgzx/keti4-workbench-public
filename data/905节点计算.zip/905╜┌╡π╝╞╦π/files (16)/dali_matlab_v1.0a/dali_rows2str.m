function s = dali_rows2str(v)
%DALI_ROWS2STR  行号向量 -> 文本（空则 '[]'）。
v = v(:).';
if isempty(v)
    s = '[]';
else
    s = ['[' strjoin(arrayfun(@num2str, v, 'UniformOutput', false), ' ') ']'];
end
end
