function nc = dali_ncomp(nb, f, t, on)
%DALI_NCOMP  连通分量个数（f,t 为内部母线序号 1..nb，on 为在运支路逻辑向量）。
%   不依赖 graph 工具箱；并联支路、自环均可。
E = find(on(:));
seen = false(nb, 1);
nc = 0;
if isempty(E)
    nc = nb;
    return;
end
A = sparse([f(E); t(E)], [t(E); f(E)], 1, nb, nb);
for s = 1:nb
    if seen(s), continue; end
    nc = nc + 1;
    seen(s) = true;
    q = s;
    while ~isempty(q)
        [nbrs, ~] = find(A(:, q));
        nbrs = unique(nbrs);
        nbrs = nbrs(~seen(nbrs));
        seen(nbrs) = true;
        q = nbrs;
    end
end
end
