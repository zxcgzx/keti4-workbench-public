function S = dali_mp_solve(blocks, info, cfg, env)
%DALI_MP_SOLVE  拼装多时段 MIQP（v1.0-a）并用 COPT 求解。
%   blocks{t} : dali_mp_build_period 的单时段块（目标已乘 dt）
%   info      : .disp (可调机组逻辑向量), .pg_init (MW, 第 0 时段出力，即 S1 解), .base
%   时段耦合：
%     动作变量 y(k,t) >= |z(k,t) - z(k,t-1)|，z(k,0) = 1（初始全在运）；Σ y <= max_actions；
%     最小持续：0 <= z(k,tau) - z(k,t) + z(k,t-1) <= 1，tau = t+1 .. t+L-1（穷举验证与规则一致）；
%     可调机组爬坡：|Pg(g,t) - Pg(g,t-1)| <= ramp_frac * PG_init(g)，Pg(g,0) = PG_init(g)。
%   目标：Σ_t dt*(网损代理 + vpen*电压越限) + action_cost * Σ y。

T = numel(blocks);
nc = blocks{1}.nc; ng = blocks{1}.ng; base = info.base;
nvs = cellfun(@(b) b.nv, blocks);
off = [0, cumsum(nvs(1:end-1))];
nvb = sum(nvs);
iY = nvb + (1:nc * T);
nv = nvb + nc * T;
zc = zeros(nc, T); pc = zeros(ng, T);
for t = 1:T
    zc(:, t) = off(t) + blocks{t}.idx.iZ(:);
    pc(:, t) = off(t) + blocks{t}.idx.iPg(:);
end
yc = reshape(iY, nc, T);

%% block-diagonal part
Ac = cellfun(@(b) b.P.A, blocks, 'UniformOutput', false);
Qc = cellfun(@(b) b.P.Qd, blocks, 'UniformOutput', false);
A = blkdiag(Ac{:});
A = [A, sparse(size(A, 1), nc * T)];
lhs = cell2mat(cellfun(@(b) b.P.lhs(:), blocks(:), 'UniformOutput', false));
rhs = cell2mat(cellfun(@(b) b.P.rhs(:), blocks(:), 'UniformOutput', false));
obj = [cell2mat(cellfun(@(b) b.P.obj(:), blocks(:), 'UniformOutput', false)); cfg.mp.action_cost * ones(nc * T, 1)];
Qd = blkdiag(Qc{:}, sparse(nc * T, nc * T));
objcon = sum(cellfun(@(b) b.P.objcon, blocks));
lb = [cell2mat(cellfun(@(b) b.P.lb(:), blocks(:), 'UniformOutput', false)); zeros(nc * T, 1)];
ub = [cell2mat(cellfun(@(b) b.P.ub(:), blocks(:), 'UniformOutput', false)); ones(nc * T, 1)];
vtype = [cell2mat(cellfun(@(b) b.P.vtype(:).', blocks(:).', 'UniformOutput', false)), repmat('C', 1, nc * T)];
if isfield(info, 'fix_z_all_on') && info.fix_z_all_on      % reference: no switching in any period (continuous QP)
    lb(zc(:)) = 1; ub(zc(:)) = 1; vtype(zc(:)) = 'C';
end

%% coupling rows
I = []; J = []; V = []; cl = []; cu = []; r = 0;
    function addrow(cols, vals, lo, hi)
        r = r + 1;
        I = [I; r * ones(numel(cols), 1)]; J = [J; cols(:)]; V = [V; vals(:)];
        cl = [cl; lo]; cu = [cu; hi];
    end
for t = 1:T
    for k = 1:nc
        if t == 1
            addrow([yc(k, 1), zc(k, 1)], [1, -1], -1, inf);   % y >= z0 - z1 = 1 - z1
            addrow([yc(k, 1), zc(k, 1)], [1, 1], 1, inf);     % y >= z1 - z0
        else
            addrow([yc(k, t), zc(k, t), zc(k, t - 1)], [1, -1, 1], 0, inf);
            addrow([yc(k, t), zc(k, t), zc(k, t - 1)], [1, 1, -1], 0, inf);
        end
    end
end
addrow(iY, ones(1, numel(iY)), -inf, cfg.mp.max_actions);
L = cfg.mp.min_hold;
for t = 1:T
    for tau = t + 1:min(t + L - 1, T)
        for k = 1:nc
            if t == 1
                addrow([zc(k, tau), zc(k, 1)], [1, -1], -1, 0);          % z0 = 1
            else
                addrow([zc(k, tau), zc(k, t), zc(k, t - 1)], [1, -1, 1], 0, 1);
            end
        end
    end
end
dg = find(info.disp(:));
R = cfg.mp.ramp_frac * abs(info.pg_init(dg)) / base;
for t = 1:T
    for j = 1:numel(dg)
        g = dg(j);
        if t == 1
            addrow(pc(g, 1), 1, info.pg_init(g) / base - R(j), info.pg_init(g) / base + R(j));
        else
            addrow([pc(g, t), pc(g, t - 1)], [1, -1], -R(j), R(j));
        end
    end
end
Acp = sparse(I, J, V, r, nv);
P = struct('A', [A; Acp], 'lhs', [lhs; cl], 'rhs', [rhs; cu], 'obj', obj, 'Qd', Qd, ...
    'objcon', objcon, 'lb', lb, 'ub', ub, 'vtype', vtype);

fprintf('\n--- Multi-period MIQP: %d periods, %d vars (%d binary), %d rows (%d coupling), nnz(A)=%d ---\n', ...
    T, nv, sum(vtype == 'B'), size(P.A, 1), r, nnz(P.A));
tb = tic;
cfg2 = cfg;
cfg2.copt.time_limit = cfg.mp.time_limit;
sol = dali_copt_call(P, env, cfg2, 1);
S = struct();
S.solve_time_s = toc(tb);
S.status = sol.status; S.ok = sol.ok; S.objval = sol.objval; S.bestgap = sol.bestgap;
S.nodecnt = sol.nodecnt; S.retry = sol.retry; S.nvars = nv; S.nbin = sum(vtype == 'B');
S.nrows = size(P.A, 1); S.ncoupling = r;
S.z = nan(nc, T); S.actions = NaN; S.pg = nan(ng, T); S.loss_proxy = nan(1, T); S.viol_proxy = nan(1, T);
S.dV = cell(1, T); S.max_row_viol = nan(1, T);
if ~sol.ok
    fprintf(2, 'Multi-period MIQP: no solution (%s)\n', sol.status);
    return;
end
x = sol.x;
S.z = reshape(x(zc(:)), nc, T);
S.actions = sum(x(iY));
for t = 1:T
    b = blocks{t};
    xt = x(off(t) + (1:b.nv));
    S.pg(:, t) = xt(b.idx.iPg) * base;
    on = true(b.nl, 1); on(b.cand(S.z(:, t) < 0.5)) = false;
    pf = xt(b.idx.iPf); qf = xt(b.idx.iQf);
    S.loss_proxy(t) = base * sum(on .* b.w .* (pf.^2 + (qf + b.cch).^2));
    S.viol_proxy(t) = sum(xt(b.idx.iSp)) + sum(xt(b.idx.iSm));
    S.dV{t} = xt(b.idx.iV);
    ax = b.A0 * xt;
    S.max_row_viol(t) = max([0; b.lhs0 - ax; ax - b.rhs0]);
end
ax = Acp * x;
S.max_coupling_viol = max([0; cl - ax; ax - cu]);
fprintf('  multi-period MIQP: status=%s, %.2f s, obj %.4f, gap %g, nodes %g, actions %.0f | own max row viol: periods %.1e, coupling %.1e\n', ...
    S.status, S.solve_time_s, S.objval, S.bestgap, S.nodecnt, S.actions, max(S.max_row_viol), S.max_coupling_viol);
end
