function out = dali_copt_call(P, env, cfg, logging)
%DALI_COPT_CALL  统一的 COPT 调用封装。
%   P.A (sparse), P.lhs, P.rhs (行上下界, ±Inf 表示无界), P.obj, P.Qd (目标中 x'*Qd*x),
%   P.objcon, P.lb, P.ub, P.vtype ('C'/'B' 字符行向量)。
%   约束写法与二次项约定由 STEP0 冒烟测试确定（env.copt.rowfmt / env.copt.qmult）。

if nargin < 4, logging = 1; end
INF = 1e30;
prob = struct();
prob.objsen = 'min';
prob.objcon = P.objcon;
prob.obj = full(P.obj(:));
prob.lb = max(full(P.lb(:)), -INF);
prob.ub = min(full(P.ub(:)), INF);
prob.vtype = char(P.vtype(:).');
if isfield(P, 'Qd') && ~isempty(P.Qd) && nnz(P.Qd) > 0
    prob.Q = env.copt.qmult * P.Qd;
end
lhs = max(full(P.lhs(:)), -INF);
rhs = min(full(P.rhs(:)), INF);
switch env.copt.rowfmt
    case 'lhsrhs'
        prob.A = P.A;
        prob.lhs = lhs;
        prob.rhs = rhs;
    case 'sense'
        [prob.A, prob.sense, prob.rhs] = to_sense(P.A, lhs, rhs, INF);
    otherwise
        error('dali:copt', 'COPT interface not verified (run STEP 0).');
end
par = struct('Logging', logging, 'TimeLimit', cfg.copt.time_limit, ...
    'RelGap', cfg.copt.rel_gap, 'IntTol', cfg.copt.int_tol);
if cfg.copt.threads > 0
    par.Threads = cfg.copt.threads;
end
if isfield(cfg.copt, 'extra_params') && isstruct(cfg.copt.extra_params)
    xp = fieldnames(cfg.copt.extra_params);
    for i = 1:numel(xp)
        par.(xp{i}) = cfg.copt.extra_params.(xp{i});
    end
end

out = struct('ok', false, 'status', '', 'x', [], 'objval', NaN, 'bestgap', NaN, ...
    'nodecnt', NaN, 'time_s', NaN, 'nvars', numel(prob.obj), 'nrows', size(prob.A, 1), ...
    'nbin', sum(prob.vtype == 'B'), 'error', '');
out.retry = '';
t0 = tic;
out = one_solve(prob, par, out);
already_off = isfield(par, 'Presolve') && par.Presolve == 0;
if ~out.ok && isempty(out.error) && ~already_off
    first = out.status;
    par2 = par;
    par2.Presolve = 0;
    out = one_solve(prob, par2, out);
    out.retry = sprintf('first status %s; retried with Presolve=0 -> %s', first, out.status);
    fprintf('  COPT retry: %s\n', out.retry);
end
out.time_s = toc(t0);
end

function out = one_solve(prob, par, out)
try
    r = copt_solve(prob, par);
catch err
    out.error = err.message;
    fprintf(2, 'copt_solve raised: %s\n', err.message);
    return;
end
out.status = ''; out.x = []; out.objval = NaN; out.bestgap = NaN; out.nodecnt = NaN;
if isfield(r, 'status'), out.status = char(r.status); end
if isfield(r, 'x'), out.x = r.x(:); end
if isfield(r, 'objval'), out.objval = r.objval; end
if isfield(r, 'bestgap'), out.bestgap = r.bestgap; end
if isfield(r, 'nodecnt'), out.nodecnt = r.nodecnt; end
out.ok = ~isempty(out.x) && numel(out.x) == numel(prob.obj) && ...
    any(strcmpi(out.status, {'optimal', 'timeout', 'nodelimit', 'interrupted'}));
end

function [A2, sense, rhs2] = to_sense(A, lhs, rhs, INF)
isE = lhs == rhs;
loInf = lhs <= -INF; hiInf = rhs >= INF;
isL = ~isE & loInf & ~hiInf;
isG = ~isE & ~loInf & hiInf;
isR = ~isE & ~loInf & ~hiInf;
A2 = [A(isE, :); A(isL, :); A(isG, :); A(isR, :); A(isR, :)];
sense = [repmat('E', 1, sum(isE)), repmat('L', 1, sum(isL)), repmat('G', 1, sum(isG)), ...
    repmat('G', 1, sum(isR)), repmat('L', 1, sum(isR))];
rhs2 = [rhs(isE); rhs(isL); lhs(isG); lhs(isR); rhs(isR)];
end
