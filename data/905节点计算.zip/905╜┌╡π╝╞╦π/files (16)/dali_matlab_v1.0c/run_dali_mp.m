function run_dali_mp(varargin)
%RUN_DALI_MP  课题4 指标4.1 多时段参考模型 v1.0-a：16 时段 × 8 候选开关 + 可调机组出力（含爬坡）。
%   流程：P0 准备（读数、建算例、S1 AC-OPF，不计入 4.1 时钟）→
%         MP-1 生成时段数据与线性化点（逐时段 ACPF）→ MP-2 逐时段建块 → MP-3 COPT 整体 MIQP
%         （4.1 时钟到此为止：从输入数据到可行解）→ 对照：同模型固定全在运的连续 QP →
%         MP-4 逐时段 MATPOWER AC 校核与指标。
%   默认电压口径为任务书口径（P0 结论）。覆盖配置同 run_dali_p0，例如 run_dali_mp('mp.max_actions', 8)。

here = fileparts(mfilename('fullpath'));
addpath(here);
cfg = dali_p0_config();
cfg.vlim.opf_source = 'taskbook_proxy';
if mod(numel(varargin), 2) ~= 0
    error('dali:mp', 'Overrides must be name/value pairs');
end
for i = 1:2:numel(varargin)
    fpath = strsplit(varargin{i}, '.');
    cfg = setfield(cfg, fpath{:}, varargin{i+1}); %#ok<SFLD>
end
if isempty(cfg.outdir)
    cfg.outdir = fullfile(here, sprintf('out_MP_T%d_%s', cfg.mp.T, cfg.vlim.opf_source));
end
if ~exist(cfg.outdir, 'dir'), mkdir(cfg.outdir); end
stamp = datestr(now, 'yyyymmdd_HHMMSS');
logf = fullfile(cfg.outdir, ['MP_log_' stamp '.txt']);
diary(logf);
cleaner = onCleanup(@() diary('off')); %#ok<NASGU>
fprintf('Dali multi-period reference model run %s (package v1.0-c)\n', stamp);
for i = 1:2:numel(varargin)
    fprintf('  override: %s = %s\n', varargin{i}, mat2str(varargin{i+1}));
end
try
    main_mp(cfg, stamp, logf);
catch err
    fprintf(2, '\n*** RUN FAILED ***\n%s\n', getReport(err, 'extended', 'hyperlinks', 'off'));
    fprintf('\nPlease upload the log file: %s\n', logf);
end
end

%% =======================================================================
function main_mp(cfg, stamp, logf)
Tm = struct();
t0 = tic;
env = dali_p0_step0_env(cfg);
if ~env.matpower_ok, error('dali:mp', 'MATPOWER >= 7 required'); end
if ~env.copt.ok, error('dali:mp', 'COPT interface not available'); end
define_constants;
raw = dali_read_pasexp(cfg.txtfile);
topo = dali_topology_audit(raw, cfg);
[mpc, ~, meta] = dali_build_case(raw, topo, cfg);
[pf0, ~] = dali_run_acpf(mpc, meta, 'equivalent_v1', false, false);
vpen = cfg.mp.vpen;
[mpo, opfset] = dali_setup_opf(mpc, pf0, meta, cfg, vpen, []);
[r1, i1] = dali_run_acopf(mpo, opfset, cfg, env, 'MP period-0 controls (S1)');
if ~i1.success, error('dali:mp', 'S1 AC-OPF failed; cannot set period controls'); end
Tm.p0_prep_s = toc(t0);

%% ---------------- MP-1: period data + linearisation points (4.1 clock starts) ----------------
T = cfg.mp.T;
fprintf('\n===== MP-1: %d periods of %.2f h, load factor %.3f -> %.3f =====\n', T, cfg.mp.dt_h, ...
    cfg.mp.load_start, cfg.mp.load_end);
tclock = tic; tt = tic;
lam = linspace(cfg.mp.load_start, cfg.mp.load_end, T);
sel = mpc.bus(:, PD) > 0 & meta.base_kv <= cfg.mp.load_kv_max & ~meta.is_boundary;
gon = mpc.gen(:, GEN_STATUS) > 0;
dispg = gon & ~ismember(mpc.gen(:, GEN_BUS), cfg.boundary.buses) & meta.snap_gen_PG >= cfg.mp.disp_min_MW;
dispg(opfset.slackgen) = false;
pg_init = r1.gen(:, PG);
opm = opfset;
opm.pmin(dispg) = (1 - cfg.mp.disp_range) * pg_init(dispg);
opm.pmax(dispg) = (1 + cfg.mp.disp_range) * pg_init(dispg);
fprintf('  scaled load: %d buses, %.1f MW at factor 1 | dispatchable units: %d (%.1f MW), range +-%.0f%%, ramp %.0f%%/period\n', ...
    sum(sel), sum(mpc.bus(sel, PD)), sum(dispg), sum(pg_init(dispg)), 100 * cfg.mp.disp_range, 100 * cfg.mp.ramp_frac);
m0 = mpc;
m0.gen(:, QMIN) = opfset.qmin;
m0.gen(:, QMAX) = opfset.qmax;
mpopt_pf = mpoption('pf.alg', 'NR', 'pf.tol', 1e-8, 'pf.nr.max_it', 30, 'verbose', 0, 'out.all', 0, ...
    'pf.enforce_q_lims', 1);
cases = cell(1, T); bases = cell(1, T);
for t = 1:T
    mt = m0;
    mt.bus(sel, PD) = mpc.bus(sel, PD) * lam(t);
    mt.bus(sel, QD) = mpc.bus(sel, QD) * lam(t);
    cases{t} = mt;
    rt = runpf(dali_pf_case_from_state(mt, r1, meta, []), mpopt_pf);
    if ~rt.success
        error('dali:mp', 'Base ACPF failed at period %d (load factor %.3f)', t, lam(t));
    end
    bases{t} = rt;
end
Tm.mp1_period_acpf_s = toc(tt);
fprintf('  %d base power flows converged in %.2f s\n', T, Tm.mp1_period_acpf_s);

%% ---------------- MP-2: blocks ----------------
fprintf('\n===== MP-2: build %d period blocks =====\n', T);
tt = tic;
blocks = cell(1, T);
cfg.ots.taps = cfg.mp.taps;
for t = 1:T
    blocks{t} = dali_mp_build_period(bases{t}, opm, meta, cfg, vpen, cfg.mp.dt_h, t == 1);
end
Tm.mp2_build_s = toc(tt);
ntp = numel(blocks{1}.tapk);
fprintf('  blocks built in %.2f s | integer decisions: %d switches x %d periods = %d binary, %d taps x %d periods = %d integer (binary-encoded equivalent %d)\n', ...
    Tm.mp2_build_s, numel(meta.cand_rows), T, numel(meta.cand_rows) * T, ntp, T, ntp * T, ...
    T * getfield_def(blocks{1}.chk, 'tap_binary_equiv', 0));

%% ---------------- MP-3 (v1.0-c): dispatch-only QP -> relaxed taps -> rounded taps -> optional COPT MIP ----------------
info = struct('disp', dispg, 'pg_init', pg_init, 'base', mpc.baseMVA, 'z_mode', 'all_on', 'tap_mode', 'zero');
fprintf('\n===== MP-3a: dispatch only (switches all in service, taps at current step), loss model %s =====\n', cfg.mp.loss_model);
S0 = dali_mp_solve(blocks, info, cfg, env);
Tm.mp3a_dispatch_s = S0.solve_time_s;
Tm.clock_first_feasible_s = toc(tclock);
if ~S0.ok
    error('dali:mp', 'Dispatch-only problem returned no solution (status %s)', S0.status);
end
fprintf('\n  >>> 4.1 clock to FIRST feasible solution (dispatch only): %.2f s  [ACPF %.2f + build %.2f + solve %.2f]\n', ...
    Tm.clock_first_feasible_s, Tm.mp1_period_acpf_s, Tm.mp2_build_s, Tm.mp3a_dispatch_s);
S = S0; used = 'DISPATCH_ONLY';
Tm.mp3b_relax_s = 0; Tm.mp3c_round_s = 0; Tm.mp3d_copt_mip_s = 0;
Sr = []; Sh = []; Sm = [];
if ntp > 0
    fprintf('\n===== MP-3b: tap steps relaxed to continuous (switches all in service) -> lower bound for this subproblem =====\n');
    info.tap_mode = 'relax';
    Sr = dali_mp_solve(blocks, info, cfg, env);
    Tm.mp3b_relax_s = Sr.solve_time_s;
    if Sr.ok
        fprintf('\n===== MP-3c: round taps period by period (|move| <= %g step, within range), fix, re-solve =====\n', cfg.mp.tap_move_max);
        nfix = round_taps(Sr.ntap_cont, Sr.tap_lo, Sr.tap_hi, cfg.mp.tap_move_max);
        info.tap_mode = 'fixed'; info.tap_fix = nfix;
        Sh = dali_mp_solve(blocks, info, cfg, env);
        Tm.mp3c_round_s = Sh.solve_time_s;
        if Sh.ok
            Sh.ntap = nfix;
            Sh.tap_moves = sum(sum(abs(diff([zeros(ntp, 1), nfix], 1, 2))));
            fprintf(['  relax-and-round: objective %.4f vs relaxed bound %.4f (gap %.3f%%) vs dispatch only %.4f | ', ...
                'tap moves %d, taps used %d of %d\n'], Sh.objval, Sr.objval, 100 * (Sh.objval - Sr.objval) / max(abs(Sh.objval), eps), ...
                S0.objval, Sh.tap_moves, sum(any(nfix ~= 0, 2)), ntp);
            if Sh.objval < S.objval, S = Sh; used = 'RELAX_AND_ROUND'; end
        end
    end
end
Tm.clock_heuristic_s = toc(tclock);
fprintf('\n  >>> 4.1 clock to INTEGER-FEASIBLE solution (%s): %.2f s  [ACPF %.2f + build %.2f + dispatch %.2f + relax %.2f + round %.2f]\n', ...
    used, Tm.clock_heuristic_s, Tm.mp1_period_acpf_s, Tm.mp2_build_s, Tm.mp3a_dispatch_s, Tm.mp3b_relax_s, Tm.mp3c_round_s);
if cfg.mp.copt_mip
    fprintf('\n===== MP-3d: COPT on the full integer model (switches + taps), MIP start = %s solution, %g s (benchmark) =====\n', ...
        used, cfg.mp.copt_mip_time);
    info.z_mode = 'free'; info.tap_mode = 'integer'; info.start = S.x; info.time_limit = cfg.mp.copt_mip_time;
    Sm = dali_mp_solve(blocks, info, cfg, env);
    Tm.mp3d_copt_mip_s = Sm.solve_time_s;
    if Sm.ok
        fprintf('  COPT benchmark: status %s, objective %.4f (start %.4f), gap %g\n', Sm.status, Sm.objval, S.objval, Sm.bestgap);
        if Sm.objval < S.objval - 1e-6, S = Sm; used = 'COPT_MIP'; end
    end
end
Tm.clock_input_to_solution_s = toc(tclock);
fprintf('\n  >>> final decision from %s | objective %.4f (dispatch only %.4f) | switching actions %g | tap moves %g\n', ...
    used, S.objval, S0.objval, S.actions, S.tap_moves);

%% ---------------- MP-4: AC check per period ----------------
fprintf('\n===== MP-4: MATPOWER AC check per period =====\n');
tt = tic;
R = struct('t', {}, 'load_factor', {}, 'load_MW', {}, 'open_rows', {}, 'disp_pg_MW', {}, ...
    'base_loss_MW', {}, 'proxy_loss_MW', {}, 'dec_loss_MW', {}, 'base_viol_pu', {}, 'proxy_viol_pu', {}, ...
    'dec_viol_pu', {}, 'base_tbVQ_pct', {}, 'dec_tbVQ_pct', {}, 'dec_converged', {}, 'proxy_row_viol', {});
for t = 1:T
    open = meta.cand_rows(S.z(:, t) < 0.5);
    st = bases{t};
    st.gen(:, PG) = S.pg(:, t);
    st.bus(:, VM) = blocks{t}.vm0 + S.dV{t}(blocks{t}.sidx(:));
    mchk = dali_pf_case_from_state(cases{t}, st, meta, open);
    if ntp > 0
        mchk.branch(blocks{t}.tapk, TAP) = blocks{t}.tau0 + blocks{t}.tapstep * S.ntap(:, t);
    end
    rchk = safe_pf(mchk, mpopt_pf);
    Eb = dali_eval_ac(bases{t}, meta, cfg, vpen, sprintf('t%02d_base', t), opm);
    Ed = dali_eval_ac(rchk, meta, cfg, vpen, sprintf('t%02d_decision', t), opm);
    R(end+1) = struct('t', t, 'load_factor', lam(t), 'load_MW', sum(cases{t}.bus(sel, PD)), ...
        'open_rows', dali_rows2str(open), 'disp_pg_MW', sum(S.pg(dispg, t)), ...
        'base_loss_MW', Eb.loss_MW, 'proxy_loss_MW', S.loss_proxy(t), 'dec_loss_MW', Ed.loss_MW, ...
        'base_viol_pu', Eb.sum_v_viol_opf_scope, 'proxy_viol_pu', S.viol_proxy(t), 'dec_viol_pu', Ed.sum_v_viol_opf_scope, ...
        'base_tbVQ_pct', Eb.tb_vq_rate_110_35kV_pct, 'dec_tbVQ_pct', Ed.tb_vq_rate_110_35kV_pct, ...
        'dec_converged', Ed.converged, 'proxy_row_viol', S.max_row_viol(t)); %#ok<AGROW>
    fprintf(['  t%02d load x%.3f | open %-6s | taps moved %3d | disp %.1f MW | loss base %.3f -> AC %.3f (proxy %.3f) MW | ', ...
        'viol %.4f -> %.4f pu | 110/35kV qualified %.1f%% -> %.1f%% | conv %d\n'], t, lam(t), R(end).open_rows, ...
        sum(S.ntap(:, t) ~= 0), R(end).disp_pg_MW, Eb.loss_MW, Ed.loss_MW, S.loss_proxy(t), Eb.sum_v_viol_opf_scope, ...
        Ed.sum_v_viol_opf_scope, Eb.tb_vq_rate_110_35kV_pct, Ed.tb_vq_rate_110_35kV_pct, Ed.converged);
end
Tm.mp4_ac_check_s = toc(tt);
dt = cfg.mp.dt_h;
Eloss_base = dt * sum([R.base_loss_MW]);
dpg = S.pg(dispg, :) - pg_init(dispg) * ones(1, T);          % MW, per unit x period
E_up = dt * sum(max(dpg(:), 0)); E_down = dt * sum(max(-dpg(:), 0));
fprintf('  dispatchable units: +%.2f MWh raised, -%.2f MWh reduced vs S1 over the horizon (curtail cost %g $/MWh)\n', ...
    E_up, E_down, cfg.mp.curtail_cost);
Eloss_dec = dt * sum([R.dec_loss_MW]);
fprintf(['\n  horizon: energy loss base %.2f MWh -> decision %.2f MWh (%.2f MWh, %.2f%%) | switching actions %.0f | ', ...
    'tap moves %g | AC converged %d/%d\n'], Eloss_base, Eloss_dec, Eloss_dec - Eloss_base, 100 * (Eloss_dec - Eloss_base) / Eloss_base, ...
    S.actions, S.tap_moves, sum([R.dec_converged]), T);

%% ---------------- outputs ----------------
writetable(struct2table(R), fullfile(cfg.outdir, 'MP_periods.csv'));
Ssum = rmfield(S, intersect(fieldnames(S), {'z', 'pg', 'dV', 'loss_proxy', 'viol_proxy', 'max_row_viol', 'x', 'ntap', 'ntap_cont', 'tap_lo', 'tap_hi'}));
Ssum.decision_from = used;
Ssum.ref_qp_objval = S0.objval; Ssum.ref_qp_time_s = S0.solve_time_s;
Ssum.relaxed_bound = NaN; Ssum.round_objval = NaN; Ssum.copt_mip_objval = NaN; Ssum.copt_mip_gap = NaN;
if ~isempty(Sr) && Sr.ok, Ssum.relaxed_bound = Sr.objval; end
if ~isempty(Sh) && Sh.ok, Ssum.round_objval = Sh.objval; end
if ~isempty(Sm) && Sm.ok, Ssum.copt_mip_objval = Sm.objval; Ssum.copt_mip_gap = Sm.bestgap; end
Ssum.clock_heuristic_s = Tm.clock_heuristic_s;
Ssum.Eloss_base_MWh = Eloss_base; Ssum.Eloss_dec_MWh = Eloss_dec;
Ssum.disp_raised_MWh = E_up; Ssum.disp_reduced_MWh = E_down; Ssum.curtail_cost = cfg.mp.curtail_cost;
writetable(struct2table(Ssum, 'AsArray', true), fullfile(cfg.outdir, 'MP_solve_summary.csv'));
writetable(array2table(S.z.', 'VariableNames', arrayfun(@(k) sprintf('row%d', k), meta.cand_rows(:).', ...
    'UniformOutput', false)), fullfile(cfg.outdir, 'MP_switch_schedule.csv'));
S = rmfield(S, 'x'); S0 = rmfield(S0, 'x');
if ntp > 0, writematrix(S.ntap, fullfile(cfg.outdir, 'MP_tap_schedule.csv')); end
save(fullfile(cfg.outdir, 'MP_workspace.mat'), 'cfg', 'S', 'S0', 'R', 'Tm', 'lam', 'dispg', '-v7');
Tm.total_s = toc(t0);
fprintf('\nTimings (s):\n'); disp(Tm);
fprintf('\n===== DONE. Upload %s (MP_log_*, MP_periods.csv, MP_solve_summary.csv, MP_switch_schedule.csv) =====\n', cfg.outdir);
end

function r = safe_pf(m, mpopt)
try
    r = runpf(m, mpopt);
catch
    r = struct('success', 0);
end
end

function s = ternary(c, a, b)
if c, s = a; else, s = b; end
end

function v = getfield_def(s, f, d)
if isfield(s, f), v = s.(f); else, v = d; end
end

function n = round_taps(nr, lo, hi, mv)
% Round relaxed tap steps period by period, keeping |n(t) - n(t-1)| <= mv (n(0) = 0) and lo <= n <= hi.
[ntp, T] = size(nr);
n = zeros(ntp, T);
prev = zeros(ntp, 1);
for t = 1:T
    v = round(nr(:, t));
    v = min(max(v, prev - mv), prev + mv);
    v = min(max(v, lo(:)), hi(:));
    n(:, t) = v;
    prev = v;
end
end
