function S = dali_mp_solve(blocks, info, cfg, env)
%DALI_MP_SOLVE  拼装多时段 MIQP（v1.0-a）并用 COPT 求解。
%   blocks{t} : dali_mp_build_period 的单时段块（目标已乘 dt）
%   info      : .disp (可调机组逻辑向量), .pg_init (MW, 第 0 时段出力，即 S1 解), .base
%   时段耦合：
%     动作变量 y(k,t) >= |z(k,t) - z(k,t-1)|，z(k,0) = 1（初始全在运）；Σ y <= max_actions；
%     最小持续：0 <= z(k,tau) - z(k,t) + z(k,t-1) <= 1，tau = t+1 .. t+L-1（穷举验证与规则一致）；
%     可调机组爬坡：|Pg(g,t) - Pg(g,t-1)| <= ramp_frac * PG_init(g)，Pg(g,0) = PG_init(g)。
%   目标：Σ_t dt*(网损代理 + vpen*电压越限) + action_cost * Σ y。

T = numel(blocks);
nc = blocks{1}.nc; ng = blocks{1}.ng; base = info.base;
ispwl = isfield(cfg.mp, 'loss_model') && strcmpi(cfg.mp.loss_model, 'pwl');
npwl = zeros(1, T);
if ispwl                                              % v1.0-a4: MILP form of the loss objective
    for t = 1:T
        [blocks{t}, npwl(t)] = pwl_block(blocks{t}, cfg);
    end
    fprintf('  loss objective: piecewise-linear (%d tangents) on %d-%d flow variables per period, first-order on the rest\n', ...
        numel(cfg.mp.pwl_grid) + 1, min(npwl), max(npwl));
end
nvs = cellfun(@(b) b.nv, blocks);
off = [0, cumsum(nvs(1:end-1))];
nvb = sum(nvs);
iY = nvb + (1:nc * T);
dg = find(info.disp(:)); nd = numel(dg);
usecurt = isfield(cfg.mp, 'curtail_cost') && cfg.mp.curtail_cost > 0;
ndv = usecurt * nd * T;                                % curtailment variables d(g,t) >= PG_init - Pg(g,t)
iD = nvb + nc * T + (1:ndv);
nv = nvb + nc * T + ndv;
ntp = numel(blocks{1}.idx.iN);
zc = zeros(nc, T); pc = zeros(ng, T); tc = zeros(ntp, T);
for t = 1:T
    zc(:, t) = off(t) + blocks{t}.idx.iZ(:);
    pc(:, t) = off(t) + blocks{t}.idx.iPg(:);
    tc(:, t) = off(t) + blocks{t}.idx.iN(:);
end
yc = reshape(iY, nc, T);

%% block-diagonal part
Ac = cellfun(@(b) b.P.A, blocks, 'UniformOutput', false);
Qc = cellfun(@(b) b.P.Qd, blocks, 'UniformOutput', false);
A = blkdiag(Ac{:});
A = [A, sparse(size(A, 1), nc * T + ndv)];
lhs = cell2mat(cellfun(@(b) b.P.lhs(:), blocks(:), 'UniformOutput', false));
rhs = cell2mat(cellfun(@(b) b.P.rhs(:), blocks(:), 'UniformOutput', false));
obj = [cell2mat(cellfun(@(b) b.P.obj(:), blocks(:), 'UniformOutput', false)); cfg.mp.action_cost * ones(nc * T, 1); ...
    usecurt * cfg.mp.curtail_cost * cfg.mp.dt_h * base * ones(ndv, 1)];
Qd = blkdiag(Qc{:}, sparse(nc * T + ndv, nc * T + ndv));
objcon = sum(cellfun(@(b) b.P.objcon, blocks));
lb = [cell2mat(cellfun(@(b) b.P.lb(:), blocks(:), 'UniformOutput', false)); zeros(nc * T + ndv, 1)];
ub = [cell2mat(cellfun(@(b) b.P.ub(:), blocks(:), 'UniformOutput', false)); ones(nc * T, 1); inf(ndv, 1)];
vtype = [cell2mat(cellfun(@(b) b.P.vtype(:).', blocks(:).', 'UniformOutput', false)), repmat('C', 1, nc * T + ndv)];
if isfield(info, 'fix_z_all_on') && info.fix_z_all_on      % reference: no switching, taps at current step
    lb(zc(:)) = 1; ub(zc(:)) = 1; vtype(zc(:)) = 'C';
    lb(tc(:)) = 0; ub(tc(:)) = 0; vtype(tc(:)) = 'C';
end

%% coupling rows
I = []; J = []; V = []; cl = []; cu = []; r = 0;
    function addrow(cols, vals, lo, hi)
        r = r + 1;
        I = [I; r * ones(numel(cols), 1)]; J = [J; cols(:)]; V = [V; vals(:)];
        cl = [cl; lo]; cu = [cu; hi];
    end
for t = 1:T
    for k = 1:nc
        if t == 1
            addrow([yc(k, 1), zc(k, 1)], [1, -1], -1, inf);   % y >= z0 - z1 = 1 - z1
            addrow([yc(k, 1), zc(k, 1)], [1, 1], 1, inf);     % y >= z1 - z0
        else
            addrow([yc(k, t), zc(k, t), zc(k, t - 1)], [1, -1, 1], 0, inf);
            addrow([yc(k, t), zc(k, t), zc(k, t - 1)], [1, 1, -1], 0, inf);
        end
    end
end
addrow(iY, ones(1, numel(iY)), -inf, cfg.mp.max_actions);
L = cfg.mp.min_hold;
for t = 1:T
    for tau = t + 1:min(t + L - 1, T)
        for k = 1:nc
            if t == 1
                addrow([zc(k, tau), zc(k, 1)], [1, -1], -1, 0);          % z0 = 1
            else
                addrow([zc(k, tau), zc(k, t), zc(k, t - 1)], [1, -1, 1], 0, 1);
            end
        end
    end
end
R = cfg.mp.ramp_frac * abs(info.pg_init(dg)) / base;
if usecurt
    dc = reshape(iD, nd, T);
    for t = 1:T
        for j = 1:nd
            addrow([pc(dg(j), t), dc(j, t)], [1, 1], info.pg_init(dg(j)) / base, inf);
        end
    end
end
for t = 1:T
    for j = 1:numel(dg)
        g = dg(j);
        if t == 1
            addrow(pc(g, 1), 1, info.pg_init(g) / base - R(j), info.pg_init(g) / base + R(j));
        else
            addrow([pc(g, t), pc(g, t - 1)], [1, -1], -R(j), R(j));
        end
    end
end
for t = 1:T                                           % v1.0-b: tap moves per period, n(.,0) = 0
    for j = 1:ntp
        if t == 1
            addrow(tc(j, 1), 1, -cfg.mp.tap_move_max, cfg.mp.tap_move_max);
        else
            addrow([tc(j, t), tc(j, t - 1)], [1, -1], -cfg.mp.tap_move_max, cfg.mp.tap_move_max);
        end
    end
end
Acp = sparse(I, J, V, r, nv);
P = struct('A', [A; Acp], 'lhs', [lhs; cl], 'rhs', [rhs; cu], 'obj', obj, 'Qd', Qd, ...
    'objcon', objcon, 'lb', lb, 'ub', ub, 'vtype', vtype);
P.params = struct('RelGap', cfg.mp.rel_gap);
isqp = isfield(info, 'fix_z_all_on') && info.fix_z_all_on;
if ispwl && ~isempty(cfg.mp.lp_method) && isfield(env.copt.params_ok, 'LpMethod') && env.copt.params_ok.LpMethod
    P.params.LpMethod = cfg.mp.lp_method;              % barrier for the large LP (continuous stage and MILP root)
end
if ~isqp
    P.params.Presolve = cfg.mp.miqp_presolve;          % MIP presolve misjudges this model as infeasible
    if isfield(env.copt, 'params_ok') && isfield(env.copt.params_ok, 'CutLevel') && env.copt.params_ok.CutLevel ...
            && ~isempty(cfg.mp.cut_level) && ~ispwl
        P.params.CutLevel = cfg.mp.cut_level;
    end
    if isfield(info, 'start') && numel(info.start) == nv
        P.start = info.start;
    end
end

kind = ternary(ispwl, ternary(isqp, 'LP (all candidates in service)', 'MILP'), ternary(isqp, 'QP (all candidates in service)', 'MIQP'));
fprintf(['\n--- Multi-period %s: %d periods, %d vars (%d binary + %d general integer), %d rows (%d coupling), ', ...
    'nnz(A)=%d | MIP start: %d ---\n'], kind, T, nv, sum(vtype == 'B'), sum(vtype == 'I'), size(P.A, 1), r, nnz(P.A), ...
    isfield(P, 'start') && env.copt.start_ok);
S0kind = kind; %#ok<NASGU>
tb = tic;
cfg2 = cfg;
cfg2.copt.time_limit = cfg.mp.time_limit;
sol = dali_copt_call(P, env, cfg2, 1);
S = struct();
S.solve_time_s = toc(tb);
S.status = sol.status; S.ok = sol.ok; S.objval = sol.objval; S.bestgap = sol.bestgap;
S.nodecnt = sol.nodecnt; S.retry = sol.retry; S.nvars = nv; S.nbin = sum(vtype == 'B');
S.nrows = size(P.A, 1); S.ncoupling = r; S.nint = sum(vtype == 'I'); S.ntap = zeros(ntp, T); S.tap_moves = NaN;
S.z = nan(nc, T); S.actions = NaN; S.pg = nan(ng, T); S.loss_proxy = nan(1, T); S.viol_proxy = nan(1, T);
S.dV = cell(1, T); S.max_row_viol = nan(1, T); S.x = [];
if ~sol.ok
    fprintf(2, 'Multi-period MIQP: no solution (%s)\n', sol.status);
    return;
end
x = sol.x;
S.x = x;
S.z = reshape(x(zc(:)), nc, T);
S.actions = sum(x(iY));
if ntp > 0
    S.ntap = round(reshape(x(tc(:)), ntp, T));
    S.tap_moves = sum(sum(abs(diff([zeros(ntp, 1), S.ntap], 1, 2))));
end
for t = 1:T
    b = blocks{t};
    xt = x(off(t) + (1:b.nv0));                        % original block variables (PWL helpers excluded)
    S.pg(:, t) = xt(b.idx.iPg) * base;
    on = true(b.nl, 1); on(b.cand(S.z(:, t) < 0.5)) = false;
    pf = xt(b.idx.iPf); qf = xt(b.idx.iQf);
    S.loss_proxy(t) = base * sum(on .* b.w .* (pf.^2 + (qf + b.cch).^2));
    S.viol_proxy(t) = sum(xt(b.idx.iSp)) + sum(xt(b.idx.iSm));
    S.dV{t} = xt(b.idx.iV);
    ax = b.A0 * xt;
    S.max_row_viol(t) = max([0; b.lhs0 - ax; ax - b.rhs0]);
end
ax = Acp * x;
S.max_coupling_viol = max([0; cl - ax; ax - cu]);
fprintf('  multi-period MIQP: status=%s, %.2f s, obj %.4f, gap %g, nodes %g, actions %.0f | own max row viol: periods %.1e, coupling %.1e\n', ...
    S.status, S.solve_time_s, S.objval, S.bestgap, S.nodecnt, S.actions, max(S.max_row_viol), S.max_coupling_viol);
end

function s = ternary(c, a, b)
if c, s = a; else, s = b; end
end

function [b, nsel] = pwl_block(b, cfg)
% Replace the block's diagonal quadratic loss terms q_i*x_i^2 (x = from-end P/Q flows) by
%   - outer tangent approximation u_i >= 2a x_i - a^2 (a from a grid around the base flow, plus a = 0)
%     for candidates and the flows carrying cfg.mp.pwl_cover of the loss curvature;
%   - first-order expansion x^2 ~ 2 x0 x - x0^2 for the remaining (always-on) flows.
% Linear terms of the block objective (charging shift, z constants) are kept unchanged, so an opened
% candidate (x = 0, z = 0) still has zero loss (the a = 0 tangent is included).
P = b.P; nv0 = b.nv;
qdiag = full(diag(P.Qd));
vars = [b.idx.iPf(:); b.idx.iQf(:)];
x0 = [real(b.Sf0(:)); imag(b.Sf0(:))];
wq = qdiag(vars);
isc = false(b.nl, 1); isc(b.cand) = true; iscv = [isc; isc];
contrib = wq .* x0.^2;
[~, o] = sort(contrib, 'descend');
cum = cumsum(contrib(o)) / max(sum(contrib), eps);
ntop = find(cum >= cfg.mp.pwl_cover, 1);
if isempty(ntop), ntop = numel(o); end
selv = false(size(vars)); selv(o(1:ntop)) = true;
selv = (selv | iscv) & wq > 0;
linv = ~selv & wq > 0;
obj = P.obj(:); objcon = P.objcon;
obj(vars(linv)) = obj(vars(linv)) + 2 * wq(linv) .* x0(linv);
objcon = objcon - sum(wq(linv) .* x0(linv).^2);
sv = find(selv); nsel = numel(sv);
g = cfg.mp.pwl_grid(:).';
nt = numel(g) + 1;
I = zeros(2 * nt * nsel, 1); J = I; V = I; rh = zeros(nt * nsel, 1); rr = 0; e = 0;
for j = 1:nsel
    i = sv(j);
    d = max(cfg.mp.pwl_rel * abs(x0(i)), cfg.mp.pwl_abs);
    a = [x0(i) + d * g, 0];
    for m = 1:nt
        rr = rr + 1;
        e = e + 1; I(e) = rr; J(e) = vars(i); V(e) = 2 * a(m);
        e = e + 1; I(e) = rr; J(e) = nv0 + j;  V(e) = -1;
        rh(rr) = a(m)^2;
    end
end
Atan = sparse(I(1:e), J(1:e), V(1:e), rr, nv0 + nsel);
P.A = [[P.A, sparse(size(P.A, 1), nsel)]; Atan];
P.lhs = [P.lhs(:); -inf(rr, 1)];
P.rhs = [P.rhs(:); rh(1:rr)];
P.obj = [obj; wq(sv)];
P.objcon = objcon;
P.Qd = sparse(nv0 + nsel, nv0 + nsel);
P.lb = [P.lb(:); zeros(nsel, 1)];
P.ub = [P.ub(:); inf(nsel, 1)];
P.vtype = [P.vtype(:).', repmat('C', 1, nsel)];
b.P = P; b.nv = nv0 + nsel; b.nv0 = nv0;
end
