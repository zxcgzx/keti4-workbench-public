# Mechanically derive dali_mp_build_period.m from dali_ots_copt.m (keep the two proxy models identical)
src=open('dali_ots_copt.m',encoding='utf-8').read().split('\n')
i_n=[i for i,l in enumerate(src) if l.strip()=="if nargin < 10, verbose = true; end"][0]
i_s=[i for i,l in enumerate(src) if l.startswith("sol = dali_copt_call(P, env, cfg, double(verbose));")][0]
i_u=[i for i,l in enumerate(src) if l.startswith("function a = uf_root")][0]
body='\n'.join(src[i_n+1:i_s]); sub='\n'.join(src[i_u:])
header='''function M = dali_mp_build_period(res0, opfset, meta, cfg, vpen, dt, verbose)
%DALI_MP_BUILD_PERIOD  多时段模型的单时段块。
%   与 dali_ots_copt 的代理模型逐行相同（线性化 AC、近零阻抗超节点、Big-M 开断、额定值八边形、
%   电压软约束、每时段开断数上限），区别只有三点：只建模不求解；目标乘以时段长度 dt（h）；
%   开断动作成本不在块内计（由 dali_mp_solve 中的动作变量计）。返回模型 P 与变量索引。
%   本文件由 gen_mp_builder.py 从 dali_ots_copt.m 机械截取生成，勿手工修改。
define_constants;
zmode = 'miqp'; zfix = []; nogood = {}; %#ok<NASGU>
cfg.ots.switch_cost = 0;
if nargin < 7, verbose = false; end
'''
a="P = struct('A', A, 'lhs', lhs, 'rhs', rhs, 'obj', c, 'Qd', spdiags(qd, 0, nv, nv), ...\n    'objcon', objcon,"
assert body.count(a)==1
body=body.replace(a,"P = struct('A', A, 'lhs', lhs, 'rhs', rhs, 'obj', dt * c, 'Qd', spdiags(dt * qd, 0, nv, nv), ...\n    'objcon', dt * objcon,")
b="fprintf('  COPT model [%s]: %d vars (%d binary), %d rows, nnz(A)=%d\\n', zmode, nv, ..."
assert body.count(b)==1
body=body.replace(b,"fprintf('  period block: %d vars (%d binary), %d rows, nnz(A)=%d\\n', nv, ...")
tail='''
M = struct();
M.P = P; M.nv = nv; M.base = base; M.nb = nb; M.ng = ng; M.nl = nl; M.nc = nc;
M.idx = struct('iTh', iTh, 'iV', iV, 'iPg', iPg, 'iQg', iQg, 'iPf', iPf, 'iQf', iQf, ...
    'iPt', iPt, 'iQt', iQt, 'iZ', iZ, 'iSp', iSp, 'iSm', iSm, 'iN', iN);
M.cand = cand; M.w = w; M.cch = cch; M.on0 = on0; M.sidx = sidx; M.nsn = nsn;
M.vm0 = vm0; M.va0 = va0; M.Pg0 = gen(:, PG); M.Qg0 = gen(:, QG); M.gon = gon; M.chk = chk;
M.A0 = A0; M.lhs0 = lhs0; M.rhs0 = rhs0; M.Sf0 = Sf0; M.nv0 = nv;
M.tapk = tapk; M.tau0 = tau0; M.tapstep = tstep;
end
'''
open('dali_mp_build_period.m','w',encoding='utf-8').write(header+body+tail+'\n'+sub+'\n')
print('dali_mp_build_period.m regenerated')
