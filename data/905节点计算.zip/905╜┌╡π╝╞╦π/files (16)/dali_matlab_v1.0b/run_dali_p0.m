function run_dali_p0(varargin)
%RUN_DALI_P0  课题4 Baseline V1 / P0 一键运行：
%   STEP0 环境 → STEP1 读TXT/拓扑审计/建算例 → STEP2 ACPF复现 →
%   [对每个电压惩罚权重] STEP3 固定拓扑AC-OPF → STEP4 COPT代理OTS → STEP5 MATPOWER AC校核
%   → (主权重) 逐条开断独立参考 → 汇总CSV/摘要/日志。
%   所有输出在 cfg.outdir（默认自动命名 out_P0_<电压口径>_n1screen<0/1>）。出错时完整报错也会写入日志。
%   可用“字段路径, 值”临时覆盖配置，例如：
%       run_dali_p0('vlim.opf_source', 'taskbook_proxy')
%       run_dali_p0('ots.require_n1_connectivity', false, 'run_enum_reference', false)

here = fileparts(mfilename('fullpath'));
addpath(here);
cfg = dali_p0_config();
if mod(numel(varargin), 2) ~= 0
    error('dali:main', 'Overrides must be name/value pairs, e.g. run_dali_p0(''vlim.opf_source'',''taskbook_proxy'')');
end
for i = 1:2:numel(varargin)
    fpath = strsplit(varargin{i}, '.');
    cfg = setfield(cfg, fpath{:}, varargin{i+1}); %#ok<SFLD>
end
if isempty(cfg.outdir)
    cfg.outdir = fullfile(here, sprintf('out_P0_%s_n1screen%d', cfg.vlim.opf_source, cfg.ots.require_n1_connectivity));
end
if ~exist(cfg.outdir, 'dir'), mkdir(cfg.outdir); end
stamp = datestr(now, 'yyyymmdd_HHMMSS');
logf = fullfile(cfg.outdir, ['P0_log_' stamp '.txt']);
diary(logf);
cleaner = onCleanup(@() diary('off')); %#ok<NASGU>
fprintf('Dali Baseline V1 / P0 run %s (package v1.0-b)\n', stamp);
for i = 1:2:numel(varargin)
    fprintf('  override: %s = %s\n', varargin{i}, mat2str(varargin{i+1}));
end
fprintf('  output folder: %s\n', cfg.outdir);
try
    main_body(cfg, stamp, logf);
catch err
    fprintf(2, '\n*** RUN FAILED ***\n%s\n', getReport(err, 'extended', 'hyperlinks', 'off'));
    fprintf('\nPlease upload the log file: %s\n', logf);
end
end

%% =======================================================================
function main_body(cfg, stamp, logf)
out = cfg.outdir;
T = struct();

tt = tic; env = dali_p0_step0_env(cfg); T.step0_env_s = toc(tt);
if ~env.matpower_ok
    error('dali:main', 'MATPOWER >= 7 not available. Fix STEP 0 first.');
end
define_constants;

%% ---------------- STEP 1 ----------------
tt = tic; raw = dali_read_pasexp(cfg.txtfile); T.step1_read_s = toc(tt);
if ~strcmpi(raw.sha256, cfg.expected_sha256)
    fprintf(2, 'WARNING: SHA-256 differs from the audited file (%s).\n', cfg.expected_sha256);
end
tt = tic; topo = dali_topology_audit(raw, cfg); T.step1_topology_s = toc(tt);
writetable(struct2table(topo.checks), fullfile(out, 'topology_check.csv'));
tt = tic; [mpc, mpc_raw, meta, rev, calib] = dali_build_case(raw, topo, cfg); T.step1_build_s = toc(tt);
savecase(fullfile(out, 'case905_baseline_v1.m'), mpc);
savecase(fullfile(out, 'case905_raw.m'), mpc_raw);
writetable(struct2table(rev), fullfile(out, 'revision_log.csv'));
writetable(struct2table(calib), fullfile(out, 'branch_calibration.csv'));
writetable(struct2table(candidate_table(raw, topo, meta, mpc)), fullfile(out, 'candidate_whitelist.csv'));

%% ---------------- STEP 2: ACPF ----------------
fprintf('\n===== STEP 2: ACPF on equivalent_v1 =====\n');
tt = tic;
[pf0, pfi] = dali_run_acpf(mpc, meta, 'equivalent_v1', false, true);
[~, pfi_flat] = dali_run_acpf(mpc, meta, 'equivalent_v1', true, true);
T.step2_acpf_s = toc(tt);
if cfg.run_raw_pf
    dali_run_acpf(mpc_raw, meta, 'raw_literal_contrast', false, false);
end
if ~pf0.success
    error('dali:main', 'ACPF on equivalent_v1 did not converge; stop before OPF/OTS.');
end

%% ---------------- STEPS 3-5 for each weight ----------------
rows = [];
otsrows = [];
n1rows = [];
ind = [];
enum_tab = []; enum_sum = [];
for iv = 1:numel(cfg.obj.vpen_list)
    vpen = cfg.obj.vpen_list(iv);
    tag = sprintf('v%g', vpen);
    fprintf('\n#################### weight case %s (c_loss=%g $/MWh, vpen=%g $/pu) ####################\n', ...
        tag, cfg.obj.c_loss, vpen);
    [mpo, opfset, permtab] = dali_setup_opf(mpc, pf0, meta, cfg, vpen, []);
    if iv == 1
        writetable(struct2table(permtab), fullfile(out, 'gen_permission_trial.csv'));
    end
    E0 = dali_eval_ac(pf0, meta, cfg, vpen, [tag '_S0_snapshot_ACPF'], opfset);
    rows = append_row(rows, E0);

    fprintf('\n===== STEP 3 [%s]: fixed-topology AC-OPF =====\n', tag);
    tt = tic;
    [r1, i1] = dali_run_acopf(mpo, opfset, cfg, env, [tag ' S1 fixed topology']);
    T.(matlab.lang.makeValidName(sprintf('step3_opf_%s_s', tag))) = toc(tt);
    E1 = dali_eval_ac(r1, meta, cfg, vpen, [tag '_S1_fixed_topology_ACOPF'], opfset);
    rows = append_row(rows, E1);
    print_eval(E0); print_eval(E1);
    if iv == 1 && (cfg.n1.run || cfg.cpf.run)
        fprintf('\n===== Indicators 4.2 [%s]: static N-1 (kV >= %g) + CPF =====\n', tag, cfg.n1.kv_min);
        tt = tic;
        [ind, n1rows] = add_scenario(ind, n1rows, mpc, pf0, [], opfset, meta, cfg, [tag '_S0_snapshot'], E0);
        if i1.success
            [ind, n1rows] = add_scenario(ind, n1rows, mpc, r1, [], opfset, meta, cfg, [tag '_S1_fixed_topology'], E1);
        end
        T.ind42_S0_S1_s = toc(tt);
    end
    if ~i1.success
        fprintf(2, 'S1 AC-OPF failed for %s: OTS skipped for this weight.\n', tag);
        continue;
    end
    if ~env.copt.ok
        fprintf(2, 'COPT unavailable: OTS skipped.\n');
        continue;
    end

    fprintf('\n===== STEP 4 [%s]: COPT proxy OTS =====\n', tag);
    tt = tic;
    ots = dali_ots_run(r1, opfset, meta, cfg, env, vpen);
    T.(matlab.lang.makeValidName(sprintf('step4_copt_%s_s', tag))) = toc(tt);
    ots.S1_J_AC = E1.J_AC;
    ots.S2_J_AC = NaN; ots.S2a_J_AC = NaN;
    ots.ac_dJ = NaN; ots.ac_dLoss_MW = NaN; ots.ac_dViol_pu = NaN;
    ots.S2_converged = NaN;
    ots.ac_verdict = 'NOT_RUN';

    fprintf('\n===== STEP 5 [%s]: MATPOWER AC check of the COPT topology =====\n', tag);
    tt = tic;
    if ots.ok && ~isempty(ots.open_rows)
        m2a = dali_pf_case_from_state(mpc, r1, meta, ots.open_rows);
        [r2a, ~] = dali_run_acpf(m2a, meta, [tag ' S2a OTS topology + S1 controls'], false, false);
        E2a = dali_eval_ac(r2a, meta, cfg, vpen, [tag '_S2a_OTS_topology_S1_controls_ACPF'], opfset);
        rows = append_row(rows, E2a);
        [mpo2, opfset2] = dali_setup_opf(mpc, r1, meta, cfg, vpen, ots.open_rows);
        [r2, ~] = dali_run_acopf(mpo2, opfset2, cfg, env, [tag ' S2 OTS topology']);
        E2 = dali_eval_ac(r2, meta, cfg, vpen, [tag '_S2_OTS_topology_ACOPF'], opfset2);
        rows = append_row(rows, E2);
        print_eval(E2a); print_eval(E2);
        if iv == 1 && (cfg.n1.run || cfg.cpf.run) && E2.converged
            tn = tic;   % separate timer so STEP 5 timing stays correct
            [ind, n1rows] = add_scenario(ind, n1rows, mpc, r2, ots.open_rows, opfset2, meta, cfg, [tag '_S2_OTS_topology'], E2);
            T.ind42_S2_s = toc(tn);
        end
        ots.S2a_J_AC = E2a.J_AC;
        ots.S2_J_AC = E2.J_AC;
        ots.S2_converged = E2.converged;
        ots.ac_dJ = E2.J_AC - E1.J_AC;
        ots.ac_dLoss_MW = E2.loss_MW - E1.loss_MW;
        ots.ac_dViol_pu = E2.sum_v_viol_opf_scope - E1.sum_v_viol_opf_scope;
        if ~E2.converged
            ots.ac_verdict = 'AC_OPF_FAILED_ON_OTS_TOPOLOGY';
        elseif ots.ac_dJ < -1e-3
            ots.ac_verdict = 'AC_IMPROVEMENT_CONFIRMED';
        else
            ots.ac_verdict = 'NO_AC_IMPROVEMENT';
        end
    elseif ots.ok
        E2 = E1;
        E2.label = [tag '_S2_zero_opening_equals_S1'];
        rows = append_row(rows, E2);
        ots.S2_J_AC = E1.J_AC; ots.S2_converged = E1.converged;
        ots.ac_dJ = 0; ots.ac_dLoss_MW = 0; ots.ac_dViol_pu = 0;
        ots.ac_verdict = 'ZERO_OPENING_IN_PROXY';
    else
        ots.ac_verdict = 'COPT_NO_SOLUTION';
    end
    T.(matlab.lang.makeValidName(sprintf('step5_check_%s_s', tag))) = toc(tt);
    fprintf('  => [%s] COPT: %s | AC verdict: %s | dJ_AC=%.4f $ dLoss=%.4f MW dViol=%.5f pu\n', ...
        tag, ots.open_desc, ots.ac_verdict, ots.ac_dJ, ots.ac_dLoss_MW, ots.ac_dViol_pu);
    otsrows = append_row(otsrows, rmfield(ots, 'open_rows'));

    if iv == 1 && cfg.run_enum_reference
        tt = tic;
        [enum_tab, enum_sum] = dali_ots_enum_reference(mpc, r1, E1, opfset, meta, cfg, env, vpen, ots.open_rows);
        T.enum_reference_s = toc(tt);
        writetable(struct2table(enum_tab), fullfile(out, sprintf('ots_enum_reference_%s.csv', tag)));
    end
    if iv == 1
        save(fullfile(out, 'P0_primary_states.mat'), 'pf0', 'r1', 'mpo', 'opfset', '-v7');
    end
end

%% ---------------- outputs ----------------
writetable(struct2table(rows), fullfile(out, 'P0_compare.csv'));
if ~isempty(otsrows)
    writetable(struct2table(otsrows), fullfile(out, 'P0_ots_copt.csv'));
end
if ~isempty(n1rows)
    writetable(struct2table(n1rows), fullfile(out, 'P0_n1_summary.csv'));
end
if ~isempty(ind)
    writetable(struct2table(ind), fullfile(out, 'P0_indicators_42.csv'));
    fprintf('\n===== Task-book indicator 4.2 sheet (vpen = %g, V limits: %s) =====\n', cfg.obj.vpen_list(1), cfg.vlim.opf_source);
    disp(struct2table(ind));
end
save(fullfile(out, 'P0_workspace.mat'), 'cfg', 'env', 'topo', 'meta', 'rev', 'calib', 'pfi', ...
    'pfi_flat', 'rows', 'otsrows', 'enum_tab', 'enum_sum', 'n1rows', 'ind', 'T', '-v7');
write_summary(fullfile(out, ['P0_summary_' stamp '.txt']), cfg, env, raw, topo, pfi, pfi_flat, ...
    rows, otsrows, enum_sum, T, logf, n1rows, ind);
fprintf('\nTimings (s):\n'); disp(T);
fprintf('\n===== DONE. Upload the folder %s (or at least P0_log_*, P0_summary_*, *.csv) =====\n', out);
end

%% =======================================================================
function S = append_row(S, r)
if isempty(S)
    S = r;
else
    S(end+1) = r;
end
end

function print_eval(E)
fprintf(['  [%s] conv=%d loss=%.3f MW | V viol: over %g under %g sum %.4f pu (opf scope %.4f) max over %.4f | ', ...
    'tb 110/35kV qualified %.2f%% | line P load max %.2f%% mean %.2f%% | J_AC=%.4f | %s\n'], E.label, ...
    E.converged, E.loss_MW, E.n_v_over, E.n_v_under, E.sum_v_viol, E.sum_v_viol_opf_scope, E.max_v_over, ...
    E.tb_vq_rate_110_35kV_pct, E.lineP_max_pct, E.lineP_mean_pct, E.J_AC, E.status);
fprintf('      file-limit violations by level: 500kV %g | 220kV %g | 110kV %g | 35kV %g | 10kV %g | 6kV %g | opf-scope sum %.4f pu\n', ...
    E.nviol_500kV, E.nviol_220kV, E.nviol_110kV, E.nviol_35kV, E.nviol_10kV, E.nviol_6kV, E.sum_v_viol_opf_scope);
end

function C = candidate_table(raw, topo, meta, mpc)
define_constants;
rows = sort([find(topo.cand_default); meta.forbidden_rows(:)]);
n = numel(rows);
Sf = meta.exp_Sf(rows); St = meta.exp_St(rows);
f = meta.f(rows); t = meta.t(rows);
kv = meta.base_kv(f);
If_A = abs(Sf) * 1000 ./ (sqrt(3) * meta.snap_vm(f) .* kv);
It_A = abs(St) * 1000 ./ (sqrt(3) * meta.snap_vm(t) .* meta.base_kv(t));
C = struct();
C.branch_row = rows;
C.source_line = raw.branch_line(rows);
C.from_bus = meta.ids(f); C.to_bus = meta.ids(t); C.kV = kv;
C.parallel_group_rows = topo.group_members(rows);
C.R_used = mpc.branch(rows, BR_R); C.X_used = mpc.branch(rows, BR_X); C.B_total_used = mpc.branch(rows, BR_B);
C.RATE_A_src = meta.rateA_src(rows);
C.rate_MVA_if_A = meta.rate_MVA_if_A(rows);
C.snap_P_load_pct_if_A = 100 * max(abs(real(Sf)), abs(real(St))) ./ meta.rate_MVA_if_A(rows);
C.snap_I_load_pct_if_A = 100 * max(If_A, It_A) ./ meta.rateA_src(rows);
C.snap_S_load_pct_if_MVA = 100 * max(abs(Sf), abs(St)) ./ meta.rateA_src(rows);
st = repmat({'PRELIMINARY_CANDIDATE'}, n, 1);
st(ismember(rows, meta.forbidden_rows)) = {'FORBIDDEN_175_176'};
st(~ismember(rows, meta.cand_rows) & ~ismember(rows, meta.forbidden_rows)) = {'EXCLUDED_BY_N1_CONNECTIVITY_OR_USER'};
C.P0_status = st;
C.used_in_P0 = double(ismember(rows, meta.cand_rows));
C.n1_connectivity_ok = double(topo.n1ok(rows));
C.n1_new_bridges_if_opened = topo.newbr(rows);
C.engineering_operability = repmat({'NOT_VERIFIED'}, n, 1);
end

function write_summary(fname, cfg, env, raw, topo, pfi, pfi_flat, rows, otsrows, enum_sum, T, logf, n1rows, ind)
fid = fopen(fname, 'w');
if fid < 0, return; end
c = onCleanup(@() fclose(fid));
p = @(varargin) fprintf(fid, varargin{:});
p('Dali Baseline V1 / P0 summary\n');
p('Log: %s\n', logf);
p('MATLAB %s | MATPOWER %s | IPOPT %d | COPT ok %d (rowfmt %s, qmult %g)\n', env.matlab, ...
    env.matpower_version, env.has_ipopt, env.copt.ok, env.copt.rowfmt, env.copt.qmult);
p('Input %s sha256 %s\n', raw.file, raw.sha256);
p('Topology checks all PASS: %d | N-1 connectivity screen: %d | candidates used: %s\n', topo.allpass, ...
    cfg.ots.require_n1_connectivity, dali_rows2str(topo.cand_rows));
p('Voltage limits used in OPF/COPT: %s\n', cfg.vlim.opf_source);
p('Assumptions: VA=%s, B x%g, impedance=%s, Q-eq=%s(thr %.3g Mvar), RATE_A unit=%s, P=%s, Q=%s, boundary V fixed=%d\n', ...
    cfg.conv.va_unit, cfg.conv.b_factor, cfg.conv.imp_policy, cfg.qeq.mode, cfg.qeq.threshold_Mvar, ...
    cfg.rate.unit, cfg.gen.p_policy, cfg.gen.q_policy, cfg.boundary.fix_voltage);
p('\nACPF reproduction: success %d (flat start %d), max|dVM| %.5f pu, #|dVM|>0.005: %d, #branch S_err>1MVA: %d\n', ...
    pfi.success, pfi_flat.success, getf(pfi, 'max_abs_dVM'), getf(pfi, 'n_dVM_gt_0p005'), getf(pfi, 'n_branch_Serr_gt_1MVA'));
p('\n%-48s %5s %9s %6s %6s %9s %9s %8s %8s %10s  %s\n', 'scenario', 'conv', 'loss_MW', 'nVover', 'nVund', ...
    'sumViol', 'violOPF', 'tbVQ%', 'lineP%', 'J_AC', 'status');
for i = 1:numel(rows)
    r = rows(i);
    p('%-48s %5d %9.3f %6g %6g %9.4f %9.4f %8.2f %8.2f %10.4f  %s %s\n', r.label, r.converged, r.loss_MW, ...
        r.n_v_over, r.n_v_under, r.sum_v_viol, r.sum_v_viol_opf_scope, r.tb_vq_rate_110_35kV_pct, ...
        r.lineP_max_pct, r.J_AC, r.status, r.open_rows);
end
p('\nFile-limit violating buses by level (500/220/110/35/10/6 kV):\n');
for i = 1:numel(rows)
    r = rows(i);
    p('  %-48s %4g %4g %4g %4g %4g %4g\n', r.label, r.nviol_500kV, r.nviol_220kV, r.nviol_110kV, ...
        r.nviol_35kV, r.nviol_10kV, r.nviol_6kV);
end
p('\nCOPT proxy OTS:\n');
for i = 1:numel(otsrows)
    o = otsrows(i);
    p(['  vpen %g: status %s, %.2f s, %d vars/%d bin/%d rows, gap %g | selected %s | proxy gain %.4f $ | ', ...
        'AC dJ %.4f $, dLoss %.4f MW, dViol %.5f pu -> %s | own max row viol %.1e (%s)\n'], o.vpen, o.miqp_status, ...
        o.miqp_time_s, o.nvars, o.nbin, o.nrows, o.miqp_bestgap, o.open_desc, o.proxy_gain_J, o.ac_dJ, ...
        o.ac_dLoss_MW, o.ac_dViol_pu, o.ac_verdict, o.miqp_max_row_viol, o.miqp_max_row_viol_block);
end
if ~isempty(enum_sum)
    p(['\nEnumeration reference (independent, not COPT): n=%d, Pearson dJ %.3f, Spearman dJ %.3f, ', ...
        'Pearson dLoss %.3f, sign agreement %.2f, best AC single opening row %g (dJ %.4f), #AC-improving %d\n'], ...
        enum_sum.n, enum_sum.pearson_dJ, enum_sum.spearman_dJ, enum_sum.pearson_dLoss, enum_sum.sign_agree_dJ, ...
        enum_sum.best_AC_row, enum_sum.best_AC_dJ, enum_sum.n_AC_improving);
end
if ~isempty(n1rows)
    p('\nStatic N-1 (kV >= %g, %s; bridges counted in denominator: %d; generator Q limits enforced: %d):\n', ...
        cfg.n1.kv_min, strjoin(cfg.n1.types, '+'), cfg.n1.count_bridges, cfg.n1.enforce_q_lims);
    for i = 1:numel(n1rows)
        q = n1rows(i);
        p(['  %-28s cont %3d conv %3d | strict %3g (%.1f%%) incremental %3g (%.1f%%) emergency %3g (%.1f%%) | ', ...
            'fail OV %g, V %g (>0.01pu %g), nonconv %g | N-0 Vviol %g, outside emerg %g, OV %g | islanding %d ', ...
            '(max lost load %.1f MW) | OV culprits: %s\n'], q.label, q.n_contingencies, q.n_converged, ...
            q.n_pass_strict, q.pass_rate_strict_pct, q.n_pass_incremental, q.pass_rate_incremental_pct, ...
            q.n_pass_emergency, q.pass_rate_emergency_pct, q.n_fail_overload, q.n_fail_voltage, ...
            q.n_fail_voltage_gt_0p01, q.n_fail_nonconv, q.ref_n_vviol, q.ref_n_outside_emerg, q.ref_n_overload, ...
            q.n_islanding_elements, q.max_island_lost_load_MW, q.overload_culprits);
    end
end
if ~isempty(ind)
    p('\nTask-book indicator 4.2 sheet (vpen %g, V limits %s):\n', cfg.obj.vpen_list(1), cfg.vlim.opf_source);
    p('  %-26s %8s %8s %8s %7s %7s %8s %8s %8s %9s\n', 'scenario', 'N1incr%', 'N1emer%', 'lineMax%', 'I_LR', ...
        'Vq%', 'I_VD', 'CPF%', 'loss_MW', 'lossRate%');
    for i = 1:numel(ind)
        q = ind(i);
        p('  %-26s %8.1f %8.1f %8.2f %7.4f %7.2f %8.4f %8.1f %8.3f %9.3f\n', q.scenario, q.n1_pass_incremental_pct, ...
            q.n1_pass_emergency_pct, q.line_load_max_pct, q.I_LR, q.voltage_qualified_110_35kV_pct, q.I_VD, ...
            q.cpf_margin_pct, q.loss_MW, q.loss_rate_le110kV_load_pct);
    end
    p('  renewable accommodation / generation cost: NOT_COMPUTABLE (no availability or cost data)\n');
end
p('\nTimings (s):\n');
fn = fieldnames(T);
for i = 1:numel(fn), p('  %-28s %8.2f\n', fn{i}, T.(fn{i})); end
p(['\nScope: single snapshot; proxy optimum is optimal only within the linearised-AC proxy and the ', ...
    'candidate set (not an AC-OTS global certificate). N-1, CPF, renewable curtailment and real ', ...
    'generation cost are NOT_COMPUTABLE. All data revisions are unconfirmed assumptions.\n']);
end

function v = getf(s, name)
if isfield(s, name), v = s.(name); else, v = NaN; end
end

function [ind, n1rows] = add_scenario(ind, n1rows, mpc, state, open_rows, opfset, meta, cfg, label, E)
N = []; C = [];
if cfg.n1.run
    N = dali_n1_check(mpc, state, open_rows, opfset, meta, cfg, label);
    n1rows = append_row(n1rows, N);
end
if cfg.cpf.run
    C = dali_cpf_margin(mpc, state, open_rows, opfset, meta, cfg, label);
end
ind = append_row(ind, dali_indicator_row(label, E, N, C));
end
