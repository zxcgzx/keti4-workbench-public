function run_dali_mp_acots(varargin)
%RUN_DALI_MP_ACOTS  16 时段“完整 AC-OTS + 机组出力 + N-1”基准（Baseline，不追求时间）。
%   每个时段、每种拓扑（不开断 + 断开后不新增桥的单条开断）求一次完整非线性交流 OPF（MATPOWER MIPS），
%   同时调整可调机组有功（±20%，与平衡机同价，即最小化网损）与无功/电压；开关序列在时间方向用动态规划
%   精确求解（全程动作 <= mp.max_actions，动作后保持 >= mp.min_hold 个时段，与线性化多时段模型同一约束）；
%   N-1 采用懒校验：对 DP 最优路径上的拓扑做静态交流 N-1，不通过则剔除并重新规划，直到每个时段都通过。
%   分接头保持当前挡位（完整交流下的离散挡位是 MINLP，现有工具不解）。最后自动生成汇报 md。
%
%   例：run_dali_mp_acots
%       run_dali_mp_acots('mpac.cand_mode', 'nonbridge')   % 每时段 225 种拓扑（约 3600 次 OPF，数小时）

here = fileparts(mfilename('fullpath'));
addpath(here);
cfg = dali_p0_config();
cfg.vlim.opf_source = 'taskbook_proxy';
if mod(numel(varargin), 2) ~= 0
    error('dali:mpac', 'Overrides must be name/value pairs');
end
for i = 1:2:numel(varargin)
    fpath = strsplit(varargin{i}, '.');
    cfg = setfield(cfg, fpath{:}, varargin{i+1}); %#ok<SFLD>
end
if strcmpi(cfg.mpac.warm, 'file') && isempty(cfg.mpac.warm_file)
    cfg.mpac.warm_file = fullfile(here, sprintf('out_MPACOTS_T%d_%s_chain', cfg.mp.T, cfg.mpac.cand_mode), 'MPAC_solutions.mat');
end
if isempty(cfg.outdir)                                 % v1.3: one folder per experiment, runs do not overwrite each other
    tag = lower(cfg.mpac.warm);
    if strcmpi(tag, 'file'), tag = sprintf('file_s%d', cfg.mpac.warm_shift); end
    if cfg.mp.load_shift ~= 0, tag = sprintf('%s_ls%d', tag, cfg.mp.load_shift); end
    if cfg.mp.load_scale ~= 1, tag = sprintf('%s_x%g', tag, cfg.mp.load_scale); end
    if cfg.mp.disp_range == 0, tag = [tag '_nodisp']; end
    if cfg.par.workers > 0, tag = sprintf('%s_par%d', tag, cfg.par.workers); end
    cfg.outdir = fullfile(here, sprintf('out_MPACOTS_T%d_%s_%s', cfg.mp.T, cfg.mpac.cand_mode, tag));
end
if ~exist(cfg.outdir, 'dir'), mkdir(cfg.outdir); end
stamp = datestr(now, 'yyyymmdd_HHMMSS');
logf = fullfile(cfg.outdir, ['MPAC_log_' stamp '.txt']);
diary(logf);
cleaner = onCleanup(@() diary('off')); %#ok<NASGU>
fprintf('Dali 16-period full AC-OTS baseline (AC-OPF per period x topology, DP over switching, lazy N-1) run %s (package v1.3)\n', stamp);
for i = 1:2:numel(varargin)
    fprintf('  override: %s = %s\n', varargin{i}, mat2str(varargin{i+1}));
end
try
    main_mpac(cfg);
catch err
    fprintf(2, '\n*** RUN FAILED ***\n%s\n', getReport(err, 'extended', 'hyperlinks', 'off'));
    fprintf('\nPlease upload the log file: %s\n', logf);
end
end

%% =======================================================================
function main_mpac(cfg)
define_constants;
Tm = struct();
dali_island_masks('reset');                            % v1.3: caches are rebuilt inside every run (fair timing)
Tm.pool_s = 0;                                         % v1.3: optional parallel pool (one-off start, reported separately)
if cfg.par.workers > 0
    tp = tic;
    if ~(license('test', 'Distrib_Computing_Toolbox') && ~isempty(ver('parallel')))
        fprintf(2, 'Parallel Computing Toolbox not available: running serially.\n');
        cfg.par.workers = 0;
    else
        pool = gcp('nocreate');
        if isempty(pool) || pool.NumWorkers ~= cfg.par.workers
            if ~isempty(pool), delete(pool); end
            parpool(cfg.par.workers);
        end
    end
    Tm.pool_s = toc(tp);
    fprintf('  parallel workers: %d (pool start %.1f s, not counted in the solve time)\n', cfg.par.workers, Tm.pool_s);
end
t_all = tic;
env = dali_p0_step0_env(cfg);
if ~env.matpower_ok, error('dali:mpac', 'MATPOWER >= 7 required'); end
raw = dali_read_pasexp(cfg.txtfile);
topo = dali_topology_audit(raw, cfg);
[mpc, ~, meta] = dali_build_case(raw, topo, cfg);
[pf0, ~] = dali_run_acpf(mpc, meta, 'equivalent_v1', false, false);
vpen = cfg.mp.vpen;
[mpo, opfset] = dali_setup_opf(mpc, pf0, meta, cfg, vpen, []);
[r1, i1] = dali_run_acopf(mpo, opfset, cfg, env, 'period-0 controls (S1)');
if ~i1.success, error('dali:mpac', 'S1 AC-OPF failed'); end
Tm.prep_s = toc(t_all);

%% ---------------- periods (same data as run_dali_mp) ----------------
T = cfg.mp.T; dt = cfg.mp.dt_h;
lam = (cfg.mp.load_start + (cfg.mp.load_end - cfg.mp.load_start) * ((0:T-1) + cfg.mp.load_shift) / (T - 1)) * ...
    cfg.mp.load_scale;                                 % v1.3: load_shift = next rolling window, load_scale = perturbed load
sel = mpc.bus(:, PD) > 0 & meta.base_kv <= cfg.mp.load_kv_max & ~meta.is_boundary;
gon = mpc.gen(:, GEN_STATUS) > 0;
dispg = gon & ~ismember(mpc.gen(:, GEN_BUS), cfg.boundary.buses) & meta.snap_gen_PG >= cfg.mp.disp_min_MW;
dispg(opfset.slackgen) = false;
pg_init = r1.gen(:, PG);
Rr = cfg.mp.ramp_frac * abs(pg_init);
lo_all = (1 - cfg.mp.disp_range) * pg_init; hi_all = (1 + cfg.mp.disp_range) * pg_init;
lo1 = max(lo_all, pg_init - Rr); hi1 = min(hi_all, pg_init + Rr);       % period 1 also respects the ramp from S1
m0 = mpc; m0.gen(:, QMIN) = opfset.qmin; m0.gen(:, QMAX) = opfset.qmax;
mpopt_pf = mpoption('pf.alg', 'NR', 'pf.tol', 1e-8, 'pf.nr.max_it', 30, 'verbose', 0, 'out.all', 0, 'pf.enforce_q_lims', 1);
cases = cell(1, T); bases = cell(1, T);
tb = tic;
for t = 1:T
    mt = m0;
    mt.bus(sel, PD) = mpc.bus(sel, PD) * lam(t);
    mt.bus(sel, QD) = mpc.bus(sel, QD) * lam(t);
    cases{t} = mt;
    rt = runpf(dali_pf_case_from_state(mt, r1, meta, []), mpopt_pf);
    if ~rt.success, error('dali:mpac', 'Base ACPF failed at period %d', t); end
    bases{t} = rt;
end
Tm.period_acpf_s = toc(tb);
fprintf('\n===== %d periods (load x%.3f -> x%.3f) | dispatchable units %d (%.1f MW, +-%.0f%%, ramp %.0f%%/period) | base PFs %.2f s =====\n', ...
    T, lam(1), lam(end), sum(dispg), sum(pg_init(dispg)), 100 * cfg.mp.disp_range, 100 * cfg.mp.ramp_frac, Tm.period_acpf_s);

%% ---------------- topology states ----------------
tsc = tic;
nb = size(mpc.bus, 1); nl = size(mpc.branch, 1);
on = mpc.branch(:, BR_STATUS) > 0;
isbr = dali_bridges(nb, meta.f, meta.t, on);
keep = on & ~isbr & ~topo.forbidden;
if strcmpi(cfg.mpac.cand_mode, 'n1safe')
    % v1.3: exact and fast. A branch that becomes a bridge after opening k shares a cycle with k, so it lies in k's
    % 2-edge-connected component; the bridge test therefore runs on that component only (same 14 candidates,
    % checked against the v1.2 screen on this network: 0.04 s instead of 16-20 s).
    nbe = find(on & ~isbr);
    G = graph(meta.f(nbe), meta.t(nbe), ones(numel(nbe), 1), nb);
    bins = conncomp(G);
    comp = bins(meta.f(nbe)).';
    for k = find(keep).'
        ce = nbe(comp == comp(nbe == k));
        [~, ~, ix] = unique([meta.f(ce); meta.t(ce)]);
        ne = numel(ce);
        m2 = true(ne, 1); m2(ce == k) = false;
        if any(dali_bridges(max(ix), ix(1:ne), ix(ne+1:end), m2) & m2), keep(k) = false; end
    end
end
cand = find(keep);
S = numel(cand) + 1;                                   % state 1 = no opening, state s = open cand(s-1)
Tm.topology_screen_s = toc(tsc);
fprintf('  topology states per period: %d (no opening + %d single openings, mode %s; screen %.2f s)\n', ...
    S, numel(cand), cfg.mpac.cand_mode, Tm.topology_screen_s);

%% ---------------- stage costs: full AC-OPF for every period x topology ----------------
fprintf('\n===== Stage costs: %d x %d = %d full AC-OPFs =====\n', T, S, T * S);
J = inf(T, S); Jloss = nan(T, S); Jviol = nan(T, S); Jvq = nan(T, S); topf = nan(T, S);
RES = cell(T, S); OPFS = cell(T, S); its = nan(T, S);
% v1.3: warm start (initial point of each OPF only; model, candidates, DP and N-1 criterion are unchanged)
WS = load_warm(cfg, cand, T);
s0 = 1;                                                % DP start topology (1 = all in service)
if WS.ok && cfg.mpac.warm_shift > 0 && ~isempty(WS.path) && cfg.mpac.warm_shift <= numel(WS.path)
    sp = WS.path(cfg.mpac.warm_shift);                 % plan of the previous window already executed
    if sp == 1, s0 = 1; else, s0 = find(cand == WS.cand(sp - 1), 1) + 1; end
    if isempty(s0), s0 = 1; end
    if all(isfinite(WS.PG(cfg.mpac.warm_shift, sp, :)))
        pg_init = reshape(WS.PG(cfg.mpac.warm_shift, sp, :), [], 1);   % ramp reference = executed dispatch
    end
end
fprintf('  warm start: %s\n', WS.label);
if WS.oracle
    fprintf(2, ['  *** ORACLE warm start: initial values = the final solution of this same instance. Use only as a ', ...
        'diagnostic lower bound; this is NOT an input-to-solution time for indicator 4.1. ***\n']);
end
Tm.opf_noopen_s = 0;
to = tic;
SB = cell(T, 1); RS = ones(nl, T); scinfo = struct('t', {}, 'iters', {}, 'rows', {}, 'emerg_pct', {}, 'time_s', {});
pg_prev = pg_init;
Tm.sc_s = 0; nn1_sc = 0;
for t = 1:T
    lo = max(lo_all, pg_prev - Rr); hi = min(hi_all, pg_prev + Rr);       % v1.2a: ramp from the previous period
    % --- preventive N-1 for the no-opening OPF: tighten the ratings of rows overloaded after contingencies ---
    tsc0 = tic; rs = ones(nl, 1); rs_ok = rs; tight = []; best = [];
    init0 = warm_init_noopen(cfg, WS, bases, RES, r1, t);
    for q = 1:cfg.mpac.sc_iters
        [rm0, opfs0, E0t, ts0, it0] = solve_period_opf(cases{t}, init0, meta, cfg, vpen, [], dispg, lo, hi, rs);
        Tm.opf_noopen_s = Tm.opf_noopen_s + ts0;
        if ~E0t.converged
            if isempty(best), error('dali:mpac', 'No-opening AC-OPF failed at period %d without tightening', t); end
            fprintf('    t%02d preventive N-1 iteration %d: AC-OPF infeasible with the tightened limits -> back off halfway\n', t, q);
            rs = 0.5 * (rs + rs_ok);                    % v1.2c: back off towards the last feasible limits
            continue;
        end
        S0t = dali_n1_check(cases{t}, rm0, [], opfs0, meta, cfg, sprintf('MPAC_t%02d_no_opening_sc%d', t, q));
        nn1_sc = nn1_sc + 1;
        if isempty(best) || S0t.pass_rate_emergency_pct > best.S.pass_rate_emergency_pct + 1e-9
            best = struct('S', S0t, 'rs', rs, 'q', q, 'rm', rm0, 'opfs', opfs0, 'E', E0t, 'ts', ts0, 'it', it0);
        end
        rs_ok = rs;
        pr = S0t.post_overload_ratio;
        if isempty(pr) || all(isnan(pr)) || S0t.pass_rate_emergency_pct >= cfg.mpac.sc_target_emerg - 1e-9 || q == cfg.mpac.sc_iters
            break;
        end
        rows = find(~isnan(pr) & pr > 1);
        if isempty(rows), break; end
        % v1.2b: new limit relative to the PRE-contingency loading (v1.2a scaled the rating itself, which never bound
        % because these corridors carry only about half their rating before the contingency)
        Lpre = S0t.ref_loading;
        if isempty(Lpre), break; end
        newlim = Lpre(rows) ./ pr(rows) / (1 + cfg.mpac.sc_margin);
        ok = isfinite(newlim) & newlim > 0;
        rows = rows(ok); newlim = newlim(ok);
        if isempty(rows), break; end
        rs(rows) = min(rs(rows), newlim);
        tight = union(tight, rows);
        fprintf('    t%02d preventive N-1 iteration %d: emergency %.1f%% -> rows %s: pre-contingency loading %s, post ratio %s -> limit %s of rating\n', ...
            t, q, S0t.pass_rate_emergency_pct, dali_rows2str(rows), mat2str(round(Lpre(rows).', 3)), ...
            mat2str(round(pr(rows).', 3)), mat2str(round(rs(rows).', 3)));
    end
    SB{t} = best.S; rs = best.rs; RS(:, t) = rs;
    if cfg.mpac.sc_iters > 1 && best.S.pass_rate_emergency_pct < cfg.mpac.sc_target_emerg - 1e-9
        fprintf(['    t%02d preventive N-1: target %.0f%% not reachable with the dispatch range of this period; ', ...
            'keeping the most secure feasible point (emergency %.1f%%, iteration %d)\n'], t, cfg.mpac.sc_target_emerg, ...
            best.S.pass_rate_emergency_pct, best.q);
    end
    scinfo(end+1) = struct('t', t, 'iters', q, 'rows', dali_rows2str(tight), 'emerg_pct', best.S.pass_rate_emergency_pct, ...
        'time_s', toc(tsc0)); %#ok<AGROW>
    Tm.sc_s = Tm.sc_s + toc(tsc0);
    % no-opening OPF: reuse the solve of the N-1 step (same limits), v1.2e solved it twice
    E = best.E;
    topf(t, 1) = best.ts; its(t, 1) = best.it;
    J(t, 1) = E.J_AC; Jloss(t, 1) = E.loss_MW; Jviol(t, 1) = E.sum_v_viol_opf_scope; Jvq(t, 1) = E.tb_vq_rate_110_35kV_pct;
    RES{t, 1} = best.rm; OPFS{t, 1} = best.opfs;
    % single openings: independent given the period data -> parfor (serial when cfg.par.workers = 0)
    INIT = cell(1, S);
    for s = 2:S, INIT{s} = warm_init_open(cfg, WS, bases, RES, t, s); end
    Rm = cell(1, S); Op = cell(1, S); Ev = cell(1, S); Ts = nan(1, S); It = nan(1, S);
    caseT = cases{t};
    parfor (kk = 2:S, cfg.par.workers)
        [Rm{kk}, Op{kk}, Ev{kk}, Ts(kk), It(kk)] = solve_period_opf(caseT, INIT{kk}, meta, cfg, vpen, cand(kk - 1), ...
            dispg, lo, hi, rs);
    end
    for s = 2:S
        topf(t, s) = Ts(s); its(t, s) = It(s);
        E = Ev{s};
        if E.converged
            J(t, s) = E.J_AC; Jloss(t, s) = E.loss_MW; Jviol(t, s) = E.sum_v_viol_opf_scope; Jvq(t, s) = E.tb_vq_rate_110_35kV_pct;
            RES{t, s} = Rm{s}; OPFS{t, s} = Op{s};
        end
    end
    if isfinite(J(t, 1)), pg_prev = RES{t, 1}.gen(:, PG); end
    [~, sb] = min(J(t, :));
    fprintf(['  t%02d x%.3f: %d/%d OPFs converged | no opening J %.3f $/h (N-1 emergency %.1f%% after %d preventive iteration(s)) ', ...
        '| best single opening %s J %.3f $/h (%+.3f) | %.1f s\n'], t, lam(t), sum(isfinite(J(t, :))), S, J(t, 1), ...
        SB{t}.pass_rate_emergency_pct, scinfo(end).iters, ternary(sb == 1, '-', sprintf('row %d', cand(max(sb - 1, 1)))), ...
        J(t, sb), J(t, sb) - J(t, 1), sum(topf(t, :)));
    if ~isfinite(J(t, 1)), error('dali:mpac', 'AC-OPF without switching failed at period %d', t); end
end
Tm.opf_stage_s = toc(to) - Tm.sc_s; Tm.n_opf = T * S; Tm.n_n1_sc = nn1_sc;
Tm.opf_all_s = Tm.opf_stage_s + Tm.opf_noopen_s; Tm.n1_base_s = Tm.sc_s - Tm.opf_noopen_s;
Tm.opf_iters_mean = mean(its(isfinite(its))); Tm.opf_iters_median = median(its(isfinite(its)));
Tm.warm = WS.label;
fprintf(['  stage costs: %d AC-OPFs (wall %.1f s = no-opening %.1f s + openings %.1f s) | per OPF mean %.2f s, ', ...
    'median %.2f s, max %.2f s | MIPS iterations mean %.1f, median %.0f | converged %d\n'], T * S, Tm.opf_all_s, ...
    Tm.opf_noopen_s, Tm.opf_stage_s, mean(topf(:)), median(topf(:)), max(topf(:)), Tm.opf_iters_mean, ...
    Tm.opf_iters_median, sum(isfinite(J(:))));

%% ---------------- DP over switching sequences with lazy N-1 ----------------
fprintf('\n===== DP over switching sequences (actions <= %d, hold >= %d periods) with lazy static AC N-1 =====\n', ...
    cfg.mp.max_actions, cfg.mp.min_hold);
n1st = zeros(T, S);                                    % 0 unknown, 1 pass, -1 fail
SC = cell(T, S);
Tm.dp_s = 0; Tm.n1_s = 0; nn1 = 0; it = 0;
while true
    it = it + 1;
    td = tic;
    Jc = J; Jc(n1st == -1) = inf;
    [path, cost] = dp_path(Jc, dt, cfg.mp.min_hold, cfg.mp.max_actions, cfg.mp.action_cost, s0);
    Tm.dp_s = Tm.dp_s + toc(td);
    if ~isfinite(cost), error('dali:mpac', 'DP found no feasible switching sequence'); end
    fprintf('  DP iteration %d: horizon cost %.3f $ | path %s\n', it, cost, path_str(path, cand));
    changed = false;
    for t = 1:T
        s = path(t);
        tn = tic;
        if isempty(SB{t})
            SB{t} = dali_n1_check(cases{t}, RES{t, 1}, [], OPFS{t, 1}, meta, cfg, sprintf('MPAC_t%02d_no_opening', t));
            nn1 = nn1 + 1;
        end
        if s > 1 && n1st(t, s) == 0
            Sx = dali_n1_check(cases{t}, RES{t, s}, cand(s - 1), OPFS{t, s}, meta, cfg, sprintf('MPAC_t%02d_open_%d', t, cand(s - 1)));
            nn1 = nn1 + 1;
            SC{t, s} = Sx;
            % v1.2e: accept when the opening creates no NEW failing contingency (v1.2-v1.2d compared pass RATES,
            % whose denominators differ by the opened branch, so equal failure sets were rejected)
            newf = setdiff(Sx.emerg_fail_keys, SB{t}.emerg_fail_keys);
            pass = strcmp(Sx.status, 'EVALUATED') && Sx.n_fail_nonconv == 0 && isempty(newf) && ...
                Sx.n_islands_load_gt_1MW <= SB{t}.n_islands_load_gt_1MW;
            n1st(t, s) = 2 * pass - 1;
            fprintf(['    t%02d open row %d: N-1 emergency %.1f%% (no opening %.1f%%), failing contingencies %d (%d), new %s, ', ...
                'load-cutting islanding %d (%d) -> %s\n'], t, cand(s - 1), Sx.pass_rate_emergency_pct, ...
                SB{t}.pass_rate_emergency_pct, Sx.n_fail_emergency, SB{t}.n_fail_emergency, dali_rows2str(newf), ...
                Sx.n_islands_load_gt_1MW, SB{t}.n_islands_load_gt_1MW, ternary(pass, 'PASS', 'FAIL'));
            if ~pass, changed = true; end
        end
        Tm.n1_s = Tm.n1_s + toc(tn);
    end
    if ~changed, break; end
end
Tm.n_n1_checks = nn1; Tm.dp_iterations = it;

%% ---------------- v1.3: save all OPF solutions (warm start for later runs) ----------------
ngen = size(mpc.gen, 1);
VMs = nan(T, S, nb); VAs = nan(T, S, nb); PGs = nan(T, S, ngen); QGs = nan(T, S, ngen);
for t = 1:T
    for s = 1:S
        x = RES{t, s};
        if ~isempty(x) && isfield(x, 'bus') && x.success
            VMs(t, s, :) = x.bus(:, VM); VAs(t, s, :) = x.bus(:, VA);
            PGs(t, s, :) = x.gen(:, PG); QGs(t, s, :) = x.gen(:, QG);
        end
    end
end
sol = struct('VM', VMs, 'VA', VAs, 'PG', PGs, 'QG', QGs, 'J', J, 'cand', cand, 'path', path, 'lam', lam, ...
    'load_shift', cfg.mp.load_shift, 'load_scale', cfg.mp.load_scale, 'disp_range', cfg.mp.disp_range, 'n1st', n1st);
save(fullfile(cfg.outdir, 'MPAC_solutions.mat'), '-struct', 'sol', '-v7');

%% ---------------- final decision, ramp check, per-period table ----------------
dpg = zeros(sum(dispg), T); prev = pg_init(dispg); ramp_ratio = zeros(1, T);
P = struct('t', {}, 'load_factor', {}, 'open_row', {}, 'J_AC', {}, 'J_AC_no_opening', {}, 'loss_MW', {}, ...
    'loss_no_opening_MW', {}, 'viol_pu', {}, 'vq_pct', {}, 'n1_emergency_pct', {}, 'n1_incremental_pct', {}, ...
    'n1_load_cutting_islanding', {}, 'n1_status', {}, 'disp_pg_MW', {}, 'ramp_use_max', {});
fprintf('\n===== Final 16-period decision =====\n');
for t = 1:T
    s = path(t);
    g = RES{t, s}.gen(dispg, PG);
    ramp_ratio(t) = max(abs(g - prev) ./ max(Rr(dispg), 1e-6));
    prev = g; dpg(:, t) = g;
    if s == 1
        Sx = SB{t}; orow = 0; st = 'reference';
    else
        Sx = SC{t, s}; orow = cand(s - 1); st = 'PASS';
    end
    P(end+1) = struct('t', t, 'load_factor', lam(t), 'open_row', orow, 'J_AC', J(t, s), 'J_AC_no_opening', J(t, 1), ...
        'loss_MW', Jloss(t, s), 'loss_no_opening_MW', Jloss(t, 1), 'viol_pu', Jviol(t, s), 'vq_pct', Jvq(t, s), ...
        'n1_emergency_pct', Sx.pass_rate_emergency_pct, 'n1_incremental_pct', Sx.pass_rate_incremental_pct, ...
        'n1_load_cutting_islanding', Sx.n_islands_load_gt_1MW, 'n1_status', st, 'disp_pg_MW', sum(g), ...
        'ramp_use_max', ramp_ratio(t)); %#ok<AGROW>
    fprintf(['  t%02d x%.3f | open %-5s | J %.3f (no opening %.3f) $/h | loss %.2f MW | viol %.4f pu | 110/35kV %.1f%% | ', ...
        'N-1 emergency %.1f%% incremental %.1f%% | disp %.1f MW | ramp use %.2f\n'], t, lam(t), ...
        ternary(orow == 0, '-', sprintf('%d', orow)), J(t, s), J(t, 1), Jloss(t, s), Jviol(t, s), Jvq(t, s), ...
        Sx.pass_rate_emergency_pct, Sx.pass_rate_incremental_pct, sum(g), ramp_ratio(t));
end
acts = sum(arrayfun(@(t) nact(ternary(t == 1, 1, path(max(t - 1, 1))), path(t)), 1:T));
Jsum = dt * sum(J(sub2ind(size(J), 1:T, path)));
J0sum = dt * sum(J(:, 1));
Tm.total_s = toc(t_all);
Tm.baseline_core_s = Tm.period_acpf_s + Tm.topology_screen_s + Tm.sc_s + Tm.opf_stage_s + Tm.dp_s + Tm.n1_s;
nviol_ramp = sum(ramp_ratio > 1 + 1e-6);
fprintf(['\n  horizon: AC objective %.2f $ (no switching %.2f $, %+.2f) | energy loss %.2f MWh (no switching %.2f) | ', ...
    'switching actions %d | N-1 checks %d | ramp limit exceeded in %d periods (max use %.2f)\n'], Jsum, J0sum, Jsum - J0sum, ...
    dt * sum(Jloss(sub2ind(size(J), 1:T, path))), dt * sum(Jloss(:, 1)), acts, nn1, nviol_ramp, max(ramp_ratio));
fprintf(['  >>> 16-period full AC-OTS time: %.1f s = period PFs %.1f + topology screen %.2f + %d AC-OPFs %.1f ', ...
    '(MIPS iterations mean %.1f) + %d static N-1 checks %.1f (period base %d: %.1f, candidates %d: %.1f) + DP %.2f\n', ...
    '      warm start: %s | parallel workers %d (pool start %.1f s, not included)\n'], Tm.baseline_core_s, ...
    Tm.period_acpf_s, Tm.topology_screen_s, Tm.n_opf, Tm.opf_all_s, Tm.opf_iters_mean, nn1_sc + nn1, ...
    Tm.n1_base_s + Tm.n1_s, nn1_sc, Tm.n1_base_s, nn1, Tm.n1_s, Tm.dp_s, Tm.warm, cfg.par.workers, Tm.pool_s);
writetable(struct2table(scinfo), fullfile(cfg.outdir, 'MPAC_preventive_n1.csv'));

%% ---------------- outputs ----------------
writetable(struct2table(P), fullfile(cfg.outdir, 'MPAC_periods.csv'));
writetable(array2table([lam(:), J], 'VariableNames', [{'load_factor'}, {'no_opening'}, ...
    arrayfun(@(k) sprintf('open_%d', k), cand(:).', 'UniformOutput', false)]), fullfile(cfg.outdir, 'MPAC_stage_costs.csv'));
writematrix(n1st, fullfile(cfg.outdir, 'MPAC_n1_status.csv'));
write_report(cfg, Tm, P, cand, S, Jsum, J0sum, acts, nn1, nviol_ramp, max(ramp_ratio), lam, dispg, pg_init, dpg, dt);
res = struct('Tm', Tm, 'Jsum', Jsum, 'J0sum', J0sum, 'acts', acts, 'path', path_str(path, cand), ...
    'n1_checks', nn1_sc + nn1, 'warm', Tm.warm, 'oracle', WS.oracle, 'workers', cfg.par.workers);
save(fullfile(cfg.outdir, 'MPAC_timing.mat'), '-struct', 'res', '-v7');   % v1.3: read by run_speed_tests
fprintf('\nTimings (s):\n'); disp(Tm);
fprintf('\n===== DONE. Upload %s (MPAC_log_*, MPAC_periods.csv, MPAC_report.md) =====\n', cfg.outdir);
end

%% =======================================================================
function [rm, opfs, E, ts, nit] = solve_period_opf(mc, init, meta, cfg, vpen, open, dispg, lo, hi, rs)
define_constants;
tj = tic;
[mpo, opfs] = dali_setup_opf(mc, init, meta, cfg, vpen, open);
if nargin >= 10 && ~isempty(rs)                         % preventive N-1: tightened ratings (only rows with a rating)
    hasr = mpo.branch(:, RATE_A) > 0;
    mpo.branch(hasr, RATE_A) = mpo.branch(hasr, RATE_A) .* rs(hasr);
end
mpo.gen(dispg, PMIN) = lo(dispg);                      % dispatchable units: P free within the period bounds,
mpo.gen(dispg, PMAX) = hi(dispg);                      % same price as the slack -> objective = network loss
mpo.gencost(dispg, 5) = cfg.obj.c_loss;
opfs.pmin(dispg) = lo(dispg); opfs.pmax(dispg) = hi(dispg);
mpopt = mpoption('opf.ac.solver', cfg.opf.solver, 'verbose', 0, 'out.all', 0, ...
    'opf.flow_lim', opfs.flow_lim, 'mips.max_it', cfg.opf.max_it);
mpopt = try_opt(mpopt, 'opf.softlims.default', 0);
mpopt = try_opt(mpopt, 'opf.start', 2);
r = safe_runopf(mpo, mpopt);
if ~r.success
    r2 = safe_runopf(mpo, mpoption(mpopt, 'mips.step_control', 1));
    if r2.success, r = r2; end
end
E = dali_eval_ac(r, meta, cfg, vpen, 'mpac', opfs);
nit = NaN;
try, nit = r.raw.output.iterations; catch, end
if r.success
    rm = struct('baseMVA', r.baseMVA, 'bus', r.bus, 'gen', r.gen, 'branch', r.branch, 'success', 1);
else
    rm = struct('success', 0);
end
ts = toc(tj);
end

function [path, best] = dp_path(J, dt, L, Umax, ac, s0)
% Exact DP over topology sequences. State (s, h, u): topology s (1 = no opening), h-1 periods still locked
% after the last change, u-1 actions used. Start s = 1 (all in service).
[T, S] = size(J);
if nargin < 6 || isempty(s0), s0 = 1; end
C = inf(S, L, Umax + 1); C(s0, 1, 1) = 0;     % v1.3: s0 = topology in effect at the start of the window
BP = zeros(T, S, L, Umax + 1);
sz = [S, L, Umax + 1];
for t = 1:T
    Cn = inf(sz); B = zeros(sz);
    for s = 1:S
        for h = 1:L
            for u = 1:Umax + 1
                c0 = C(s, h, u);
                if ~isfinite(c0), continue; end
                if h > 1
                    cand_s = s;
                else
                    cand_s = 1:S;
                end
                for s2 = cand_s
                    if h > 1
                        a = 0; h2 = h - 1; u2 = u;
                    else
                        a = nact(s, s2);
                        u2 = u + a;
                        if u2 > Umax + 1, continue; end
                        if a > 0, h2 = L; else, h2 = 1; end
                    end
                    v = c0 + dt * J(t, s2) + ac * a;
                    if v < Cn(s2, h2, u2)
                        Cn(s2, h2, u2) = v;
                        B(s2, h2, u2) = sub2ind(sz, s, h, u);
                    end
                end
            end
        end
    end
    C = Cn; BP(t, :, :, :) = reshape(B, [1, sz]);
end
[best, idx] = min(C(:));
path = zeros(1, T);
if ~isfinite(best), return; end
for t = T:-1:1
    [s, h, u] = ind2sub(sz, idx);
    path(t) = s;
    idx = BP(t, s, h, u);
end
end

function a = nact(s, s2)
if s == s2, a = 0; elseif s == 1 || s2 == 1, a = 1; else, a = 2; end
end

function str = path_str(path, cand)
parts = cell(1, numel(path));
for t = 1:numel(path)
    if path(t) == 1, parts{t} = '-'; else, parts{t} = sprintf('%d', cand(path(t) - 1)); end
end
str = strjoin(parts, ' ');
end

function write_report(cfg, Tm, P, cand, S, Jsum, J0sum, acts, nn1, nviol_ramp, maxramp, lam, dispg, pg_init, dpg, dt)
fn = fullfile(cfg.outdir, 'MPAC_report.md');
fid = fopen(fn, 'w', 'n', 'UTF-8');
w = @(varargin) fprintf(fid, varargin{:});
T = numel(P);
w('# 大理 905 节点：16 时段完整 AC-OTS 基准（含机组出力与 N-1）\n\n');
w('%s 自动生成（run_dali_mp_acots v1.3；MATLAB + MATPOWER 8.0 MIPS；并行 worker %d）\n\n', datestr(now, 'yyyy-mm-dd HH:MM'), cfg.par.workers);
w('**OPF 初值（热启动）：** %s\n\n', Tm.warm);
if strcmpi(cfg.mpac.warm, 'file') && cfg.mpac.warm_shift == 0 && cfg.mp.load_shift == 0 && cfg.mp.load_scale == 1
    w('> 注意：本次用本算例自己的最终解作初值（ORACLE），用时只作诊断下限，不能作为指标 4.1 的“输入数据→可行解”用时。\n\n');
end
w('## 1. 结论\n\n');
w(['16 个时段（15 min，负荷系数 %.2f→%.2f）全部跑通：%d 次完整非线性交流 OPF、%d 次静态交流 N-1，', ...
    '基准总用时 %.0f s（约 %.1f 分钟）。最终开关序列共 %d 次动作，4 小时 AC 目标 %.2f $（全程不开断 %.2f $，%+.2f），', ...
    '每个时段的 N-1 紧急判据均不低于不开断方式；可调机组爬坡限制超限时段 %d 个（最大使用率 %.2f）。\n\n'], ...
    lam(1), lam(end), Tm.n_opf, nn1, Tm.baseline_core_s, Tm.baseline_core_s / 60, acts, Jsum, J0sum, Jsum - J0sum, ...
    nviol_ramp, maxramp);
w('## 2. 方法\n\n');
w(['每个时段有 %d 种拓扑：不开断，或断开 %d 条“断开后不新增桥”的支路之一（候选模式 %s）。对每个时段×拓扑求一次完整交流 OPF，', ...
    '决策为 %d 台可调机组有功（±%.0f%%，与平衡机同价，即目标为网损）以及机组无功/电压；目标 J_AC = 网损 + %g × 电压越限（任务书电压口径）。', ...
    '开关序列在时间方向用动态规划精确求解（全程动作 ≤ %d 次，动作后保持 ≥ %d 个时段，每次动作成本 %g）。', ...
    'N-1 为懒校验：对 DP 最优路径上的拓扑做静态交流 N-1（≥110 kV 非桥线路与主变，紧急电压带 0.90–1.10），', ...
    '要求全部收敛、不出现不开断方式没有的失败故障、切负荷解列元件不多于不开断方式，不通过则剔除并重新规划。', ...
    '机组爬坡按时段顺序以上一时段不开断方式的出力为中心施加。分接头保持当前挡位。', ...
    '热启动只改变每次 OPF 的初始点，不改变模型、候选集、动态规划和 N-1 判据。\n\n'], S, numel(cand), cfg.mpac.cand_mode, ...
    sum(dispg), 100 * cfg.mp.disp_range, cfg.mp.vpen, cfg.mp.max_actions, cfg.mp.min_hold, cfg.mp.action_cost);
w('## 3. 用时\n\n| 环节 | 次数 | 用时 |\n| --- | --- | --- |\n');
w('| 16 个时段基准潮流 | %d | %.1f s |\n', T, Tm.period_acpf_s);
w('| 拓扑筛选（不新增桥） | - | %.1f s |\n', Tm.topology_screen_s);
w('| 完整交流 OPF：不开断方式 | %d | %.1f s |\n', T, Tm.opf_noopen_s);
w('| 完整交流 OPF：单条开断（MIPS 平均迭代 %.1f 次） | %d | %.1f s |\n', Tm.opf_iters_mean, Tm.n_opf - T, Tm.opf_stage_s);
w('| 各时段不开断方式的静态 N-1（基准） | %d | %.1f s |\n', Tm.n_n1_sc, Tm.n1_base_s);
w('| 动态规划（%d 轮） | - | %.2f s |\n', Tm.dp_iterations, Tm.dp_s);
w('| 候选拓扑的静态交流 N-1 | %d | %.1f s |\n', nn1, Tm.n1_s);
w('| **合计** | | **%.1f s** |\n\n', Tm.baseline_core_s);
w('## 4. 逐时段结果\n\n| 时段 | 负荷系数 | 开断 | J_AC（$/h） | 不开断 J_AC | 网损（MW） | 电压越限（p.u.） | 110/35 kV 合格率 | N-1 紧急 | N-1 增量 | 可调出力（MW） |\n');
w('| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |\n');
for t = 1:T
    p = P(t);
    w('| %d | %.3f | %s | %.3f | %.3f | %.2f | %.4f | %.1f%% | %.1f%% | %.1f%% | %.1f |\n', p.t, p.load_factor, ...
        ternary(p.open_row == 0, '—', sprintf('%d', p.open_row)), p.J_AC, p.J_AC_no_opening, p.loss_MW, p.viol_pu, p.vq_pct, ...
        p.n1_emergency_pct, p.n1_incremental_pct, p.disp_pg_MW);
end
dE = dpg - pg_init(dispg) * ones(1, T);
w(['\n可调机组相对 S1 出力：4 小时增发 %.1f MWh、压减 %.1f MWh（目标只计网损，未计入水电价值与新能源消纳，', ...
    '压减部分需在汇报中单列）。\n\n'], dt * sum(max(dE(:), 0)), dt * sum(max(-dE(:), 0)));
w('## 5. 口径说明\n\n');
w(['“完整”指每个时段×拓扑都用完整非线性交流 OPF 求解，开关序列在候选集内精确优化；每个 OPF 为非凸问题的局部最优。', ...
    '候选集限于单条开断且断开后不新增桥（需要时可改为全部非桥支路，OPF 次数约增加 16 倍）。机组爬坡按时段顺序写入约束。', ...
    '分接头未参与优化。N-1 为静态交流校验，故障后不重新优化（非 SCOPF）。负荷曲线为合成曲线，', ...
    '电压限值、额定值单位、外网等值等仍为待确认假设。\n']);
fclose(fid);
fprintf('  report written: %s\n', fn);
end

function mpopt = try_opt(mpopt, name, val)
try
    mpopt = mpoption(mpopt, name, val);
catch
end
end

function res = safe_runopf(mpo, mpopt)
try
    res = runopf(mpo, mpopt);
catch
    res = struct('success', 0, 'f', NaN);
end
end

function s = ternary(c, a, b)
if c, s = a; else, s = b; end
end

%% ---------------- v1.3: warm-start helpers ----------------
function WS = load_warm(cfg, cand, ~)
WS = struct('ok', false, 'oracle', false, 'label', '', 'VM', [], 'VA', [], 'PG', [], 'QG', [], 'cand', [], ...
    'path', [], 'smap', []);
switch lower(cfg.mpac.warm)
    case 'none'
        WS.label = 'none (every OPF starts from the period power flow, as in v1.2e)';
    case 'chain'
        WS.label = ['chain (no-opening OPF starts from the previous period''s OPF solution, ', ...
            'single openings from this period''s no-opening OPF solution)'];
    case 'file'
        fn = cfg.mpac.warm_file;
        if ~exist(fn, 'file'), error('dali:mpac', 'Warm-start file not found: %s', fn); end
        X = load(fn);
        WS.ok = true;
        WS.VM = X.VM; WS.VA = X.VA; WS.PG = X.PG; WS.QG = X.QG; WS.cand = X.cand(:); WS.path = X.path(:).';
        smap = zeros(1, numel(cand) + 1); smap(1) = 1;
        for s = 2:numel(cand) + 1
            j = find(WS.cand == cand(s - 1), 1);
            if ~isempty(j), smap(s) = j + 1; end
        end
        WS.smap = smap;
        WS.oracle = cfg.mpac.warm_shift == 0 && X.load_shift == cfg.mp.load_shift && ...
            abs(X.load_scale - cfg.mp.load_scale) < 1e-12 && abs(X.disp_range - cfg.mp.disp_range) < 1e-12;
        if WS.oracle
            kind = 'ORACLE: same instance, diagnostic lower bound only';
        elseif cfg.mpac.warm_shift > 0
            kind = sprintf(['ROLLING: next window, period t starts from the previous window''s period t+%d ', ...
                '(load x%g, previous run x%g)'], cfg.mpac.warm_shift, cfg.mp.load_scale, X.load_scale);
        else
            kind = sprintf('PERTURBED LOAD: x%g, solutions from a run at x%g', cfg.mp.load_scale, X.load_scale);
        end
        WS.label = sprintf('file [%s] %s', kind, fn);
    otherwise
        error('dali:mpac', 'Unknown cfg.mpac.warm = %s (none | chain | file)', cfg.mpac.warm);
end
end

function init = warm_init_noopen(cfg, WS, bases, RES, r1, t)
init = bases{t};
switch lower(cfg.mpac.warm)
    case 'chain'
        if t == 1
            init = with_state(bases{t}, r1);
        elseif ~isempty(RES{t - 1, 1})
            init = with_state(bases{t}, RES{t - 1, 1});
        end
    case 'file'
        x = file_state(bases{t}, WS, t + cfg.mpac.warm_shift, 1);
        if ~isempty(x)
            init = x;
        elseif t > 1 && ~isempty(RES{t - 1, 1})
            init = with_state(bases{t}, RES{t - 1, 1});
        end
end
end

function init = warm_init_open(cfg, WS, bases, RES, t, s)
init = bases{t};
switch lower(cfg.mpac.warm)
    case 'chain'
        init = with_state(bases{t}, RES{t, 1});
    case 'file'
        x = file_state(bases{t}, WS, t + cfg.mpac.warm_shift, WS.smap(s));
        if isempty(x), x = with_state(bases{t}, RES{t, 1}); end
        init = x;
end
end

function x = with_state(base, src)
define_constants;
x = base;
x.bus(:, VM) = src.bus(:, VM); x.bus(:, VA) = src.bus(:, VA);
x.gen(:, PG) = src.gen(:, PG); x.gen(:, QG) = src.gen(:, QG);
end

function x = file_state(base, WS, tt, ss)
define_constants;
x = [];
if ~WS.ok || ss < 1, return; end
tt = min(max(tt, 1), size(WS.VM, 1));
vm = reshape(WS.VM(tt, ss, :), [], 1);
if any(~isfinite(vm)), return; end
x = base;
x.bus(:, VM) = vm; x.bus(:, VA) = reshape(WS.VA(tt, ss, :), [], 1);
x.gen(:, PG) = reshape(WS.PG(tt, ss, :), [], 1); x.gen(:, QG) = reshape(WS.QG(tt, ss, :), [], 1);
end
