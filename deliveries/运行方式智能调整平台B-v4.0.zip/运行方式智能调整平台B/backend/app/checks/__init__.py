"""Five-layer specification validation."""
